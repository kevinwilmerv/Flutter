import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:portfolio_flutter/theme_notifier.dart';

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});

  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  String activeCategory = 'github';

  final List<Map<String, String>> projects = const [
    {
      'title': 'CuacaKu – Aplikasi Cuaca Simpel',
      'image': 'assets/images/CuacaApp.png',
      'description': 'Aplikasi Flutter yang menampilkan info cuaca dengan OpenWeatherMap API.',
      'github': 'https://github.com/kevinwilmerv/Aplikasi-Cuaca.git'
    },
    {
      'title': 'FiVin. – Desain UI/UX Android',
      'image': 'assets/images/PF-UIUX.png',
      'description': 'Prototipe UI/UX Android versi FiVin menggunakan Figma.',
      'figma': 'https://www.figma.com/design/ai7VVwtOpLNkjd6crbiVfi/Project-APSI?node-id=122-8'
    },
    {
      'title': 'Power BI – Visualisasi Penjualan',
      'image': 'assets/images/dashboard1.png',
      'description': 'Visualisasi data penjualan produk dengan Power BI.',
      'github': 'https://github.com/kevinwilmerv/Power-BI.git'
    },
    {
      'title': 'Aplikasi Cluster VB.NET',
      'image': 'assets/images/VB-NET.png',
      'description': 'Aplikasi desktop manajemen data cluster CRUD berbasis VB.NET.',
      'github': 'https://github.com/kevinwilmerv/VB.NET.git'
    },
    {
      'title': 'Website Pemesanan Tiket Pesawat',
      'image': 'assets/images/Website Penerbangan.png',
      'description': 'Website simulasi pemesanan dan jadwal penerbangan.',
      'github': 'https://github.com/kevinwilmerv/Website.git'
    },
    {
      'title': 'Formulir Pendaftaran – Kwik Kian Gie',
      'image': 'assets/images/Form Validation.png',
      'description': 'Simulasi form pendaftaran HTML dengan validasi HTML5.',
      'github': 'https://github.com/kevinwilmerv/Website-Form.git'
    },
    {
      'title': 'FiVin. – Desain UI/UX Desktop',
      'image': 'assets/images/FiVin - Desktop.png',
      'description': 'Prototipe UI/UX desktop aplikasi FiVin menggunakan Figma.',
      'figma': 'https://www.figma.com/design/458FndH06vlyPLlAMQ3qfV/Project-Pemvis'
    },
  ];

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  void _showImagePopup(BuildContext context, String imagePath) {
    bool visible = false;

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setState) {
            Future.delayed(const Duration(milliseconds: 10), () {
              if (mounted) setState(() => visible = true);
            });

            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: const EdgeInsets.all(0),
              child: Stack(
                children: [
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(color: Colors.black.withOpacity(0.3)),
                  ),
                  Center(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: AnimatedOpacity(
                        opacity: visible ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 300),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.asset(
                            imagePath,
                            width: 350,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textTheme = Theme.of(context).textTheme;
    final filteredProjects = projects.where((p) {
      return (activeCategory == 'github' && p['github'] != null) ||
          (activeCategory == 'figma' && p['figma'] != null);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: isDark ? Colors.black : Colors.white,
        elevation: 1,
        centerTitle: true,
        title: Text(
          'My Projects',
          style: GoogleFonts.poppins(
            textStyle: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ),
        ),
        iconTheme: IconThemeData(color: isDark ? Colors.white : Colors.black87),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.center,
                children: [
                  _buildFilterButton('github', Icons.code, 'GitHub Projects', isDark),
                  _buildFilterButton('figma', Icons.design_services, 'Figma Projects', isDark),
                ],
              ),
              const SizedBox(height: 24),
              Expanded(
                child: ListView.builder(
                  itemCount: filteredProjects.length,
                  itemBuilder: (context, index) {
                    final project = filteredProjects[index];
                    final url = project[activeCategory]!;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 24),
                      elevation: 3,
                      color: isDark ? Colors.grey[900] : Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (project['image'] != null)
                              GestureDetector(
                                onTap: () => _showImagePopup(context, project['image']!),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: AspectRatio(
                                    aspectRatio: 16 / 9,
                                    child: Image.asset(
                                      project['image']!,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            const SizedBox(height: 12),
                            Text(
                              project['title'] ?? '',
                              style: textTheme.titleMedium?.copyWith(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: isDark ? Colors.white : Colors.black,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              project['description'] ?? '',
                              style: textTheme.bodyMedium?.copyWith(
                                fontSize: 14,
                                color: isDark ? Colors.grey[300] : Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: SizedBox(
                                width: 180,
                                child: ElevatedButton.icon(
                                  onPressed: () => _launchUrl(url),
                                  icon: Icon(activeCategory == 'github'
                                      ? Icons.code
                                      : Icons.design_services),
                                  label: Text(
                                    activeCategory == 'github'
                                        ? 'Lihat di GitHub'
                                        : 'Lihat di Figma',
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                    isDark ? Colors.blue[700] : Colors.blue,
                                    foregroundColor: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterButton(
      String category, IconData icon, String label, bool isDark) {
    final isActive = activeCategory == category;

    return ElevatedButton.icon(
      onPressed: () => setState(() => activeCategory = category),
      icon: Icon(icon, color: isActive ? Colors.white : Colors.black87),
      label: Text(
        label,
        style: TextStyle(color: isActive ? Colors.white : Colors.black87),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor:
        isActive ? (isDark ? Colors.blue[700] : Colors.blue) : Colors.grey[200],
        elevation: isActive ? 3 : 0,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
