import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:portfolio_flutter/theme_notifier.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final imageSize = screenWidth * 0.7;

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    final subtitleColor = isDark ? Colors.grey[300] : Colors.grey;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 1,
        centerTitle: true,
        title: Text(
          'About Me',
          style: GoogleFonts.poppins(
            textStyle: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).appBarTheme.foregroundColor,
            ),
          ),
        ),
        iconTheme: IconThemeData(
          color: Theme.of(context).appBarTheme.foregroundColor,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (_) => Dialog(
                    backgroundColor: Colors.transparent,
                    insetPadding: const EdgeInsets.all(0),
                    child: Stack(
                      children: [
                        BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                          child: Container(color: Colors.black.withOpacity(0.3)),
                        ),
                        Center(
                          child: GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: ClipOval(
                              child: Image.asset(
                                'assets/images/fotoIC.jpg',
                                width: imageSize,
                                height: imageSize,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
              child: const CircleAvatar(
                radius: 90,
                backgroundImage: AssetImage('assets/images/fotoIC.jpg'),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'KEVIN WILMER VITTORIO',
              style: GoogleFonts.poppins(
                textStyle: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Sistem Informasi | Pemrograman • UI/UX • Bisnis',
              style: GoogleFonts.poppins(
                textStyle: TextStyle(
                  fontSize: 14,
                  color: subtitleColor,
                ),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Text(
              'Seorang individu yang memiliki komitmen tinggi terhadap tanggung jawab dan pencapaian tujuan, serta terbiasa bekerja secara terstruktur dalam lingkungan yang dinamis. Pengalaman organisasi yang dimiliki turut membentuk kemampuan dalam beradaptasi, mengambil keputusan secara bijak, dan memimpin secara kolaboratif. Terus berupaya mengembangkan diri melalui pembelajaran dan kontribusi yang positif dalam setiap peran yang diemban.',
              style: GoogleFonts.poppins(
                fontSize: 14,
                color: textColor,
              ),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 28),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.school, color: Colors.indigo),
                const SizedBox(width: 12),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: GoogleFonts.poppins(
                        textStyle: TextStyle(
                          fontSize: 14,
                          color: textColor,
                        ),
                      ),
                      children: const [
                        TextSpan(
                          text: 'Institut Bisnis dan Informatika Kwik Kian Gie\n',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        TextSpan(
                          text: 'SISTEM INFORMASI',
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
