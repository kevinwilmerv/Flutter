import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:portfolio_flutter/theme_notifier.dart';

class CertificationsPage extends StatelessWidget {
  const CertificationsPage({super.key});

  final List<Map<String, String>> certifications = const [
    {
      'title': 'Ketua Pelaksana',
      'issuer': 'Informatics Community - IBIKKG',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=1E6sF98B3ElUfQq5tuasVFUAhgD8TAOen'
    },
    {
      'title': 'Financial Literacy',
      'issuer': 'Wadhwani Foundation',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=1caxkEr4VvhezXlLfzbYdV_AWnhbCzEqq'
    },
    {
      'title': 'Introduction to Entrepreneurship',
      'issuer': 'Wadhwani Foundation',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=1M3gpV7v4ov4HUJ3AgMGnvAmDuG4roQMi'
    },
    {
      'title': 'JobReady Employability Skills',
      'issuer': 'Wadhwani Foundation',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=1A0O30wOeUCoulkSjNLZ3IoDNlxvZyi44'
    },
    {
      'title': 'Obtain an Appropriate Job',
      'issuer': 'Wadhwani Foundation',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=12yGHt8Xh0RE1y59N36W_1twlNCb02PGM'
    },
    {
      'title': 'Online Communication & Data Security',
      'issuer': 'Wadhwani Foundation',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=1U9K2OI12ZBanVY2R8MTMKSR-EYoGh_70'
    },
    {
      'title': 'Start-up Mindset',
      'issuer': 'Wadhwani Foundation',
      'year': '2024',
      'url': 'https://drive.google.com/uc?export=download&id=1Az3DziLgupz_lSZQYBYv7qDS6a2NhdeG'
    },
  ];

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    final subtitleColor = isDark ? Colors.grey[300] : Colors.grey[600];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 1,
        centerTitle: true,
        title: Text(
          'Certifications',
          style: GoogleFonts.poppins(
            textStyle: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).appBarTheme.foregroundColor,
            ),
          ),
        ),
        iconTheme: IconThemeData(
          color: Theme.of(context).appBarTheme.foregroundColor,
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return ListView.builder(
            padding: const EdgeInsets.all(20),
            itemCount: certifications.length,
            itemBuilder: (context, index) {
              final cert = certifications[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 20),
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                color: Theme.of(context).cardColor,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        cert['title'] ?? '',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: textColor,
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${cert['issuer']} • ${cert['year']}',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            fontSize: 14,
                            color: subtitleColor,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        onPressed: () {
                          if (cert['url'] != null) {
                            _launchUrl(cert['url']!);
                          }
                        },
                        icon: const Icon(Icons.download),
                        label: const Text('Download Certificate'),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
