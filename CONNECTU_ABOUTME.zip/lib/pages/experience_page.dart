import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ExperiencePage extends StatelessWidget {
  const ExperiencePage({super.key});

  final List<Map<String, String>> experiences = const [
    {
      'role': 'Ketua Umum',
      'org': 'Himpunan Mahasiswa SI & TI',
      'year': '2024–2025',
      'desc':
      'Memimpin tim untuk mencapai dan melampaui target yang ditetapkan, mengoordinasikan program kerja dengan terstruktur, dan membangun serta menjaga relasi eksternal.',
    },
    {
      'role': 'Kepala Divisi Humas',
      'org': 'Himpunan Mahasiswa SI & TI',
      'year': '2023–2024',
      'desc':
      'Mengorganisir dan bertanggung jawab atas branding organisasi serta berbagai acara kampus, menjalin kemitraan dengan pihak luar seperti AORUS (partner kolaboratif) dan media partner lainnya.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final appBarColor = Theme.of(context).appBarTheme.backgroundColor ??
        (isDark ? Colors.grey[900] : Colors.white);
    final iconColor =
        Theme.of(context).appBarTheme.iconTheme?.color ??
            (isDark ? Colors.white : Colors.black87);
    final textColor =
        Theme.of(context).appBarTheme.titleTextStyle?.color ??
            (isDark ? Colors.white : Colors.black87);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: appBarColor,
        elevation: 1,
        centerTitle: true,
        title: Text(
          'My Experience',
          style: GoogleFonts.poppins(
            textStyle: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
        ),
        iconTheme: IconThemeData(color: iconColor),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: experiences.length,
        itemBuilder: (context, index) {
          final exp = experiences[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 20),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    exp['role'] ?? '',
                    style: GoogleFonts.poppins(
                      textStyle: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${exp['org']} • ${exp['year']}',
                    style: GoogleFonts.poppins(
                      textStyle: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    exp['desc'] ?? '',
                    style: GoogleFonts.poppins(
                      textStyle: const TextStyle(fontSize: 15),
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
