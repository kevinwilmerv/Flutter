import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_fonts/google_fonts.dart';
// Hapus jika theme_notifier tidak digunakan
// import 'package:portfolio_flutter/theme_notifier.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  final String email = 'mailto:kevinwilmerv07@gmail.com';
  final String github = 'https://github.com/kevinwilmerv';
  final String linkedin = 'https://www.linkedin.com/in/kevinwilmerv/';
  final String cvLink =
      'https://raw.githubusercontent.com/kevinwilmerv/cv-2024-2025/main/CV%2020242025%20-%20KEVIN%20WILMER%20VITTORIO.pdf';

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor ?? (isDark ? Colors.black : Colors.white),
        elevation: 1,
        centerTitle: true,
        title: Text(
          'Contact Me',
          style: GoogleFonts.poppins(
            textStyle: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ),
        ),
        iconTheme: IconThemeData(color: isDark ? Colors.white : Colors.black87),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hubungi Saya:',
              style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.email),
              title: const Text('Email'),
              subtitle: const Text('kevinwilmerv07@gmail.com'),
              onTap: () => _launchUrl(email),
            ),
            ListTile(
              leading: const Icon(Icons.code),
              title: const Text('GitHub'),
              subtitle: const Text('github.com/kevinwilmerv'),
              onTap: () => _launchUrl(github),
            ),
            ListTile(
              leading: const Icon(Icons.work),
              title: const Text('LinkedIn'),
              subtitle: const Text('linkedin.com/in/kevinwilmerv'),
              onTap: () => _launchUrl(linkedin),
            ),
            const SizedBox(height: 24),
            Center(
              child: ElevatedButton.icon(
                onPressed: () => _launchUrl(cvLink),
                icon: const Icon(Icons.download),
                label: const Text('Download CV'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
