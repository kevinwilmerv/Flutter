import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:portfolio_flutter/theme_notifier.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String searchQuery = '';

  final List<Map<String, dynamic>> menuItems = [
    {'icon': Icons.person, 'label': 'About Me', 'route': '/about'},
    {'icon': Icons.phone_android, 'label': 'Projects', 'route': '/projects'},
    {'icon': Icons.leaderboard, 'label': 'Experience', 'route': '/experience'},
    {'icon': Icons.verified, 'label': 'Certifications', 'route': '/certifications'},
    {'icon': Icons.mail, 'label': 'Contact', 'route': '/contact'},
  ];

  @override
  void initState() {
    super.initState();

    // Hindari keyboard muncul lagi saat kembali ke halaman ini
    Future.delayed(Duration.zero, () {
      FocusScope.of(context).unfocus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;
    final textColor = theme.textTheme.bodyMedium?.color ?? Colors.black87;
    final backgroundColor = theme.scaffoldBackgroundColor;
    final cardColor = theme.cardColor;

    final filteredItems = menuItems
        .where((item) => (item['label'] as String)
        .toLowerCase()
        .contains(searchQuery.toLowerCase()))
        .toList();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
          elevation: 1,
          centerTitle: true,
          title: Text(
            'My Portfolio',
            style: GoogleFonts.poppins(
              textStyle: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                color: textColor,
              ),
            ),
          ),
          actions: [
            ValueListenableBuilder<ThemeMode>(
              valueListenable: themeNotifier,
              builder: (context, currentTheme, _) {
                return IconButton(
                  icon: Icon(
                    currentTheme == ThemeMode.light
                        ? Icons.dark_mode
                        : Icons.light_mode,
                    color: Theme.of(context).iconTheme.color,
                  ),
                  onPressed: () {
                    themeNotifier.value = currentTheme == ThemeMode.light
                        ? ThemeMode.dark
                        : ThemeMode.light;
                  },
                );
              },
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (_) => Dialog(
                      backgroundColor: Colors.transparent,
                      insetPadding: const EdgeInsets.all(0),
                      child: Stack(
                        children: [
                          BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                            child: Container(
                              color: Colors.black.withOpacity(0.3),
                            ),
                          ),
                          Center(
                            child: GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Hero(
                                tag: 'profile',
                                child: ClipOval(
                                  child: Image.asset(
                                    'assets/images/Foto Profile.jpg',
                                    width: 240,
                                    height: 240,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                child: Hero(
                  tag: 'profile',
                  child: const CircleAvatar(
                    radius: 80,
                    backgroundImage:
                    AssetImage('assets/images/Foto Profile.jpg'),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'KEVIN WILMER VITTORIO',
                style: GoogleFonts.poppins(
                  textStyle: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextField(
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    hintStyle: TextStyle(
                      color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
                    ),
                    prefixIcon: Icon(Icons.search, color: textColor),
                    filled: true,
                    fillColor: isDarkMode ? Colors.grey[800] : Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  onChanged: (value) => setState(() => searchQuery = value),
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    children: filteredItems
                        .map((item) => _buildMenuItem(
                      icon: item['icon'],
                      label: item['label'],
                      route: item['route'],
                      cardColor: cardColor,
                      textColor: textColor,
                      isDarkMode: isDarkMode,
                    ))
                        .toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String label,
    required String route,
    required Color cardColor,
    required Color textColor,
    required bool isDarkMode,
  }) {
    return InkWell(
      onTap: () {
        FocusScope.of(context).unfocus(); // ⬅️ ini memastikan keyboard ditutup saat pindah halaman
        Navigator.pushNamed(context, route);
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            if (!isDarkMode)
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 6,
                offset: const Offset(2, 2),
              ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 36, color: Colors.indigo),
            const SizedBox(height: 10),
            Text(
              label,
              style: GoogleFonts.poppins(
                textStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: textColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
