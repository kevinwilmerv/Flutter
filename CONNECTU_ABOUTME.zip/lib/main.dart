import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'theme_notifier.dart';

import 'pages/home_page.dart';
import 'pages/about_page.dart';
import 'pages/projects_page.dart';
import 'pages/experience_page.dart';
import 'pages/certifications_page.dart';
import 'pages/contact_page.dart';
import 'pages/splash_screen.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() {
  runApp(const PortfolioApp());
}

class PortfolioApp extends StatelessWidget {
  const PortfolioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Kevin Wilmer Vittorio Portfolio',
          navigatorKey: navigatorKey,
          themeMode: themeNotifier.value,
          theme: ThemeData(
            primarySwatch: Colors.indigo,
            scaffoldBackgroundColor: const Color(0xFFF5F7FA),
            textTheme: GoogleFonts.poppinsTextTheme(
              ThemeData.light().textTheme.copyWith(
                headlineMedium: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
                bodyMedium: const TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
            ),
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.white,
              foregroundColor: Colors.black87,
              elevation: 0.5,
              centerTitle: true,
            ),
            cardTheme: CardThemeData(
              color: Colors.white, // Warna card untuk tema terang
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            primarySwatch: Colors.indigo,
            scaffoldBackgroundColor: const Color(0xFF121212),
            textTheme: GoogleFonts.poppinsTextTheme(
              ThemeData.dark().textTheme.copyWith(
                headlineMedium: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
                bodyMedium: const TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
              ),
            ),
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              elevation: 0.5,
              centerTitle: true,
            ),
            cardTheme: CardThemeData(
              color: const Color(0xFF1E1E1E), // Warna card untuk tema gelap
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          home: const SplashScreen(),
          routes: {
            '/home': (context) => const HomePage(),
            '/about': (context) => const AboutPage(),
            '/projects': (context) => const ProjectsPage(),
            '/experience': (context) => const ExperiencePage(),
            '/certifications': (context) => const CertificationsPage(),
            '/contact': (context) => const ContactPage(),
          },
        );
      },
    );
  }
}
