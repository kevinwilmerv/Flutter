import 'dart:async';
import 'package:flutter/material.dart';
import 'package:ok_oce/pages/auth_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    // Durasi splash — ubah sesuai preferensi (saya set 3 detik, sebelumnya 6.5)
    _timer = Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const AuthPage(),
        ),
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFF9F9), // Pink muda
              Color(0xFFFFFFFF), // Putih
            ],
          ),
        ),
        child: Center(
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Radial gradient soft blur behind the GIF
              Container(
                width: 760,
                height: 760,
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 0.65,
                    colors: [
                      Color(0xFFFFF9F9), // warna dalam, mirip bg
                      Color(0x00FFFFFF), // makin transparan
                    ],
                  ),
                ),
              ),
              // Logo GIF
              Image.asset(
                'assets/InmatoID_gif.gif',
                width: 720,
                height: 720,
                fit: BoxFit.contain,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
