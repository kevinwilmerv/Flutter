import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/widget/usaha_drawer.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/pages/laporanLB.dart';

class ThousandsSeparatorInputFormatter extends TextInputFormatter {
  final NumberFormat _formatter = NumberFormat.decimalPattern('id_ID');
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.text.isEmpty) return newValue;
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return newValue.copyWith(text: '');
    final formatted = _formatter.format(int.parse(digits));
    return TextEditingValue(text: formatted, selection: TextSelection.collapsed(offset: formatted.length));
  }
}

enum InputMode { harian, periode }

// ====== MODEL BIAYA DINAMIS ======
enum _JenisBiaya { sewa, servis, lainnya }

class _BiayaItem {
  _JenisBiaya jenis;
  final TextEditingController namaCtrl;     // dipakai hanya jika lainnya
  final TextEditingController nominalCtrl;  // selalu dipakai

  _BiayaItem({
    required this.jenis,
    String? nama,
    int nominal = 0,
  })  : namaCtrl = TextEditingController(text: nama ?? ''),
        nominalCtrl = TextEditingController(
          text: nominal <= 0 ? '' : NumberFormat.decimalPattern('id_ID').format(nominal),
        );

  int get nominal {
    final raw = nominalCtrl.text.replaceAll('.', '');
    return int.tryParse(raw) ?? 0;
  }

  String get nama => namaCtrl.text.trim();

  void dispose() {
    namaCtrl.dispose();
    nominalCtrl.dispose();
  }

  String get labelJenis {
    switch (jenis) {
      case _JenisBiaya.sewa:
        return 'Sewa & Penyusutan';
      case _JenisBiaya.servis:
        return 'Servis Kantor';
      case _JenisBiaya.lainnya:
        return 'Lainnya';
    }
  }
}

class InputLabaBersihPage extends StatefulWidget {
  final DateTime tanggal;
  const InputLabaBersihPage({super.key, required this.tanggal});
  @override
  State<InputLabaBersihPage> createState() => _InputLabaBersihPageState();
}

class _InputLabaBersihPageState extends State<InputLabaBersihPage> {
  // ===== Unsaved-changes guard =====
  final _dirty = ValueNotifier<bool>(false);
  bool _dirtyToastShown = false;
  bool get _isDirty => _dirty.value;

  // --- Tambah di dalam _InputLabaBersihPageState
  void _onFieldsChanged() {
    // Dirty hanya jika ada input bermakna (nominal>0 atau nama lain terisi)
    if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
  }

  void _watchItem(_BiayaItem it) {
    // Hindari double-listener
    it.nominalCtrl.removeListener(_onFieldsChanged);
    it.namaCtrl.removeListener(_onFieldsChanged);
    it.nominalCtrl.addListener(_onFieldsChanged);
    it.namaCtrl.addListener(_onFieldsChanged);
  }

  void _unwatchItem(_BiayaItem it) {
    it.nominalCtrl.removeListener(_onFieldsChanged);
    it.namaCtrl.removeListener(_onFieldsChanged);
  }

  void _markDirty() {
    if (!_dirty.value) {
      _dirty.value = true;
    }
  }

  void _markClean() {
    if (_dirty.value) _dirty.value = false;
    _dirtyToastShown = false;
  }

  // Dianggap ada draft bermakna jika ada nominal > 0 atau (Lainnya && nama terisi)
  bool _hasMeaningfulDraft() {
    for (final it in _items) {
      if (it.nominal > 0) return true;
      if (it.jenis == _JenisBiaya.lainnya && it.nama.isNotEmpty) return true;
    }
    return false;
  }

  Future<_DiscardAction> _confirmDiscardDialog() async {
    return await showDialog<_DiscardAction>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Perubahan belum disimpan'),
        content: const Text('Kamu sudah mengubah data tapi belum menekan Simpan. Mau gimana?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardAction.cancel),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardAction.discard),
            child: const Text('Tinggalkan'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, _DiscardAction.save),
            icon: const Icon(Icons.save),
            label: const Text('Simpan sekarang'),
          ),
        ],
      ),
    ) ??
        _DiscardAction.cancel;
  }

  Future<bool> _confirmLeaveIfDirty() async {
    if (!_isDirty) return true;

    // Kalau cuma "Tambah Biaya" kosong tanpa input -> tidak dicegat
    if (!_hasMeaningfulDraft()) {
      _markClean();
      return true;
    }

    final action = await _confirmDiscardDialog();
    if (action == _DiscardAction.save) {
      await _saveLaporan();
      return true;
    } else if (action == _DiscardAction.discard) {
      return true;
    }
    return false;
  }

  Future<void> _openLaporanLB() async {
    if (idUsaha == null) return;
    if (!await _confirmLeaveIfDirty()) return;
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => LaporanLBPage(idUsaha: idUsaha!)),
    );
  }

  // ===== State dasar =====
  final List<_BiayaItem> _items = [];

  int totalPenjualan = 0;
  int totalBebanUsaha = 0;
  int totalHPP = 0;

  DateTime? _startDate;
  DateTime? _endDate;
  String? idUsaha;

  InputMode _mode = InputMode.harian;
  bool _saving = false;

  // ===== Helper tampilan uang =====
  String _cur(int value) => NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(value);

  // ===== Getter perhitungan =====
  int get _sumSewa   => _items.where((e) => e.jenis == _JenisBiaya.sewa).fold(0, (a, it) => a + it.nominal);
  int get _sumServis => _items.where((e) => e.jenis == _JenisBiaya.servis).fold(0, (a, it) => a + it.nominal);
  int get _sumLain   => _items.where((e) => e.jenis == _JenisBiaya.lainnya).fold(0, (a, it) => a + it.nominal);

  int get biayaTetap => _sumSewa + _sumServis + _sumLain;
  int get labaKotor => totalPenjualan - totalHPP;
  int get labaSebelumBiayaTetap => labaKotor - totalBebanUsaha;
  int get labaBersih => labaSebelumBiayaTetap - biayaTetap;

  bool get _datesReady => _startDate != null && (_mode == InputMode.harian ? true : _endDate != null);
  bool get _canRun => idUsaha != null && _datesReady;

  @override
  void initState() {
    super.initState();
    _startDate = widget.tanggal;
    _endDate = widget.tanggal;
    _init();
  }

  @override
  void dispose() {
    for (final it in _items) {
      it.dispose();
    }
    _dirty.dispose();
    super.dispose();
  }

  // ================== INIT ==================
  Future<void> _init() async {
    await _loadUsaha();
    _ensureDefaultRows(); // hanya 1 row default
    if (_canRun) await _runFetch();
    if (_mode == InputMode.harian) await _loadFixedCostForStartDate();
    _markClean();
  }

  // Pastikan 1 baris default
  void _ensureDefaultRows() {
    if (_items.isEmpty) {
      final it = _BiayaItem(jenis: _JenisBiaya.sewa);
      _items.add(it);
      _watchItem(it);
    }
    setState(() {});
  }

  Future<void> _loadUsaha() async {
    final supabase = Supabase.instance.client;
    try {
      final row = await supabase
          .from('profiles')
          .select('id_usaha')
          .eq('id', supabase.auth.currentUser!.id)
          .maybeSingle();
      setState(() => idUsaha = row?['id_usaha'] as String?);
    } catch (_) {/* ignore */}
  }

  // ================== DATE HELPERS ==================
  Map<String, String> _rangeDate() {
    var s = DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
    var e = _mode == InputMode.harian ? s : DateTime(_endDate!.year, _endDate!.month, _endDate!.day);
    if (s.isAfter(e)) {
      final t = s; s = e; e = t;
    }
    return {
      'start': DateFormat('yyyy-MM-dd').format(s),
      'end': DateFormat('yyyy-MM-dd').format(e),
    };
  }

  Future<void> _pickStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _startDate = picked);
      _resetTotals();
      if (_mode == InputMode.harian) {
        await _loadFixedCostForStartDate();
      } else {
        _resetBiayaItems();
      }
      _markClean(); // ganti tanggal saja tidak dianggap draft
    }
  }

  Future<void> _pickEndDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _endDate ?? (_startDate ?? DateTime.now()),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _endDate = picked);
      _resetTotals();
      _markClean();
    }
  }

  // ================== LOAD & RESET ==================
  void _resetTotals() {
    setState(() {
      totalPenjualan = 0;
      totalBebanUsaha = 0;
      totalHPP = 0;
    });
  }

  void _resetBiayaItems() {
    for (final it in _items) { _unwatchItem(it); it.dispose(); } // <-- unwatch
    _items.clear();
    _ensureDefaultRows();
  }

  Future<void> _loadFixedCostForStartDate() async {
    if (idUsaha == null || _startDate == null) {
      _resetBiayaItems();
      _markClean();
      return;
    }
    final supabase = Supabase.instance.client;
    final t = DateFormat('yyyy-MM-dd').format(_startDate!);
    try {
      final row = await supabase
          .from('laba_bersih')
          .select('sewa_penyusutan, servis_kantor, nilai_biaya_lain, biaya_lain')
          .eq('id_usaha', idUsaha!)
          .eq('tanggal', t)
          .maybeSingle();

      final sewa   = (row?['sewa_penyusutan'] ?? 0) as int;
      final servis = (row?['servis_kantor'] ?? 0) as int;
      final lain   = (row?['nilai_biaya_lain'] ?? 0) as int;
      final jenis  = (row?['biaya_lain'] ?? '') as String;

      for (final it in _items) { _unwatchItem(it); it.dispose(); } // sebelum clear
      _items.clear();

// ...tambah item sesuai data...
      if (sewa > 0)   _items.add(_BiayaItem(jenis: _JenisBiaya.sewa, nominal: sewa));
      if (servis > 0) _items.add(_BiayaItem(jenis: _JenisBiaya.servis, nominal: servis));
      if (lain > 0 || jenis.isNotEmpty) {
        _items.add(_BiayaItem(jenis: _JenisBiaya.lainnya, nama: jenis, nominal: lain));
      }
      if (_items.isEmpty) _items.add(_BiayaItem(jenis: _JenisBiaya.sewa));

// pasang watcher utk semua item baru
      for (final it in _items) { _watchItem(it); }  // <-- add this

      setState(() {});
      _markClean();

    } catch (_) {
      _resetBiayaItems();
      _markClean();
    }
  }

  // ================== FETCH AGGREGATES ==================
  Future<void> _runFetch() async {
    if (idUsaha == null) await _loadUsaha();
    if (!_datesReady) {
      await showTopToast(context, "Pilih tanggal terlebih dahulu", icon: Icons.info_rounded);
      return;
    }
    _resetTotals();
    if (_mode == InputMode.harian) {
      await _loadFixedCostForStartDate();
    }
    await Future.wait([_fetchPenjualan(), _fetchBebanUsaha(), _fetchHPP()]);
  }

  Future<void> _fetchPenjualan() async {
    if (!_datesReady || idUsaha == null) return;
    final r = _rangeDate(); final usaha = idUsaha!;
    try {
      final rows = await Supabase.instance.client
          .from('rekap_omzet_harian')
          .select('tanggal,total_omzet')
          .eq('id_usaha', usaha)
          .gte('tanggal', r['start']!)
          .lte('tanggal', r['end']!)
          .order('tanggal');
      var total = 0;
      for (final row in rows) {
        total += (row['total_omzet'] as num?)?.toInt() ?? 0;
      }
      setState(() => totalPenjualan = total);
    } catch (_) {}
  }

  Future<void> _fetchBebanUsaha() async {
    if (!_datesReady || idUsaha == null) return;
    final r = _rangeDate(); final usaha = idUsaha!;
    try {
      final rows = await Supabase.instance.client
          .from('rekap_beban_usaha_harian')
          .select('tanggal,total_beban_usaha')
          .eq('id_usaha', usaha)
          .gte('tanggal', r['start']!)
          .lte('tanggal', r['end']!)
          .order('tanggal');
      var total = 0;
      for (final row in rows) {
        total += (row['total_beban_usaha'] as num?)?.toInt() ?? 0;
      }
      setState(() => totalBebanUsaha = total.abs());
    } catch (_) {}
  }

  Widget _lihatLaporanButton() {
    return SizedBox(
      height: 36,
      child: OutlinedButton.icon(
        onPressed: idUsaha == null ? null : () async { await _openLaporanLB(); },
        icon: const Icon(Icons.receipt_long, size: 16),
        label: const Text('Lihat Laporan'),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          side: const BorderSide(color: Colors.black, width: 1),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          foregroundColor: Colors.black,
          backgroundColor: const Color(0xFFFFE4E9),
        ),
      ),
    );
  }

  Widget _saveFooterButton() {
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        final targetWidth = (w <= 380) ? w : (w <= 560) ? w * 0.70 : 420.0;
        final label = _saving ? (w < 380 ? 'Menyimpan...' : 'Menyimpan Laporan...') : (w < 380 ? 'Simpan' : 'Simpan');

        return Align(
          alignment: Alignment.centerLeft,
          child: SizedBox(
            width: targetWidth,
            child: FilledButton.icon(
              onPressed: _saving ? null : () async { await _saveLaporan(); },
              icon: _saving
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.save_rounded, size: 18),
              label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
              style: FilledButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                backgroundColor: Colors.black87,
                foregroundColor: Colors.white,
                elevation: 0,
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _fetchHPP() async {
    if (!_datesReady || idUsaha == null) return;
    final r = _rangeDate(); final usaha = idUsaha!;
    try {
      final rows = await Supabase.instance.client
          .from('rekap_bahan_pokok')
          .select('tanggal,total')
          .eq('id_usaha', usaha)
          .gte('tanggal', r['start']!)
          .lte('tanggal', r['end']!)
          .order('tanggal');
      var total = 0;
      for (final row in rows) {
        total += (row['total'] as num?)?.toInt() ?? 0;
      }
      setState(() => totalHPP = total);
    } catch (_) {}
  }

  // ================== SAVE ==================
  Future<void> _saveLaporan() async {
    if (idUsaha == null) {
      await showTopToast(context, "ID usaha tidak ditemukan", icon: Icons.warning_amber_rounded);
      return;
    }
    if (_startDate == null) {
      await showTopToast(context, "Pilih tanggal dulu", icon: Icons.info_rounded);
      return;
    }

    final DateTime start = DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
    final DateTime end   = (_mode == InputMode.harian)
        ? start
        : DateTime(_endDate!.year, _endDate!.month, _endDate!.day);

    if (start.isAfter(end)) {
      await showTopToast(context, "Rentang tanggal tidak valid", icon: Icons.info_rounded);
      return;
    }

    if (!mounted) return;
    setState(() => _saving = true);

    final supabase = Supabase.instance.client;

    final totalSewa   = _sumSewa;
    final totalServis = _sumServis;
    final totalLain   = _sumLain;

    final labelsLain = _items
        .where((e) => e.jenis == _JenisBiaya.lainnya && (e.nama.isNotEmpty || e.nominal > 0))
        .map((e) => e.nama.isEmpty ? 'Lainnya' : e.nama)
        .join(' | ')
        .trim();

    final tStart = DateFormat('yyyy-MM-dd').format(start);
    final tEnd   = DateFormat('yyyy-MM-dd').format(end);

    try {
      final results = await Future.wait([
        supabase
            .from('rekap_omzet_harian')
            .select('tanggal,total_omzet')
            .eq('id_usaha', idUsaha!)
            .gte('tanggal', tStart)
            .lte('tanggal', tEnd),
        supabase
            .from('rekap_bahan_pokok')
            .select('tanggal,total')
            .eq('id_usaha', idUsaha!)
            .gte('tanggal', tStart)
            .lte('tanggal', tEnd),
        supabase
            .from('rekap_beban_usaha_harian')
            .select('tanggal,total_beban_usaha')
            .eq('id_usaha', idUsaha!)
            .gte('tanggal', tStart)
            .lte('tanggal', tEnd),
      ]);

      String _keyDate(dynamic v) {
        if (v == null) return '';
        if (v is DateTime) return DateFormat('yyyy-MM-dd').format(v.toLocal());
        final s = v.toString();
        return s.length >= 10 ? s.substring(0, 10) : s;
      }

      final Map<String, num> omzet = {};
      for (final r in (results[0] as List)) {
        omzet[_keyDate(r['tanggal'])] = (r['total_omzet'] as num?) ?? 0;
      }
      final Map<String, num> hpp = {};
      for (final r in (results[1] as List)) {
        hpp[_keyDate(r['tanggal'])] = ((r['total'] as num?) ?? 0).abs();
      }
      final Map<String, num> bu = {};
      for (final r in (results[2] as List)) {
        bu[_keyDate(r['tanggal'])] = ((r['total_beban_usaha'] as num?) ?? 0).abs();
      }

      final Map<String, Map<String, dynamic>> byDate = {};
      for (DateTime d = start; !d.isAfter(end); d = d.add(const Duration(days: 1))) {
        final t = DateFormat('yyyy-MM-dd').format(d);

        final bool isLastDay = d.year == end.year && d.month == end.month && d.day == end.day;
        final int sewaHari   = (_mode == InputMode.periode) ? (isLastDay ? totalSewa   : 0) : totalSewa;
        final int servisHari = (_mode == InputMode.periode) ? (isLastDay ? totalServis : 0) : totalServis;
        final int lainHari   = (_mode == InputMode.periode) ? (isLastDay ? totalLain   : 0) : totalLain;
        final String jenisHari = (_mode == InputMode.periode)
            ? (isLastDay ? labelsLain : '')
            : labelsLain;

        final num penjualan  = omzet[t] ?? 0;
        final num hppHarian  = hpp[t] ?? 0;
        final num bebanUsaha = bu[t] ?? 0;
        final num labaKotor  = penjualan - hppHarian;
        final num totalLB    = labaKotor - bebanUsaha - sewaHari - servisHari - lainHari;

        byDate[t] = {
          'id_usaha': idUsaha,
          'tanggal': t,
          'penjualan': penjualan,
          'beban_pokok_penjualan': hppHarian,
          'laba_kotor': labaKotor,
          'beban_usaha': bebanUsaha,
          'sewa_penyusutan': sewaHari,
          'servis_kantor': servisHari,
          'nilai_biaya_lain': lainHari,
          'biaya_lain': jenisHari,
          'total_laba_bersih': totalLB,
          'updated_at': DateTime.now().toIso8601String(),
        };
      }
      final batch = byDate.values.toList(growable: false);

      await supabase
          .from('laba_bersih')
          .delete()
          .eq('id_usaha', idUsaha!)
          .gte('tanggal', tStart)
          .lte('tanggal', tEnd);

      await supabase.from('laba_bersih').insert(batch);

      await showTopToast(
        context,
        "Tersimpan untuk ${batch.length} hari",
        icon: Icons.check_circle_rounded,
      );
      _markClean();
    } on PostgrestException catch (e) {
      await showTopToast(
        context,
        "Gagal menyimpan (DB): ${e.message}",
        icon: Icons.warning_amber_rounded,
        duration: const Duration(seconds: 4),
      );
    } catch (e) {
      await showTopToast(
        context,
        "Gagal menyimpan: $e",
        icon: Icons.warning_amber_rounded,
        duration: const Duration(seconds: 4),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ================== UI ==================
  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(bodyColor: Colors.black87, displayColor: Colors.black87),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    final scaffold = Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      drawer: usahaDrawer(idUsaha: idUsaha, active: 'lb', onConfirmLeaveIfDirty: _confirmLeaveIfDirty),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text('Penetapan Laba Bersih', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: AppBackground(
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, c) {
              return SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _section(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          LayoutBuilder(
                            builder: (context, c) {
                              final compact = c.maxWidth < 720;
                              if (compact) {
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('Mode Input', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        _lihatLaporanButton(),
                                        const SizedBox(width: 8),
                                        _modeToggle(),
                                      ],
                                    ),
                                  ],
                                );
                              }
                              return Row(
                                children: [
                                  const Text('Mode Input', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                  const Spacer(),
                                  _lihatLaporanButton(),
                                  const SizedBox(width: 8),
                                  _modeToggle(),
                                ],
                              );
                            },
                          ),
                          const SizedBox(height: 12),
                          _datesRowWide(),
                          if (_mode == InputMode.periode && _datesReady) ...[
                            const SizedBox(height: 10),
                            _periodePreviewCard(),
                          ],
                          const SizedBox(height: 12),
                          _saveFooterButton(),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    _infoCard("Penjualan", _cur(totalPenjualan), Icons.trending_up),
                    _infoCard("Beban Pokok Penjualan (HPP)", _cur(totalHPP), Icons.shopping_cart),
                    _infoCard("Laba Kotor", _cur(labaKotor), Icons.bar_chart),
                    _infoCard("Beban Usaha", _cur(totalBebanUsaha), Icons.scale),

                    const SizedBox(height: 16),
                    const Divider(),
                    const SizedBox(height: 12),

                    const Text("Biaya Lain-Lain", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    const SizedBox(height: 12),

                    ...List.generate(_items.length, (i) => _biayaRow(i, _items[i])),
                    const SizedBox(height: 10),

                    Align(
                      alignment: Alignment.centerRight,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          setState(() {
                            final it = _BiayaItem(jenis: _JenisBiaya.lainnya);
                            _items.add(it);
                            _watchItem(it);
                          });
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('Tambah Biaya'),
                        style: OutlinedButton.styleFrom(
                          shape: const StadiumBorder(),
                          side: const BorderSide(color: Colors.black, width: 1),
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black,
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),
                    _infoCard("Laba Bersih", _cur(labaBersih), Icons.star, highlight: true),
                    const SizedBox(height: 24),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: ValueListenableBuilder<bool>(
          valueListenable: _dirty,
          builder: (context, isDirty, child) {
            return PopScope(
              canPop: false,
              onPopInvoked: (didPop) async {
                if (didPop) return;

                final ok = await _confirmLeaveIfDirty();
                if (!ok) return;

                // Jika masih ada route di atas kita -> pop.
                if (Navigator.of(context).canPop()) {
                  Navigator.of(context).pop();
                } else {
                  // Kita di root; benar-benar keluar app.
                  SystemNavigator.pop();
                }
              },
              child: child!,
            );
          },
          child: scaffold,
        ),
      ),
    );
  }

  // ====== ROW BIAYA ======
  Widget _biayaRow(int index, _BiayaItem item) {
    Future<void> _handleDelete() async {
      // label yang enak dibaca di dialog
      final jenisLabel = item.jenis == _JenisBiaya.lainnya
          ? (item.nama.isNotEmpty ? 'Biaya "${item.nama}"' : 'Biaya Lainnya')
          : item.labelJenis;

      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text('Hapus $jenisLabel?'),
          content: const Text('Baris biaya ini akan dihapus dari formulir. Lanjutkan?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
          ],
        ),
      ) ?? false;

      if (!ok) return;

      setState(() {
        final removed = _items.removeAt(index);
        _unwatchItem(removed);
        removed.dispose();
      });

      // Tandai dirty hanya jika masih ada draft bermakna
      if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.black.withOpacity(.12)),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 8, offset: const Offset(0, 4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<_JenisBiaya>(
                  value: item.jenis,
                  decoration: InputDecoration(
                    labelText: "Pilih Jenis Biaya",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  ),
                  items: const [
                    DropdownMenuItem(value: _JenisBiaya.sewa,   child: Text("Sewa & Penyusutan")),
                    DropdownMenuItem(value: _JenisBiaya.servis, child: Text("Servis Kantor")),
                    DropdownMenuItem(value: _JenisBiaya.lainnya, child: Text("Lainnya")),
                  ],
                  onChanged: (val) {
                    if (val == null) return;
                    setState(() { item.jenis = val; });
                    // Ubah jenis saja tidak menandai dirty kecuali ada isi bermakna
                    if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
                  },
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                tooltip: 'Hapus baris',
                onPressed: _handleDelete,
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (item.jenis == _JenisBiaya.lainnya) ...[
            TextField(
              controller: item.namaCtrl,
              decoration: InputDecoration(
                hintText: "Nama biaya (misal: Sewa Tempat, Air, Parkir)",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
              onChanged: (_) {
                setState(() {});
                if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
              },
            ),
            const SizedBox(height: 10),
          ],
          _buildMoneyField('Nominal', item.nominalCtrl),
        ],
      ),
    );
  }

  // ================== UI small widgets ==================
  Widget _section({required Widget child}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.55),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.black.withOpacity(0.05)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: child,
    );
  }

  Widget _modeToggle() {
    return SegmentedButton<InputMode>(
      segments: const [
        ButtonSegment(value: InputMode.harian, label: Text('Harian'), icon: Icon(Icons.today)),
        ButtonSegment(value: InputMode.periode, label: Text('Periode'), icon: Icon(Icons.date_range)),
      ],
      selected: {_mode},
      onSelectionChanged: (s) async {
        final next = s.first;
        if (next == _mode) return;
        setState(() => _mode = next);
        _resetTotals();
        if (_mode == InputMode.harian) {
          await _loadFixedCostForStartDate();
        } else {
          _resetBiayaItems();
        }
        _markClean();
      },
      showSelectedIcon: false,
      style: ButtonStyle(
        padding: MaterialStateProperty.all(const EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
      ),
    );
  }

  Widget _datesRowWide() {
    return Row(
      children: [
        Expanded(
          child: _datePill(
            label: _mode == InputMode.harian ? 'Tanggal' : 'Tanggal Awal',
            date: _startDate,
            onTap: _pickStartDate,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Opacity(
            opacity: _mode == InputMode.periode ? 1 : .4,
            child: IgnorePointer(
              ignoring: _mode == InputMode.harian,
              child: _datePill(
                label: 'Tanggal Akhir',
                date: _endDate,
                onTap: _pickEndDate,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        SizedBox(
          height: 36,
          child: ElevatedButton(
            onPressed: _canRun ? _runFetch : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD5F5DD),
              foregroundColor: const Color(0xFF166534),
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              padding: const EdgeInsets.symmetric(horizontal: 14),
            ),
            child: const Text('Tampilkan'),
          ),
        ),
      ],
    );
  }

  Widget _datePill({required String label, required DateTime? date, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(12),
          color: Colors.white.withOpacity(0.8),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today_rounded, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  Text(
                    date == null ? "Pilih tanggal" : DateFormat('dd MMM yyyy', 'id_ID').format(date),
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _periodePreviewCard() {
    final s = DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
    final e = DateTime(_endDate!.year, _endDate!.month, _endDate!.day);
    final days = e.difference(s).inDays + 1;

    final totalSewa = _sumSewa;
    final totalServ = _sumServis;
    final totalLain = _sumLain;

    final perSewa = days > 0 ? totalSewa ~/ days : 0;
    final perServ = days > 0 ? totalServ ~/ days : 0;
    final perLain = days > 0 ? totalLain ~/ days : 0;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black.withOpacity(.06)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Rentang: ${DateFormat('d MMM yyyy', 'id_ID').format(s)} — ${DateFormat('d MMM yyyy', 'id_ID').format(e)} • '
                  '$days hari • Estimasi per-hari: Sewa ${_cur(perSewa)}, Servis ${_cur(perServ)}, Lain ${_cur(perLain)}',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle_rounded,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    if (!(context as Element).mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(duration, () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });
        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(
            scale: Tween<double>(begin: .92, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  Widget _infoCard(String label, String value, IconData icon, {bool highlight = false}) {
    Color accent;
    if (label.startsWith('Penjualan') || label.startsWith('Laba Bersih')) {
      accent = const Color(0xFF16A34A);
    } else if (label.startsWith('Beban Usaha')) {
      accent = const Color(0xFFDC2626);
    } else if (label.startsWith('Beban Pokok')) {
      accent = const Color(0xFF2563EB);
    } else if (label.startsWith('Laba Kotor')) {
      accent = const Color(0xFFF59E0B);
    } else {
      accent = Colors.black87;
    }
    final bg = highlight ? const Color(0xFFEFFBEF) : Colors.white;
    final chipBg = accent.withOpacity(.10);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 10, offset: const Offset(0, 6))],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                height: 36,
                width: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: chipBg, borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, color: accent, size: 20),
              ),
              const SizedBox(width: 12),
              Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ],
          ),
          Text(value, style: TextStyle(fontWeight: FontWeight.w800, color: accent)),
        ],
      ),
    );
  }

  Widget _buildMoneyField(String label, TextEditingController controller) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      inputFormatters: [ThousandsSeparatorInputFormatter()],
      onTap: () => controller.selection = TextSelection(baseOffset: 0, extentOffset: controller.text.length),
      decoration: InputDecoration(
        label: Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6)),
          child: Text(label, style: const TextStyle(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.w600)),
        ),
        floatingLabelBehavior: FloatingLabelBehavior.auto,
        isDense: true,
        hintText: '0',
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(30)),
          borderSide: BorderSide(color: Colors.black, width: 1.2),
        ),
        prefix: const Padding(
          padding: EdgeInsets.only(right: 6),
          child: Text('Rp', style: TextStyle(fontWeight: FontWeight.w800)),
        ),
      ),
      onChanged: (_) {
        setState(() {});
        if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
      },
    );
  }
}

// Unsaved changes enum (shared)
enum _DiscardAction { cancel, save, discard }
