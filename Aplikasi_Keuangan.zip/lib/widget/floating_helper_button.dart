import 'package:flutter/material.dart';
import 'package:ok_oce/pages/helper_page.dart';

class FloatingHelperButton extends StatelessWidget {
  final List<HelperItem> items;
  final String pageTitle;
  final EdgeInsets margin;
  const FloatingHelperButton({
    super.key,
    required this.items,
    this.pageTitle = 'Panduan Penggunaan Aplikasi',
    this.margin = const EdgeInsets.only(right: 6, bottom: 6),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: GestureDetector(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => HelperPage(items: items, pageTitle: pageTitle),
            ),
          );
        },
        child: Material(
          color: Colors.transparent,
          elevation: 8,
          shape: const CircleBorder(),
          child: Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFFD54F), Color(0xFFFFF59D)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(color: Color(0xFF8E101A), width: 6),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.18),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: const Center(
              child: Text(
                '?',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: Colors.black87,
                  height: 1,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
