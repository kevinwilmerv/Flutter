import 'dart:async';
import 'package:flutter/material.dart';

enum NoticeType { success, info, warning, error }

// ==== Helpers (boleh override durasi) ====
// Catatan: duration di sini nullable, tapi kita kirim ke show sebagai non-null
void notifySuccess(BuildContext context, String title, String msg, {Duration? duration}) {
  PopNotifier.I.show(
    context,
    title: title,
    message: msg,
    type: NoticeType.success,
    duration: duration ?? const Duration(seconds: 2),
  );
}

void notifyInfo(BuildContext context, String title, String msg, {Duration? duration}) {
  PopNotifier.I.show(
    context,
    title: title,
    message: msg,
    type: NoticeType.info,
    duration: duration ?? const Duration(seconds: 2),
  );
}

void notifyWarn(BuildContext context, String title, String msg, {Duration? duration}) {
  PopNotifier.I.show(
    context,
    title: title,
    message: msg,
    type: NoticeType.warning,
    duration: duration ?? const Duration(seconds: 2),
  );
}

void notifyError(BuildContext context, String title, String msg, {Duration? duration}) {
  PopNotifier.I.show(
    context,
    title: title,
    message: msg,
    type: NoticeType.error,
    duration: duration ?? const Duration(seconds: 2),
  );
}

/// Toast overlay ala InputBahanPokok:
/// - posisi dekat top (safe area), center
/// - container hitam (#000, 87% opa), text putih bold
/// - icon putih kecil, rounded 12, shadow halus
/// - animasi Fade + Scale (easeOutBack)
/// - tap untuk dismiss
class PopNotifier {
  PopNotifier._();
  static final PopNotifier I = PopNotifier._();

  final List<_NoticeJob> _queue = [];
  bool _isShowing = false;

  Future<void> show(
      BuildContext context, {
        String? title,
        required String message,
        NoticeType type = NoticeType.success,
        Duration duration = const Duration(seconds: 3),
      }) async {
    _queue.add(_NoticeJob(context, title, message, type, duration));
    if (!_isShowing) _dequeue();
  }

  void _dequeue() async {
    if (_queue.isEmpty) {
      _isShowing = false;
      return;
    }
    _isShowing = true;
    final job = _queue.removeAt(0);
    await _showOne(job);
    _dequeue();
  }

  Future<void> _showOne(_NoticeJob job) async {
    final ctx = job.context;
    final overlay = Overlay.of(ctx);
    if (overlay == null) return;

    // animasi: fade + scale (seperti di page referensi)
    final controller = AnimationController(
      vsync: Navigator.of(ctx),
      duration: const Duration(milliseconds: 220),
      reverseDuration: const Duration(milliseconds: 160),
    );
    final fade   = CurvedAnimation(parent: controller, curve: Curves.easeOut, reverseCurve: Curves.easeIn);
    final scale  = Tween<double>(begin: .92, end: 1).animate(
      CurvedAnimation(parent: controller, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn),
    );

    final tapClose = Completer<void>();

    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) {
        final media = MediaQuery.of(ctx);
        final isPhone = media.size.width < 600;
        final double maxW = isPhone ? media.size.width - 24 : 440;

        final _ToastStyle s = _toastStyle(job.type);

        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92), // dekat top, mirip ref page
            child: Material(
              color: Colors.transparent,
              child: FadeTransition(
                opacity: fade,
                child: ScaleTransition(
                  scale: scale,
                  child: GestureDetector(
                    onTap: () {
                      if (!tapClose.isCompleted) tapClose.complete();
                    },
                    child: Container(
                      width: maxW,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: s.bg, // hitam 87%
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: const [
                          BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4)),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(s.icon, color: s.fg, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (job.title != null && job.title!.trim().isNotEmpty)
                                  Text(
                                    job.title!,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: s.fg,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                if (job.title != null && job.title!.trim().isNotEmpty)
                                  const SizedBox(height: 2),
                                Text(
                                  job.message,
                                  style: TextStyle(
                                    color: s.fg,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13.5,
                                    height: 1.25,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );

    overlay.insert(entry);
    await controller.forward();

    // tunggu timeout atau tap
    await Future.any([
      Future.delayed(job.duration),
      tapClose.future,
    ]);

    if (controller.status != AnimationStatus.dismissed) {
      try { await controller.reverse(); } catch (_) {}
    }
    try { entry.remove(); } catch (_) {}
    controller.dispose();
  }

  // Gaya “satu tema hitam” – icon beda per type (seperti konsep referensi)
  _ToastStyle _toastStyle(NoticeType t) {
    const bg = Colors.black87;
    const fg = Colors.white;
    switch (t) {
      case NoticeType.success: return const _ToastStyle(bg: bg, fg: fg, icon: Icons.check_circle);
      case NoticeType.info:    return const _ToastStyle(bg: bg, fg: fg, icon: Icons.info_rounded);
      case NoticeType.warning: return const _ToastStyle(bg: bg, fg: fg, icon: Icons.warning_amber_rounded);
      case NoticeType.error:   return const _ToastStyle(bg: bg, fg: fg, icon: Icons.cancel_rounded);
    }
  }
}

class _ToastStyle {
  final Color bg;
  final Color fg;
  final IconData icon;
  const _ToastStyle({required this.bg, required this.fg, required this.icon});
}

class _NoticeJob {
  final BuildContext context;
  final String? title;
  final String message;
  final NoticeType type;
  final Duration duration;
  _NoticeJob(this.context, this.title, this.message, this.type, this.duration);
}
