import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/InputIncomeMato.dart';
import 'package:ok_oce/InputPBP.dart';
import 'package:ok_oce/InputTransaksiPage.dart';
import 'package:ok_oce/log_page.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/feedbackPage.dart';
import 'package:ok_oce/InputBahanPokokPage.dart';

class usahaDrawer extends StatefulWidget {
  final String? idUsaha;   // lebih baik DI-PASS dari page pemanggil
  final String? namausaha; // untuk header awal (fallback)
  /// 'home' | 'bbp' | 'pbp' | 'trx' | 'lb' | 'mato' | 'ps' | 'log' | 'feedback'
  final String? active;

  // [ADD] Guard opsional: dipanggil sebelum navigasi
  final Future<bool> Function()? onConfirmLeaveIfDirty;

  const usahaDrawer({
    super.key,
    this.idUsaha,
    this.namausaha,
    this.active,
    this.onConfirmLeaveIfDirty, // [ADD]
  });

  @override
  State<usahaDrawer> createState() => _usahaDrawerState();
}

class _usahaDrawerState extends State<usahaDrawer> {
  final _sp = Supabase.instance.client;
  final _log = LogService();

  String? _idUsaha;
  String? _namausahaDb;
  String? _lokasiusahaDb;
  String? _userEmail;

  String? _active; // highlight lokal

  // editor
  final _namaCtrl = TextEditingController();
  final _lokasiCtrl = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _active = widget.active;
    _userEmail = _sp.auth.currentUser?.email;
    _bootstrap();
  }

  @override
  void dispose() {
    _namaCtrl.dispose();
    _lokasiCtrl.dispose();
    super.dispose();
  }

  Future<void> _bootstrap() async {
    // 1) pastikan id_usaha
    String? id = widget.idUsaha;
    final user = _sp.auth.currentUser;
    if ((id == null || id.isEmpty) && user != null) {
      final prof = await _sp
          .from('profiles')
          .select('id_usaha')
          .eq('id', user.id)
          .maybeSingle();
      id = prof?['id_usaha']?.toString();
    }
    if (!mounted) return;
    setState(() => _idUsaha = id);

    // 2) tarik nama & lokasi
    if (id != null && id.isNotEmpty) {
      await _loadUsaha(id);
    } else {
      if (!mounted) return;
      setState(() {
        _namausahaDb = widget.namausaha;
        _lokasiusahaDb = null;
        _namaCtrl.text = _namausahaDb ?? '';
        _lokasiCtrl.text = _lokasiusahaDb ?? '';
      });
    }
  }

  Future<void> _loadUsaha(String idUsaha) async {
    try {
      final row = await _sp
          .from('usaha')
          .select('nama_usaha, lokasi')
          .eq('id_usaha', idUsaha)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        _namausahaDb = (row?['nama_usaha'] as String?)?.trim();
        _lokasiusahaDb = (row?['lokasi'] as String?)?.trim();
        _namaCtrl.text = _namausahaDb ?? widget.namausaha ?? '';
        _lokasiCtrl.text = _lokasiusahaDb ?? '';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _namausahaDb = widget.namausaha;
        _lokasiusahaDb = null;
        _namaCtrl.text = _namausahaDb ?? '';
      });
    }
  }

  // [CHG] Navigasi dilindungi guard (kalau ada)
  Future<void> _navigate(String key, Future<void> Function() go) async {
    // Panggil guard jika tersedia
    if (widget.onConfirmLeaveIfDirty != null) {
      final ok = await widget.onConfirmLeaveIfDirty!();
      if (!ok) return; // batal navigasi
    }
    setState(() => _active = key);
    Navigator.pop(context); // tutup drawer
    await Future.delayed(const Duration(milliseconds: 150));
    if (!mounted) return;
    await go(); // lanjut navigasi
  }

  // selalu balik ke dashboard (route tunggal '/dashboard')
  void _goDashboard(String id) {
    Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
      '/dashboard',
          (route) => false,
      arguments: {'idUsaha': id, 'namausaha': _namausahaDb ?? widget.namausaha},
    );
  }

  Future<void> _showEditNamausahaDialog() async {
    _namaCtrl.text = _namausahaDb ?? widget.namausaha ?? '';
    _lokasiCtrl.text = _lokasiusahaDb ?? '';
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Ubah nama & lokasi usaha *',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 14),
                TextField(
                  controller: _namaCtrl,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    hintText: 'NAMA USAHA',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _lokasiCtrl,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: 'LOKASI (mis. ANCOL)',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                  onSubmitted: (_) => _saveNama(setLocal),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saving ? null : () => _saveNama(setLocal),
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                    child: _saving
                        ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('Simpan'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _saveNama(void Function(void Function()) setLocal) async {
    final id = _idUsaha;
    final nama = _namaCtrl.text.trim();
    final lokasi = _lokasiCtrl.text.trim();
    if (id == null || id.isEmpty) return;

    if (nama.isEmpty || lokasi.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nama usaha dan lokasi tidak boleh kosong')),
      );
      return;
    }

    try {
      setLocal(() => _saving = true);
      await _sp.from('usaha').update({
        'nama_usaha': nama,
        'lokasi': lokasi,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id_usaha', id);

      if (!mounted) return;
      setState(() {
        _namausahaDb = nama;
        _lokasiusahaDb = lokasi;
      });

      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nama & lokasi usaha diperbarui')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal menyimpan: $e')));
    } finally {
      setLocal(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final namaUsaha = ((_namausahaDb ?? widget.namausaha) ?? 'usaha').toUpperCase();
    final lokasi = (_lokasiusahaDb ?? '—').toUpperCase();
    final idUsaha = _idUsaha; // bisa null di frame awal
    final active = _active ?? widget.active ?? '';

    // Paksa skema light hanya untuk Drawer ini
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      listTileTheme: const ListTileThemeData(
          iconColor: Colors.black87, textColor: Colors.black87),
      dialogTheme: base.dialogTheme.copyWith(
        backgroundColor: Colors.white,
        titleTextStyle: const TextStyle(
            color: Colors.black87, fontSize: 18, fontWeight: FontWeight.w700),
        contentTextStyle: const TextStyle(color: Colors.black87),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              _FancyDrawerHeader(
                namaUsaha: namaUsaha,
                email: _userEmail ?? 'Email tidak tersedia',
                role: 'ADMIN USAHA',
                usaha: lokasi,
                photoUrl: _sp.auth.currentUser?.userMetadata?['avatar_url'],
                onTapEditUsaha: () {
                  Navigator.pop(context);
                  _showEditNamausahaDialog();
                },
                onTapSettings: () async {
                  // [OPT] guard juga saat buka settings
                  if (widget.onConfirmLeaveIfDirty != null) {
                    final ok = await widget.onConfirmLeaveIfDirty!();
                    if (!ok) return;
                  }
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/settings');
                },
              ),

              const SizedBox(height: 6),

              _DrawerItem(
                icon: Icons.home_rounded,
                label: 'Beranda',
                active: active == 'home',
                onTap: () {
                  final id = idUsaha;
                  if (id == null) return;
                  _navigate('home', () async => _goDashboard(id));
                },
              ),
              _DrawerItem(
                icon: Icons.payments_rounded,
                label: 'Input Beban Pokok Penjualan',
                active: active == 'bbp',
                onTap: () {
                  final id = idUsaha;
                  if (id == null || id.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('ID usaha belum siap. Coba lagi.')),
                    );
                    return;
                  }
                  _navigate('bbp', () async {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => InputBahanPokokPage(usahaId: id)),
                    );
                  });
                },
              ),
              _DrawerItem(
                icon: Icons.inventory_2_rounded,
                label: 'Input Persedian Bahan Pokok',
                active: active == 'pbp',
                onTap: () {
                  final id = idUsaha;
                  if (id == null) return;
                  _navigate('pbp', () async {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => InputPBP(idUsaha: id),
                    ));
                  });
                },
              ),
              _DrawerItem(
                icon: Icons.receipt_long_rounded,
                label: 'Input Penjualan & Beban Usaha',
                active: active == 'trx',
                onTap: () {
                  final id = idUsaha;
                  if (id == null) return;
                  _navigate('trx', () async {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => InputTransaksiPage(usahaId: id),
                    ));
                  });
                },
              ),
              _DrawerItem(
                icon: Icons.insights_rounded,
                label: 'Penetapan Laba Bersih',
                active: active == 'lb',
                onTap: () {
                  final id = idUsaha;
                  if (id == null) return;
                  _navigate('lb', () async {
                    Navigator.of(context).pushNamed(
                      '/input-laba',
                      arguments: {'idUsaha': id, 'tanggal': DateTime.now()},
                    );
                  });
                },
              ),
              _DrawerItem(
                icon: Icons.inventory_2_rounded,
                label: 'Update Income Per Mato',
                active: active == 'mato',
                onTap: () {
                  final id = idUsaha;
                  if (id == null) return;
                  _navigate('mato', () async {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => InputIncomeMato(idUsaha: id),
                    ));
                  });
                },
              ),

              const Divider(height: 24, indent: 16, endIndent: 16),

              _DrawerItem(
                icon: Icons.history_rounded,
                label: 'Log Aktivitas',
                active: active == 'log',
                onTap: () => _navigate('log', () async {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const LogPage()),
                  );
                }),
              ),
              _DrawerItem(
                icon: Icons.feedback_rounded,
                label: 'Kirim Feedback',
                active: active == 'feedback',
                onTap: () {
                  final id = idUsaha;
                  if (id == null) return;
                  _navigate('feedback', () async {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => FeedbackPage(idUsaha: id),
                    ));
                  });
                },
              ),

              const SizedBox(height: 8),

              _DrawerItem(
                icon: Icons.logout_rounded,
                label: 'Keluar',
                danger: true,
                onTap: () async {
                  // [OPT] Guard juga saat logout supaya tidak kehilangan perubahan
                  if (widget.onConfirmLeaveIfDirty != null) {
                    final ok = await widget.onConfirmLeaveIfDirty!();
                    if (!ok) return;
                  }

                  final user = _sp.auth.currentUser;
                  if (user != null) {
                    final userData = await _sp
                        .from('profiles')
                        .select('nama, role')
                        .eq('id', user.id)
                        .maybeSingle();
                    if (userData != null) {
                      await _log.addLog(
                        aktivitas: "Logout",
                        halaman: "Auth",
                        detail: "User ${userData['nama']} (${userData['role']}) melakukan logout",
                      );
                    }
                  }
                  await _sp.auth.signOut();
                  if (!mounted) return;
                  Navigator.of(context, rootNavigator: true)
                      .pushNamedAndRemoveUntil('/login', (r) => false);
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
/// ===== Header & item =====

class _FancyDrawerHeader extends StatelessWidget {
  final String namaUsaha;
  final String email;
  final String role;
  final String usaha;
  final String? photoUrl;
  final VoidCallback? onTapEditUsaha;
  final VoidCallback? onTapSettings;

  const _FancyDrawerHeader({
    required this.namaUsaha,
    required this.email,
    required this.role,
    required this.usaha,
    this.photoUrl,
    this.onTapEditUsaha,
    this.onTapSettings,
  });

  String _initialsFrom(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    final first = parts.isNotEmpty && parts.first.isNotEmpty ? parts.first[0] : 'U';
    final last  = parts.length > 1 && parts.last.isNotEmpty ? parts.last[0] : '';
    return (first + last).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(24),
        bottomRight: Radius.circular(24),
      ),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFC1CC), Colors.white],
          ),
        ),
        padding: EdgeInsets.fromLTRB(16, top + 16, 12, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: const Color(0xFF2D2D2D),
                  backgroundImage:
                  (photoUrl != null && photoUrl!.isNotEmpty) ? NetworkImage(photoUrl!) : null,
                  child: (photoUrl == null || photoUrl!.isEmpty)
                      ? Text(
                    _initialsFrom(namaUsaha),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                    ),
                  )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              namaUsaha,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                letterSpacing: .2,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            onTap: onTapEditUsaha,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(Icons.edit, size: 18),
                            ),
                          ),
                          const SizedBox(width: 4),
                          InkWell(
                            onTap: onTapSettings,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(Icons.settings, size: 18),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.black54, fontSize: 12.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _badge(role, color: const Color(0xFF22313F)),
                  const SizedBox(width: 8),
                  InkWell(
                    onTap: onTapEditUsaha,
                    borderRadius: BorderRadius.circular(999),
                    child: _chip(icon: Icons.location_on_rounded, label: usaha),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.55),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black.withOpacity(0.06)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: const [
                  Icon(Icons.verified_user, size: 16, color: Colors.black87),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Akun aktif – akses admin',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, {required Color color}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(999)),
    child: Text(
      text,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 12,
        fontWeight: FontWeight.w700,
        letterSpacing: .3,
      ),
    ),
  );

  Widget _chip({required IconData icon, required String label}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(999),
      border: Border.all(color: Colors.black.withOpacity(0.10)),
      boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: Offset(0, 3)),
      ],
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: Colors.black87),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, letterSpacing: .2)),
      ],
    ),
  );
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final bool danger;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = active ? const Color(0xFFFFE4E9) : Colors.white;
    final fg = danger ? Colors.red : Colors.black87;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        elevation: active ? 2 : 0,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(icon, color: danger ? Colors.red : Colors.black87),
                const SizedBox(width: 12),
                Expanded(child: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: fg))),
                Icon(Icons.chevron_right_rounded, color: danger ? Colors.red : Colors.black38),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
