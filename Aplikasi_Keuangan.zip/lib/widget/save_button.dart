import 'package:flutter/material.dart';

/// Style global tombol simpan (pakai warna dari InputBahanPokokPage)
final ButtonStyle saveButtonStyle = ElevatedButton.styleFrom(
  backgroundColor: const Color(0xFF1F2937), // warna sama persis dengan di InputBahanPokokPage
  foregroundColor: Colors.white,            // teks dan icon putih
  minimumSize: const Size.fromHeight(50),   // tinggi tombol
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(30), // radius sisi tombol
  ),
);

/// Widget siap pakai: SaveButton
class SaveButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String label;
  final IconData icon;
  final EdgeInsetsGeometry padding;

  const SaveButton({
    super.key,
    required this.onPressed,
    this.label = 'Simpan',
    this.icon = Icons.save,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 22),
        label: Text(
          label,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        style: saveButtonStyle,
      ),
    );
  }
}
