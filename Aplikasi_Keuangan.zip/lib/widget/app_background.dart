import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class AppBackground extends StatelessWidget {
  final Widget child;
  final bool overlayLight;     // true = overlay putih tipis, false = overlay hitam tipis
  final double overlayOpacity; // 0.0 - 1.0
  final bool showBrandGradient;

  const AppBackground({
    super.key,
    required this.child,
    this.overlayLight = false,
    this.overlayOpacity = 0.28,
    this.showBrandGradient = true,
  });

  // Pilih asset berdasarkan jenis layar & rasio
  String _pickAsset(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final ratio = size.width / size.height;
    final shortest = size.shortestSide;

    final isTablet = shortest >= 600;     // breakpoint tablet umum
    final isDesktop = kIsWeb || size.width >= 1000;

    // Kalau sangat lebar (landscape wide), pakai versi 16:9
    if (isDesktop || ratio >= 1.6) {
      return 'assets/wallpaper_desktop_2560x1440.jpg';
    }
    if (isTablet) {
      return 'assets/wallpaper_tablet_2048x2732.jpg';
    }
    return 'assets/wallpaper_phone_1440x3200.jpg';
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final dpr  = MediaQuery.of(context).devicePixelRatio;
    final asset = _pickAsset(context);

    // Decode tidak perlu sebesar aslinya → hemat RAM
    final decodeWidth = (size.width * dpr).round();

    return Stack(
      fit: StackFit.expand,
      children: [
        // Gradient brand + wallpaper
        Container(
          decoration: BoxDecoration(
            gradient: showBrandGradient
                ? const LinearGradient(
              colors: [Color(0xFFFFD1D1), Colors.white],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            )
                : null,
            image: DecorationImage(
              // ResizeImage mengatur cacheWidth supaya decode pas layar
              image: ResizeImage(AssetImage(asset), width: decodeWidth),
              fit: BoxFit.cover,
              alignment: Alignment.center,
              filterQuality: FilterQuality.low,
            ),
          ),
        ),
        // Overlay/scrim agar teks-ikon tetap kebaca
        if (overlayOpacity > 0)
          Container(
            color: (overlayLight ? Colors.white : Colors.black)
                .withOpacity(overlayOpacity),
          ),
        child,
      ],
    );
  }

  /// Opsional: panggil sekali saat halaman dibuka supaya mulus
  static Future<void> precacheAll(BuildContext context) async {
    final dpr  = MediaQuery.of(context).devicePixelRatio;
    final w    = MediaQuery.of(context).size.width;
    final cw   = (w * dpr).round();
    final providers = [
      ResizeImage(const AssetImage('assets/wallpaper_phone_1440x3200.jpg'), width: cw),
      ResizeImage(const AssetImage('assets/wallpaper_tablet_2048x2732.jpg'), width: cw),
      ResizeImage(const AssetImage('assets/wallpaper_desktop_2560x1440.jpg'), width: cw),
    ];
    for (final p in providers) {
      await precacheImage(p, context);
    }
  }
}
