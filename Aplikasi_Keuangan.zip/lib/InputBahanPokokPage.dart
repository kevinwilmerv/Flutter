import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/usaha_drawer.dart';
import 'package:ok_oce/widget/app_background.dart';

enum _DiscardAction { cancel, save, discard }

class InputBahanPokokPage extends StatefulWidget {
  final String usahaId; // <- id usaha dari halaman pemanggil
  const InputBahanPokokPage({super.key, required this.usahaId});

  @override
  State<InputBahanPokokPage> createState() => _InputBahanPokokPageState();
}

class _InputBahanPokokPageState extends State<InputBahanPokokPage> {
  final logService = LogService();

  bool _saving = false;

  // === [ADD] Unsaved changes tracking ===
  final _dirty = ValueNotifier<bool>(false); // true jika ada perubahan belum disimpan
  Timer? _idleReminder;

  void _markDirty() {
    if (!_dirty.value) {
      _dirty.value = true;

      // Tampilkan banner pengingat simpan
      setState(() {
        _topNoticeText = 'Ada perubahan yang belum disimpan. Tekan "Simpan" sebelum keluar.';
        _showTopNotice = true;
      });

      // Pengingat berkala supaya user ingat menekan simpan (setiap 2 menit)
      _idleReminder?.cancel();
      _idleReminder = Timer.periodic(const Duration(minutes: 2), (_) {
        if (mounted && _dirty.value) {
          _showSnackPopup('Perubahan belum disimpan — jangan lupa tekan "Simpan".');
        }
      });
    }
  }

  void _markClean() {
    _dirty.value = false;
    _removeUnsavedBanner();
    _cancelIdleReminder();
  }

  // Helper: pakai di semua aksi yang berpotensi "kehilangan" perubahan (back/ganti tanggal)
  Future<bool> _confirmLeaveIfDirty() async {
    if (!_dirty.value) return true;
    final action = await _confirmDiscardDialog();
    if (action == _DiscardAction.save) {
      await _saveData();
      return true;
    } else if (action == _DiscardAction.discard) {
      return true;
    }
    return false; // cancel
  }

  Future<_DiscardAction> _confirmDiscardDialog() async {
    return await showDialog<_DiscardAction>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text('Perubahan belum disimpan'),
          content: const Text(
            'Kamu sudah mengubah data, tapi belum menekan Simpan. Mau gimana?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, _DiscardAction.cancel),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, _DiscardAction.discard),
              child: const Text('Tinggalkan'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context, _DiscardAction.save),
              icon: const Icon(Icons.save),
              label: const Text('Simpan sekarang'),
            ),
          ],
        );
      },
    ) ?? _DiscardAction.cancel;
  }

  void _removeUnsavedBanner() {
    ScaffoldMessenger.of(context).clearMaterialBanners();
    setState(() {
      _showTopNotice = false;
      _topNoticeText = null;
    });
  }

  void _cancelIdleReminder() {
    _idleReminder?.cancel();
    _idleReminder = null;
  }
  // === [END ADD] ===

  DateTime get _todayDate {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  DateTime _selectedDate = DateTime.now();
  final TextEditingController _jenisController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  // === [ADD] Search UX helpers ===
  Timer? _searchDebounce;
  String _searchText = '';
  int _searchResultCount = 0;

  void _onSearchChanged(String txt) {
    _searchDebounce?.cancel();
    final t = txt.trim();

    // Jika kosong → langsung reset, tanpa debounce
    if (t.isEmpty) {
      _searchText = '';
      _applySearchBehavior(); // langsung collapse semua
      return;
    }

    // Kalau ada isinya → debounce biar halus
    _searchDebounce = Timer(const Duration(milliseconds: 250), () {
      _searchText = t.toLowerCase();
      _applySearchBehavior();
    });
  }

  // === [ADD] Start-of-word matcher (hindari "bayam" saat cari "ayam")
  // Mendukung multi-kata berurutan: "ayam kampung" => \bayam ... \bcampung
  bool _matchStartOfWordSequence(String text, String query) {
    final t = text.toLowerCase();
    final parts = query.trim().toLowerCase().split(RegExp(r'\s+')).where((s) => s.isNotEmpty).toList();
    if (parts.isEmpty) return true;

    final buf = StringBuffer();
    for (var i = 0; i < parts.length; i++) {
      final p = RegExp.escape(parts[i]);
      if (i == 0) {
        buf..write(r'\b')..write(p);
      } else {
        buf..write(r'(?:.*\b')..write(p)..write(')');
      }
    }
    final re = RegExp(buf.toString());
    return re.hasMatch(t);
  }

  bool _isItemMatch(Map<String, TextEditingController> m, String q) {
    return _matchStartOfWordSequence(m['id']!.text, q) ||
        _matchStartOfWordSequence(m['nama']!.text, q);
  }

  // Terapkan efek pencarian: expand yg match, collapse lainnya
  void _applySearchBehavior() {
    final hasQuery = _searchText.isNotEmpty;
    _searchResultCount = 0;

    if (hasQuery) {
      _expanded.clear(); // reset expanded state
      for (final entry in _data.entries) {
        final items = entry.value;
        final matches = items.where((m) => _isItemMatch(m, _searchText)).length;
        if (matches > 0) {
          _expanded.add(entry.key);
          _searchResultCount += matches;
        }
      }
    } else {
      // ✅ Saat search dikosongkan, collapse semua kategori
      _expanded.clear();
      _searchResultCount = 0;
    }

    if (mounted) setState(() {});
  }

  void _autoScrollToFirstMatch() {
    if (_searchText.isEmpty) return;
    for (final entry in _data.entries) {
      final items = entry.value.where((m) => _isItemMatch(m, _searchText)).toList();
      if (items.isNotEmpty) {
        final ctx = _kategoriKeys[entry.key]?.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(
            ctx,
            duration: const Duration(milliseconds: 450),
            curve: Curves.easeOutCubic,
            alignment: 0.04,
          );
        }
        break;
      }
    }
  }
  // === [END ADD] ===

  String get _usahaPrefix {
    final raw = (_idUsahaFromProfile ?? widget.usahaId);
    final only = raw.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();
    return (only.length > 6) ? only.substring(0, 6) : only;
  }

  Map<String, List<Map<String, TextEditingController>>> _data = {};
  Map<String, List<String>> _usedIds = {};
  Map<String, List<String>> _reusableIds = {};
  String get _storageKey =>
      'bahan_pokok_${DateFormat('yyyy-MM-dd').format(_selectedDate)}';

  String? _idUsahaFromProfile;
  RealtimeChannel? _bpChannel;

  String? _topNoticeText;
  bool _showTopNotice = false;

  final Map<String, GlobalKey> _kategoriKeys = {};
  final Set<String> _expanded = {};

  InputDecoration _pillInput({
    String? label,
    String? hint,
    String? prefixText,
    IconData? prefixIcon,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(30),
        borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(30)),
        borderSide: BorderSide(color: Colors.black, width: 1.2),
      ),
      prefixIcon: prefixIcon == null ? null : Icon(prefixIcon),
      prefix: (prefixText == null)
          ? null
          : Padding(
        padding: const EdgeInsets.only(right: 6),
        child: Text(
          ' $prefixText',
          style: const TextStyle(
            fontWeight: FontWeight.w800,
            color: Colors.black87,
          ),
        ),
      ),
    );
  }

  Widget _topBanner() {
    if (!_showTopNotice || (_topNoticeText?.isEmpty ?? true)) {
      return const SizedBox.shrink();
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      child: Padding(
        key: const ValueKey('top-banner'),
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.15),
                blurRadius: 14,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _topNoticeText ?? '',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              IconButton(
                splashRadius: 18,
                onPressed: () => setState(() => _showTopNotice = false),
                icon: const Icon(Icons.close, color: Colors.white70, size: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _addJenis() {
    final jenis = _jenisController.text.trim();
    if (jenis.isEmpty || _data.containsKey(jenis)) return;

    setState(() {
      _data[jenis] = [];
      _usedIds[jenis] = [];
      _reusableIds[jenis] = [];
      _jenisController.clear();
      _expanded.add(jenis);
    });

    _markDirty(); // [ADD] perubahan lokal

    _showSnackPopup('Kategori "$jenis" ditambahkan');

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _kategoriKeys[jenis]?.currentContext;
      if (ctx != null) {
        Scrollable.ensureVisible(
          ctx,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeOutCubic,
          alignment: 0.06,
        );
      }
    });

    logService.addLog(
      aktivitas: 'Tambah Kategori',
      halaman: 'Input Beban Pokok Penjualan',
      detail: 'Kategori $jenis - ${DateFormat('yyyy-MM-dd').format(_selectedDate)}',
    );
  }

  Future<void> _showSnackPopup(String message, {bool isError = false}) async {
    if (!mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(const Duration(milliseconds: 1400), () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });

        final bgColor = isError ? Colors.red.shade700 : Colors.black87;
        final icon = isError ? Icons.error_rounded : Icons.check_circle_rounded;

        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        message,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved = CurvedAnimation(
          parent: anim,
          curve: Curves.easeOutBack,
          reverseCurve: Curves.easeIn,
        );
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(
            scale: Tween<double>(begin: .92, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  Widget _saveHeaderButton() {
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        final targetWidth = (w <= 380)
            ? w
            : (w <= 560)
            ? w * 0.70
            : 420.0;

        return Align(
          alignment: Alignment.centerLeft,
          child: SizedBox(
            width: targetWidth,
            child: FilledButton.icon(
              onPressed: _saving ? null : _saveData,
              icon: _saving
                  ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
                  : const Icon(Icons.save_rounded, size: 18),
              label: const Text(
                'Simpan',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              style: FilledButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                backgroundColor: Colors.black87,
                foregroundColor: Colors.white,
                elevation: 0,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _section({
    required String title,
    Widget? action,
    required Widget child,
  }) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.55),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.05),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: Colors.black87,
                ),
              ),
              const Spacer(),
              if (action != null) action,
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  @override
  void initState() {

    final today = _todayDate;
    if (_selectedDate.isAfter(today)) {
      _selectedDate = today;
    }

    super.initState();
    _loadDataForDate(_selectedDate);
    _fetchUsahaFromUser();
    _onSearchChanged(_searchController.text); // [ADD] sinkron awal search
  }

  @override
  void dispose() {
    _bpChannel?.unsubscribe();
    _jenisController.dispose();
    _searchController.dispose();
    _searchDebounce?.cancel(); // [ADD]
    _cancelIdleReminder(); // [ADD]
    _dirty.dispose(); // [ADD]
    super.dispose();
  }

  final NumberFormat _nf = NumberFormat.decimalPattern('id_ID');

  int _parseInt(String s) {
    if (s.isEmpty) return 0;
    return int.tryParse(s.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
  }

  String _fmtThousands(dynamic v) {
    final n = int.tryParse(
      v?.toString().replaceAll(RegExp(r'[^0-9]'), '') ?? '',
    );
    if (n == null) return '';
    return _nf.format(n);
  }

  Future<void> _fetchUsahaFromUser() async {
    final sp = Supabase.instance.client;
    final user = sp.auth.currentUser;
    if (user == null) return;

    final prof = await sp
        .from('profiles')
        .select('id_usaha')
        .eq('id', user.id)
        .maybeSingle();
    setState(() => _idUsahaFromProfile = prof?['id_usaha']);

    if (_idUsahaFromProfile != null) {
      await _fetchJenisFromDB();
      await _fetchItemTemplatesFromDB();
      _subscribeBahanPokok();
    }
  }

  Future<void> _fetchJenisFromDB() async {
    final sp = Supabase.instance.client;
    final cab = _idUsahaFromProfile;
    if (cab == null) return;

    final rows =
    await sp.from('bahan_pokok').select('jenis').eq('id_usaha', cab).not('jenis', 'is', null);

    final setJenis = <String>{};
    for (final r in rows) {
      final j = (r['jenis'] ?? '').toString().trim();
      if (j.isNotEmpty) setJenis.add(j);
    }
    if (!mounted) return;
    setState(() {
      for (final j in setJenis) {
        _data[j] = _data[j] ?? <Map<String, TextEditingController>>[];
      }
    });
  }

  Future<void> _fetchItemTemplatesFromDB() async {
    final sp = Supabase.instance.client;
    final cab = _idUsahaFromProfile;
    if (cab == null) return;

    final rows = await sp
        .from('bahan_pokok')
        .select('jenis,id_bahan,nama_bahan,satuan')
        .eq('id_usaha', cab);

    if (!mounted) return;
    setState(() {
      for (final r in rows) {
        final jenis = (r['jenis'] ?? '').toString().trim();
        final id = (r['id_bahan'] ?? '').toString().trim();
        final nama = (r['nama_bahan'] ?? '').toString().trim();
        final satuan = (r['satuan'] ?? '').toString().trim();
        if (jenis.isEmpty || id.isEmpty) continue;

        _data[jenis] = _data[jenis] ?? <Map<String, TextEditingController>>[];
        final exists = _data[jenis]!.any((m) => m['id']!.text == id);
        if (!exists) {
          _data[jenis]!.add({
            'id': TextEditingController(text: id),
            'nama': TextEditingController(text: nama),
            'satuan': TextEditingController(text: satuan),
            'jumlah': TextEditingController(),
            'harga': TextEditingController(),
          });
        }
      }
    });
  }

  void _subscribeBahanPokok() {
    final sp = Supabase.instance.client;
    final cab = _idUsahaFromProfile;
    if (cab == null) return;

    _bpChannel?.unsubscribe();
    final ch = sp.channel('bahan_pokok:$cab');

    for (final ev in [
      PostgresChangeEvent.insert,
      PostgresChangeEvent.update,
      PostgresChangeEvent.delete,
    ]) {
      ch.onPostgresChanges(
        event: ev,
        schema: 'public',
        table: 'bahan_pokok',
        filter: PostgresChangeFilter(
          column: 'id_usaha',
          type: PostgresChangeFilterType.eq,
          value: cab,
        ),
        callback: (payload) async {
          await _fetchJenisFromDB();
          await _fetchItemTemplatesFromDB();
        },
      );
    }

    ch.subscribe();
    _bpChannel = ch;
  }

  void _addBarang(String jenis) {
    final id = _generateId(jenis);
    setState(() {
      _data[jenis]!.add({
        'id': TextEditingController(text: id),
        'nama': TextEditingController(),
        'jumlah': TextEditingController(),
        'satuan': TextEditingController(),
        'harga': TextEditingController(),
      });
    });
    _markDirty(); // [ADD]
    logService.addLog(
      aktivitas: 'Tambah Barang',
      halaman: 'Input Beban Pokok Penjualan',
      detail: 'Jenis: $jenis - Tanggal: ${DateFormat('yyyy-MM-dd').format(_selectedDate)}',
    );
  }

  String _generateId(String jenis) {
    String jPrefix;
    final parts = jenis.trim().split(RegExp(r'\s+'));
    if (parts.length == 1) {
      jPrefix = parts[0].toUpperCase().padRight(3, 'X').substring(0, 3);
    } else {
      jPrefix = parts[0][0].toUpperCase() + parts[1][0].toUpperCase() + parts[1].substring(parts[1].length - 1).toUpperCase();
    }

    final base = '$_usahaPrefix-$jPrefix';

    final reusable = _reusableIds[jenis] ?? <String>[];
    final idx = reusable.indexWhere((id) => id.startsWith(base));
    if (idx >= 0) {
      final reused = reusable.removeAt(idx);
      _reusableIds[jenis] = reusable;
      _usedIds[jenis] = [...?_usedIds[jenis], reused];
      return reused;
    }

    final existing = <String>{
      ...?_usedIds[jenis],
      ...?_data[jenis]?.map((m) => m['id']!.text) ?? <String>{},
    };

    final reg = RegExp('^${RegExp.escape(base)}(\\d+)\$');
    int maxNum = 0;
    for (final id in existing) {
      final m = reg.firstMatch(id);
      if (m != null) {
        final n = int.tryParse(m.group(1)!) ?? 0;
        if (n > maxNum) maxNum = n;
      }
    }

    int next = maxNum + 1;
    String newId;
    do {
      newId = '$base${next.toString().padLeft(3, '0')}';
      next++;
    } while (existing.contains(newId));

    _usedIds[jenis] = [...?_usedIds[jenis], newId];
    return newId;
  }

  void _hapusBarang(String jenis, int index) {
    final id = _data[jenis]![index]['id']!.text;
    _reusableIds[jenis]!.add(id);
    _usedIds[jenis]!.remove(id);
    setState(() {
      _data[jenis]![index].values.forEach((e) => e.dispose());
      _data[jenis]!.removeAt(index);
    });
    _markDirty(); // [ADD]
  }

  Future<void> _hapusJenis(String jenis) async {
    final sp = Supabase.instance.client;
    final cab = _idUsahaFromProfile;
    if (cab == null) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text(
          'Hapus Kategori?',
          style: TextStyle(color: Colors.black87),
        ),
        content: Text(
          'Semua item & histori dengan kategori "$jenis" akan dihapus.',
          style: const TextStyle(color: Colors.black87),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    try {
      await sp.rpc(
        'delete_jenis_bahan_pokok',
        params: {'p_id_usaha': cab, 'p_jenis': jenis},
      );

      setState(() {
        _data.remove(jenis);
        _usedIds.remove(jenis);
        _reusableIds.remove(jenis);
      });

      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null) {
        final parsed = Map<String, dynamic>.from(jsonDecode(raw));
        parsed.remove(jenis);
        await prefs.setString(_storageKey, jsonEncode(parsed));
      }

      await _fetchItemTemplatesFromDB();
      _showSnackPopup('Kategori "$jenis" telah dihapus.');
      _markDirty(); // [ADD] (perubahan lokal setelah sinkron)
    } catch (e) {
      _showSnackPopup('Gagal menghapus: $e', isError: true);
    }
  }

  Future<void> _loadDataForDate(DateTime date) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'bahan_pokok_${DateFormat('yyyy-MM-dd').format(date)}';
    final raw = prefs.getString(key);
    final rawUsed = prefs.getString('used_ids_${DateFormat('yyyy-MM-dd').format(date)}');
    final rawReused = prefs.getString('reused_ids_${DateFormat('yyyy-MM-dd').format(date)}');

    _data.clear();
    _usedIds.clear();
    _reusableIds.clear();

    if (raw != null) {
      final parsed = jsonDecode(raw);
      parsed.forEach((jenis, items) {
        _data[jenis] = List<Map<String, TextEditingController>>.from(
          (items as List).map(
                (item) => {
              'id': TextEditingController(text: item['id']),
              'nama': TextEditingController(text: item['nama']),
              'jumlah': TextEditingController(text: item['jumlah']),
              'satuan': TextEditingController(text: item['satuan']),
              'harga': TextEditingController(text: _fmtThousands(item['harga'])),
            },
          ),
        );
      });
    }

    if (rawUsed != null) {
      final parsed = jsonDecode(rawUsed);
      parsed.forEach((jenis, list) => _usedIds[jenis] = List<String>.from(list));
    }
    if (rawReused != null) {
      final parsed = jsonDecode(rawReused);
      parsed.forEach((jenis, list) => _reusableIds[jenis] = List<String>.from(list));
    }

    setState(() {});
    _markClean(); // [ADD] berpindah tanggal = muat state tersimpan => bersih
  }

  Future<void> _saveData() async {
    if (_saving) return; // cegah double tap
    if (_idUsahaFromProfile == null || _idUsahaFromProfile!.isEmpty) {
      _showSnackPopup("Gagal menyimpan: ID usaha belum tersedia. Coba lagi.", isError: true);
      return;
    }

    setState(() => _saving = true); // mulai loading

    final prefs = await SharedPreferences.getInstance();
    final tanggal = DateFormat('yyyy-MM-dd').format(_selectedDate);
    final sp = Supabase.instance.client;

    try {
      final jsonData = _data.map(
            (jenis, items) => MapEntry(
          jenis,
          items
              .map(
                (item) => {
              'id': item['id']!.text,
              'nama': item['nama']!.text,
              'jumlah': item['jumlah']!.text,
              'satuan': item['satuan']!.text,
              'harga': item['harga']!.text,
            },
          )
              .toList(),
        ),
      );
      await prefs.setString(_storageKey, jsonEncode(jsonData));
      await prefs.setString('used_ids_$tanggal', jsonEncode(_usedIds));
      await prefs.setString('reused_ids_$tanggal', jsonEncode(_reusableIds));

      for (var entry in _data.entries) {
        final jenis = entry.key;
        for (var item in entry.value) {
          final jumlah = num.tryParse(item['jumlah']!.text) ?? 0;
          final harga = _parseInt(item['harga']!.text);
          await sp.from('bahan_pokok').upsert({
            'id_usaha': _idUsahaFromProfile,
            'tanggal': tanggal,
            'jenis': jenis,
            'id_bahan': item['id']!.text,
            'nama_bahan': item['nama']!.text,
            'jumlah': jumlah,
            'satuan': item['satuan']!.text,
            'harga': harga,
            'total': jumlah * harga,
          }, onConflict: 'id_usaha,tanggal,id_bahan');
        }
      }

      if (mounted) {
        _showSnackPopup("Data berhasil disimpan");
        _markClean(); // [ADD] tandai bersih setelah berhasil simpan
      }
    } catch (e) {
      if (mounted) _showSnackPopup("Gagal menyimpan: $e", isError: true);
    } finally {
      if (mounted) setState(() => _saving = false); // selesai loading
    }
  }

  Future<void> _pickDate() async {
    final today = _todayDate;

    final picked = await showDatePicker(
      context: context,
      // jangan biarkan initialDate lewat dari hari ini
      initialDate: _selectedDate.isAfter(today) ? today : _selectedDate,
      firstDate: DateTime(2024),
      lastDate: today, // ⛔ maksimum = hari ini
      selectableDayPredicate: (d) => !d.isAfter(today), // disable tanggal > hari ini
      builder: (ctx, child) {
        final base = Theme.of(ctx);
        return Theme(
          data: base.copyWith(
            brightness: Brightness.light,
            colorScheme: base.colorScheme.copyWith(brightness: Brightness.light),
            textTheme: base.textTheme.apply(bodyColor: Colors.black87, displayColor: Colors.black87),
          ),
          child: child!,
        );
      },
    );

    if (picked == null || picked == _selectedDate) return;

    final ok = await _confirmLeaveIfDirty();
    if (!ok) return;

    setState(() => _selectedDate = picked);
    await _loadDataForDate(picked);
    await _fetchJenisFromDB();
    await _fetchItemTemplatesFromDB();
  }

  Widget _itemCard(
      String jenis,
      int index,
      Map<String, TextEditingController> item,
      ) {
    // === [ADD] Highlight saat search dan match
    final isSearching = _searchText.isNotEmpty;
    final isMatch = isSearching && _isItemMatch(item, _searchText);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isMatch ? Colors.teal.withOpacity(.45) : Colors.black.withOpacity(.06),
          width: isMatch ? 1.4 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: (isMatch ? Colors.teal : Colors.black).withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: item['id'],
                  readOnly: true,
                  decoration: _pillInput(label: 'ID'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: item['nama'],
                  onChanged: (_) => _markDirty(), // [ADD]
                  decoration: _pillInput(label: 'Nama Barang'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: item['jumlah'],
                  keyboardType: TextInputType.number,
                  onChanged: (_) => _markDirty(), // [ADD]
                  decoration: _pillInput(label: 'Jumlah', hint: '0'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: item['satuan'],
                  onChanged: (_) => _markDirty(), // [ADD]
                  decoration: _pillInput(
                    label: 'Satuan',
                    hint: 'Kg / Ltr / Pcs',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: item['harga'],
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    ThousandSeparatorInputFormatter(),
                  ],
                  onChanged: (_) => _markDirty(), // [ADD]
                  decoration: _pillInput(
                    label: 'Harga per Item',
                    hint: '0',
                    prefixText: 'Rp',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                tooltip: 'Hapus barang',
                onPressed: () => _hapusBarang(jenis, index),
                icon: const Icon(Icons.delete, color: Colors.red),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Paksa LIGHT hanya untuk halaman ini
    final base = Theme.of(context);
    final forcedLight = base.copyWith(
      brightness: Brightness.light,
      scaffoldBackgroundColor: Colors.transparent,
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      iconTheme: const IconThemeData(color: Colors.black87),
      appBarTheme: const AppBarTheme(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      listTileTheme: const ListTileThemeData(
        textColor: Colors.black87,
        iconColor: Colors.black87,
      ),
      expansionTileTheme: const ExpansionTileThemeData(
        textColor: Colors.black87,
        collapsedTextColor: Colors.black87,
        iconColor: Colors.black87,
        collapsedIconColor: Colors.black54,
      ),
      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        labelStyle: const TextStyle(color: Colors.black87),
        hintStyle: const TextStyle(color: Colors.black54),
        prefixStyle: const TextStyle(color: Colors.black87),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
      ),
    );

    final search = _searchController.text.trim().toLowerCase();
    final hasQuery = search.isNotEmpty;

    // === [ADD] WillPopScope untuk cegat keluar halaman ===
    Widget scaffold = Scaffold(
      drawer: usahaDrawer(
        idUsaha: widget.usahaId,
        active: 'bbp',
        onConfirmLeaveIfDirty: _confirmLeaveIfDirty,
      ),
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black87),
            splashRadius: 22,
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text(
          'Input Beban Pokok Penjualan',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700),
        ),
      ),

      body: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Scrollbar(
          thumbVisibility: true,
          child: SingleChildScrollView(
            padding: const EdgeInsets.only(bottom: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                _topBanner(),

                _section(
                  title: 'Tanggal & Pencarian',
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              borderRadius: BorderRadius.circular(30),
                              onTap: _pickDate,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(30),
                                  border: Border.all(color: Colors.black.withOpacity(.15)),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.calendar_today_rounded, size: 18, color: Colors.black87),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        DateFormat('EEEE, dd MMM yyyy', 'id_ID').format(_selectedDate),
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _searchController,
                        onChanged: (v) {
                          _onSearchChanged(v);    // [MOD] debounce & auto-expand
                          setState(() {});        // refresh icon clear & badge
                        },
                        decoration: _pillInput(
                          hint: 'Cari ID atau Nama Barang',
                          prefixIcon: Icons.search,
                        ).copyWith(
                          suffixIcon: (_searchController.text.isEmpty)
                              ? null
                              : IconButton(
                            tooltip: 'Bersihkan',
                            onPressed: () {
                              _searchController.clear();
                              _onSearchChanged('');
                              setState(() {});
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      if (_searchController.text.trim().isNotEmpty)
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(.06),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(color: Colors.black.withOpacity(.12)),
                              ),
                              child: Text(
                                '$_searchResultCount hasil',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black87,
                                  fontSize: 12.5,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            TextButton.icon(
                              onPressed: _autoScrollToFirstMatch,
                              icon: const Icon(Icons.vertical_align_bottom_rounded, size: 18),
                              label: const Text('Lompat ke hasil pertama'),
                            ),
                          ],
                        ),
                      const SizedBox(height: 12),
                      _saveHeaderButton(),
                    ],
                  ),
                ),

                _section(
                  title: 'Kategori',
                  action: FilledButton.tonalIcon(
                    onPressed: _addJenis,
                    icon: const Icon(Icons.add),
                    label: const Text('Tambah'),
                  ),
                  child: TextField(
                    controller: _jenisController,
                    onChanged: (_) => _markDirty(), // [ADD]
                    decoration: _pillInput(
                      label: 'Nama kategori baru',
                      hint: 'Mis. Sayuran / Daging / Bumbu',
                    ),
                  ),
                ),

                // === [MOD] Saat search aktif, render hanya kategori yang punya hasil (auto-expanded)
                ...(() {
                  final entries = hasQuery
                      ? _data.entries
                      .where((entry) => entry.value.any((item) => _isItemMatch(item, search)))
                      .toList()
                      : _data.entries.toList();

                  if (hasQuery && entries.isEmpty) {
                    return [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.black.withOpacity(.06)),
                          ),
                          child: const Row(
                            children: [
                              Icon(Icons.search_off_rounded),
                              SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'Tidak ada hasil. Coba kata kunci lain.',
                                  style: TextStyle(fontWeight: FontWeight.w600),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ];
                  }

                  return entries.map((entry) {
                    final jenis = entry.key;
                    final totalItems = entry.value.length;

                    final filteredItems = entry.value.where((item) {
                      if (!hasQuery) return true;
                      return _isItemMatch(item, search);
                    }).toList();

                    return Container(
                      key: _kategoriKeys.putIfAbsent(jenis, () => GlobalKey()),
                      margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.black.withOpacity(.06)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(.05),
                            blurRadius: 12,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Theme(
                        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                        child: ExpansionTile(
                          key: ValueKey<String>('exp-$jenis-${hasQuery ? 'q:${_searchText}' : 'normal'}'),

                          // Auto expand kalau search aktif dan ada hasil match
                          initiallyExpanded: hasQuery
                              ? (filteredItems.isNotEmpty)
                              : _expanded.contains(jenis),

                          // Jangan pertahankan state lama saat search aktif
                          maintainState: !hasQuery,

                          onExpansionChanged: (open) =>
                              setState(() => open ? _expanded.add(jenis) : _expanded.remove(jenis)),

                          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          childrenPadding: const EdgeInsets.only(bottom: 10),

                          title: Row(
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                margin: const EdgeInsets.only(right: 10),
                                decoration: BoxDecoration(
                                  color: Colors.teal.withOpacity(.35),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  jenis,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.teal.withOpacity(.12),
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: Colors.teal.withOpacity(.25)),
                                ),
                                child: Text(
                                  hasQuery ? '${filteredItems.length} match' : '$totalItems item',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: Colors.teal,
                                    fontSize: 12.5,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: 'Tambah barang',
                                onPressed: () => _addBarang(jenis),
                                icon: const Icon(Icons.add, color: Colors.black87),
                              ),
                              IconButton(
                                tooltip: 'Hapus kategori',
                                onPressed: () => _hapusJenis(jenis),
                                icon: const Icon(Icons.delete, color: Colors.red),
                              ),
                            ],
                          ),

                          children: [
                            ...filteredItems.asMap().entries.map((e) => _itemCard(jenis, e.key, e.value)),
                            if (!hasQuery)
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 10),
                                child: OutlinedButton.icon(
                                  onPressed: () => _addBarang(jenis),
                                  icon: const Icon(Icons.add, color: Colors.black87),
                                  label: const Text('Tambah Barang', style: TextStyle(color: Colors.black87)),
                                  style: OutlinedButton.styleFrom(
                                    side: BorderSide(color: Colors.black.withOpacity(.25)),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                  ),
                                ),
                              ),
                          ],
                        )
                      ),
                    );
                  }).toList();
                }()),

                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );

    // Bungkus dengan ValueListenableBuilder + WillPopScope
    scaffold = ValueListenableBuilder<bool>(
      valueListenable: _dirty,
      builder: (context, isDirty, child) {
        return WillPopScope(
          onWillPop: () async {
            // === [ADD] Cegat back gesture / system back jika dirty ===
            return await _confirmLeaveIfDirty();
          },
          child: child!,
        );
      },
      child: scaffold,
    );

    return Theme(data: forcedLight, child: AppBackground(child: scaffold));
  }
}

class ThousandSeparatorInputFormatter extends TextInputFormatter {
  final NumberFormat _nf = NumberFormat.decimalPattern('id_ID');

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue,
      TextEditingValue newValue,
      ) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) {
      return const TextEditingValue(
        text: '',
        selection: TextSelection.collapsed(offset: 0),
      );
    }
    final formatted = _nf.format(int.parse(digits));
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}
