import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:ok_oce/pages/reset_password_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'splash_screen.dart';
import 'dashboard/dashboard_usaha.dart';
import 'dashboard/dashboard_staff.dart';
import 'package:ok_oce/pages/reset_password_page.dart';
import 'InputBahanPokokPage.dart';
import 'InputLabaBersihPage.dart';
import 'pages/settings_page.dart';
import 'pages/auth_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID', null);

  await Supabase.initialize(
    url: 'https://vefkehdclnpufzkbumot.supabase.co',
    anonKey:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZlZmtlaGRjbG5wdWZ6a2J1bW90Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU4NDE2NjEsImV4cCI6MjA3MTQxNzY2MX0.JEA5TJNNWgOxqg_48lwyPUsPzeZQTY38FT0MCMp5YeA',
    debug: true,
    authOptions: const FlutterAuthClientOptions(
      authFlowType: AuthFlowType.pkce, // <-- yang benar di 2.9.1
    ),
  );

  runApp(const SimpangRayaApp());
}

class SimpangRayaApp extends StatelessWidget {
  const SimpangRayaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sistem Keuangan Simpang Raya',
      debugShowCheckedModeBanner: false,

      themeMode: ThemeMode.light,
      builder: (context, child) {
        final media = MediaQuery.of(context);
        final isMobile = media.size.width < 600;
        final clampedTextScale = isMobile
            ? media.textScaleFactor.clamp(0.6, 0.7)
            : media.textScaleFactor.clamp(1.0, 1.15);

        final Widget app = MediaQuery(
          data: media.copyWith(textScaleFactor: clampedTextScale),
          child: child!,
        );

        if (!isMobile) return app;

        final base = Theme.of(context);
        final compact = base.copyWith(
          brightness: Brightness.light,
          colorScheme: base.colorScheme.copyWith(
            brightness: Brightness.light,
            onSurface: Colors.black87,
            onBackground: Colors.black87,
          ),
          visualDensity: const VisualDensity(horizontal: -1, vertical: -1),
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          textTheme: base.textTheme
              .apply(bodyColor: Colors.black87, displayColor: Colors.black87)
              .copyWith(
            bodyMedium: const TextStyle(fontSize: 14),
            labelLarge:
            const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          ),

          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
              padding: const WidgetStatePropertyAll(
                EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              ),
              minimumSize: const WidgetStatePropertyAll(Size(0, 20)),
              textStyle: const WidgetStatePropertyAll(
                TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
              ),
              shape: const WidgetStatePropertyAll(StadiumBorder()),
            ),
          ),
          filledButtonTheme: FilledButtonThemeData(
            style: ButtonStyle(
              padding: const WidgetStatePropertyAll(
                EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              ),
              minimumSize: const WidgetStatePropertyAll(Size(0, 36)),
              textStyle: const WidgetStatePropertyAll(
                TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
              ),
              shape: const WidgetStatePropertyAll(StadiumBorder()),
            ),
          ),
          outlinedButtonTheme: OutlinedButtonThemeData(
            style: ButtonStyle(
              padding: const WidgetStatePropertyAll(
                EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              ),
              minimumSize: const WidgetStatePropertyAll(Size(0, 36)),
              textStyle: const WidgetStatePropertyAll(
                TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
              ),
              shape: const WidgetStatePropertyAll(StadiumBorder()),
            ),
          ),
          chipTheme: base.chipTheme.copyWith(
            labelStyle: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          ),
          inputDecorationTheme: base.inputDecorationTheme.copyWith(
            isDense: true,
            contentPadding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          ),
          navigationBarTheme: base.navigationBarTheme.copyWith(
            height: 50,
            labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
          ),
          appBarTheme: base.appBarTheme.copyWith(
            toolbarHeight: 52,
            titleTextStyle: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Colors.black87,
            ),
            systemOverlayStyle: SystemUiOverlayStyle.dark,
            foregroundColor: Colors.black87,
            backgroundColor: Colors.transparent,
            elevation: 0,
          ),
          iconTheme: const IconThemeData(color: Colors.black87),
        );

        return Theme(data: compact, child: app);
      },

      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Poppins',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE74C3C), // merah Inmato
          brightness: Brightness.light,
        ),
        brightness: Brightness.light,
        textTheme: ThemeData.light()
            .textTheme
            .apply(bodyColor: Colors.black87, displayColor: Colors.black87),
        iconTheme: const IconThemeData(color: Colors.black87),
        appBarTheme: const AppBarTheme(
          foregroundColor: Colors.black87,
          backgroundColor: Colors.transparent,
          elevation: 0,
          systemOverlayStyle: SystemUiOverlayStyle.dark,
          titleTextStyle: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Colors.black87,
          ),
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),


      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        fontFamily: 'Poppins',
      ),

      initialRoute: '/',
      routes: {
        '/': (_) => const SplashScreen(),
        '/login': (_) => const AuthPage(),
        '/reset-password': (_) => const ResetPasswordPage(),
        '/register': (_) => const AuthPage(),
        '/settings': (_) => const SettingsPage(),
        '/dashboard': (context) {
          final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
          final String? idUsaha = args?['idUsaha'] as String?;
          final String? namausaha = args?['namausaha'] as String?;
          if (idUsaha == null || idUsaha.isEmpty) {
            return const Scaffold(
              body: Center(child: Text('idUsaha tidak tersedia')),
            );
          }
          return Dashboardusaha(
            idUsaha: idUsaha,
            namausaha: namausaha ?? '',
          );
        },

        '/dashboard-usaha': (context) {
          final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
          final String? idUsaha = args?['idUsaha'] as String?;
          final String? namausaha = args?['namausaha'] as String?;
          if (idUsaha == null || idUsaha.isEmpty) {
            return const Scaffold(
              body: Center(child: Text('idUsaha tidak tersedia')),
            );
          }
          return Dashboardusaha(
            idUsaha: idUsaha,
            namausaha: namausaha ?? '',
          );
        },
        '/dashboard_staff': (_) => const DashboardStaff(),
        '/input-laba': (context) {
          final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
          final DateTime? tanggal = args?['tanggal'] as DateTime?;
          if (tanggal == null) {
            return const Scaffold(
              body: Center(child: Text('Argument tanggal tidak ditemukan')),
            );
          }
          return InputLabaBersihPage(tanggal: tanggal);
        },
        '/lupa-password': (_) => const ResetPasswordPage(),
        '/input-omzet': (context) {
          final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
          final String? idUsahaFromArgs = args?['idUsaha'] as String?;
          final String? idUsahaFromUser = Supabase.instance.client.auth
              .currentUser
              ?.userMetadata?['usaha_id'] as String?;
          final String? idUsaha = idUsahaFromArgs ?? idUsahaFromUser;

          if (idUsaha == null || idUsaha.isEmpty) {
            return const Scaffold(
              body: Center(child: Text('idUsaha tidak tersedia')),
            );
          }
          return InputBahanPokokPage(usahaId: idUsaha);
        },
      },
    );
  }
}
