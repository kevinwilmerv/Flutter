import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/widget/usaha_drawer.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/pages/laporanIncomeMato.dart';
import 'package:flutter/services.dart';

class InputIncomeMato extends StatefulWidget {
  final String? idUsaha; // opsional: kalau null, drawer & query ambil dari profiles
  const InputIncomeMato({super.key, this.idUsaha});

  @override
  State<InputIncomeMato> createState() => _InputIncomeMatoState();
}

bool _noticeShown = false;

enum _DiscardAction { cancel, save, discard }

class _InputIncomeMatoState extends State<InputIncomeMato> {
  DateTime? _startDate;
  DateTime? _endDate;
  bool _showInfo = false;
  bool _saving = false;

  double _labaBersih = 0;
  int _totalMato = 0;

  double get _pctPemilik => 100 - _pctKaryawan;

  // ==== Unsaved changes guard ====
  final _dirty = ValueNotifier<bool>(false);
  bool _dirtyToastShown = false;
  double _lastSavedPctKaryawan = 50; // baseline (nilai saat terakhir tersimpan)

  bool get _isDirty => _dirty.value;

  void _markDirty() {
    if (!_dirty.value) {
      _dirty.value = true;
    }
  }

  void _markClean() {
    if (_dirty.value) _dirty.value = false;
    _dirtyToastShown = false;
  }

// perubahan bermakna = persen karyawan berbeda dari baseline tersimpan
  bool _hasMeaningfulDraft() => _pctKaryawan.toInt() != _lastSavedPctKaryawan.toInt();

  Future<_DiscardAction> _confirmDiscardDialog() async {
    return await showDialog<_DiscardAction>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Perubahan belum disimpan'),
        content: const Text('Kamu sudah mengubah persentase tapi belum menekan Simpan. Mau gimana?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, _DiscardAction.cancel), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, _DiscardAction.discard), child: const Text('Tinggalkan')),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, _DiscardAction.save),
            icon: const Icon(Icons.save),
            label: const Text('Simpan sekarang'),
          ),
        ],
      ),
    ) ?? _DiscardAction.cancel;
  }

  Future<bool> _confirmLeaveIfDirty() async {
    if (!_isDirty || !_hasMeaningfulDraft()) {
      _markClean();
      return true;
    }
    final action = await _confirmDiscardDialog();
    if (action == _DiscardAction.save) {
      await _simpanKeSupabase();
      return true;
    } else if (action == _DiscardAction.discard) {
      return true;
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
    _lastSavedPctKaryawan = _pctKaryawan; // baseline awal (tetap pakai karyawan)
    _pctCtrl.text = _pctPemilik.toInt().toString(); // tampilkan nilai Pemilik
  }

  // ====== Tambahan: Persentase dinamis ======
  double _pctKaryawan = 50; // default 50%
  final TextEditingController _pctCtrl = TextEditingController(text: '50');

  @override
  void dispose() {
    _pctCtrl.dispose();
    super.dispose();
  }

  void _openLaporanIncomeMato() async {
    final idUsaha = widget.idUsaha;
    if (idUsaha == null || idUsaha.isEmpty) return;
    if (!await _confirmLeaveIfDirty()) return;
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => LaporanIncomeMatoPage(idUsaha: idUsaha)),
    );
  }

  // ======== DATE PICKERS ========
  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime.now(),
      builder: (ctx, child) {
        final base = Theme.of(ctx);
        final themed = base.copyWith(
          useMaterial3: false,
          colorScheme: base.colorScheme.copyWith(
            brightness: Brightness.light,
            primary: Colors.black87,
            onPrimary: Colors.white,
            surface: Colors.white,
            onSurface: Colors.black87,
          ),
          textTheme: base.textTheme.apply(
            bodyColor: Colors.black87,
            displayColor: Colors.black87,
          ),
          dialogBackgroundColor: Colors.white,
        );
        return Theme(data: themed, child: child!);
      },
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
        } else {
          _endDate = picked;
        }
      });
      if (_startDate != null && _endDate != null) {
        await _fetchData();
      }
    }
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _startDate ?? DateTime(now.year, now.month, 1),
      end: _endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2024, 1, 1),
      lastDate: now,
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate   = picked.end;
      });
      await _fetchData();
    }
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();

    if (code == 'all') {
      setState(() {
        _startDate = DateTime(2024, 1, 1);
        _endDate = now;
      });
    } else if (code == 'month') {
      setState(() {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '100') {
      setState(() {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      });
    }

    await _fetchData();
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _labaBersih = 0;
      _totalMato = 0;
    });
  }

  // ======== DATA OPS ========
  Future<String?> _resolveidUsaha() async {
    if (widget.idUsaha != null && widget.idUsaha!.isNotEmpty) {
      return widget.idUsaha;
    }
    final sp = Supabase.instance.client;
    final user = sp.auth.currentUser;
    if (user == null) return null;
    final prof = await sp
        .from('profiles')
        .select('id_usaha')
        .eq('id', user.id)
        .maybeSingle();
    return prof?['id_usaha']?.toString();
  }

  Future<void> _simpanKeSupabase() async {
    if (_saving) return;

    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      await showTopToast(context, 'Anda belum login', icon: Icons.info_rounded);
      return;
    }
    if (_startDate == null || _endDate == null) {
      await showTopToast(context, 'Pilih tanggal terlebih dahulu', icon: Icons.info_rounded);
      return;
    }

    final start = DateTime(_startDate!.year, _startDate!.month, _startDate!.day);
    final end   = DateTime(_endDate!.year,   _endDate!.month,   _endDate!.day);
    if (start.isAfter(end)) {
      await showTopToast(context, 'Rentang tanggal tidak valid', icon: Icons.info_rounded);
      return;
    }

    final idUsaha = await _resolveidUsaha();
    if (idUsaha == null || idUsaha.isEmpty) {
      await showTopToast(context, 'ID usaha tidak ditemukan', icon: Icons.warning_amber_rounded);
      return;
    }

    // ==== Hitung angka (pakai persentase dinamis) ====
    final bagianKaryawan = (_labaBersih * (_pctKaryawan / 100)).round();
    final bagianDireksi  = (_labaBersih * ((100 - _pctKaryawan) / 100)).round();
    final incomePerMato  = _totalMato > 0 ? (bagianKaryawan / _totalMato).round() : 0;

    if (mounted) setState(() => _saving = true);

    try {
      await supabase.from('income_per_mato').insert({
        'id_usaha': idUsaha,
        'tanggal_awal': DateFormat('yyyy-MM-dd').format(start),
        'tanggal_akhir': DateFormat('yyyy-MM-dd').format(end),
        'total_laba_bersih': _labaBersih.round(),
        'bagian_karyawan': bagianKaryawan,
        'bagian_direksi': bagianDireksi,
        'total_mato': _totalMato,
        'income_per_mato': incomePerMato,
        'created_at': DateTime.now().toIso8601String(),
      });

      if (!mounted) return;
      await showTopToast(context, 'Data berhasil disimpan', icon: Icons.check_circle_rounded);
    } on PostgrestException catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal menyimpan (DB): ${e.message}',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(seconds: 3),
      );
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal menyimpan: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(seconds: 3),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
    _lastSavedPctKaryawan = _pctKaryawan;
    _markClean();
  }

  Widget _saveFooterButton() {
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        final targetWidth = (w <= 380) ? w : (w <= 560) ? w * 0.70 : 420.0;
        final label = _saving
            ? (w < 380 ? 'Menyimpan...' : 'Menyimpan...')
            : (w < 380 ? 'Simpan' : 'Simpan');

        return Align(
          alignment: Alignment.centerLeft,
          child: SizedBox(
            width: targetWidth,
            child: FilledButton.icon(
              onPressed: _saving ? null : _simpanKeSupabase,
              icon: _saving
                  ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
                  : const Icon(Icons.save_rounded, size: 18),
              label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
              style: FilledButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                backgroundColor: Colors.black87,
                foregroundColor: Colors.white,
                elevation: 0,
              ),
            ),
          ),
        );
      },
    );
  }

  // add inside _InputIncomeMatoState
  Widget _sectionCard({required Widget child}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.55),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.black.withOpacity(0.05)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: child,
    );
  }

  Future<void> _fetchData() async {
    final sp = Supabase.instance.client;
    final idUsaha = await _resolveidUsaha();
    if (idUsaha == null || _startDate == null || _endDate == null) return;

    final labaResp = await sp
        .from('laba_bersih')
        .select('total_laba_bersih, tanggal')
        .eq('id_usaha', idUsaha)
        .gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!))
        .lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));

    double totalLaba = 0;
    for (var row in labaResp) {
      totalLaba += double.tryParse(row['total_laba_bersih'].toString()) ?? 0;
    }

    final matoResp = await sp.from('profiles').select('skor_mato').eq('id_usaha', idUsaha);

    int totalMato = 0;
    for (var row in matoResp) {
      totalMato += (row['skor_mato'] as num?)?.toInt() ?? 0;
    }

    setState(() {
      _labaBersih = totalLaba;
      _totalMato = totalMato;
    });
  }

  void _showInitialNotice() {
    showDialog(
      context: context,
      useRootNavigator: true,
      barrierDismissible: true,
      builder: (ctx) {
        final w = MediaQuery.of(ctx).size.width;
        final bodyMaxW = w < 480 ? (w - 32) : 440.0;

        final theme = Theme.of(ctx).copyWith(
          dialogTheme: Theme.of(ctx).dialogTheme.copyWith(
            backgroundColor: Colors.white,
            titleTextStyle:
            const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
            contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
          ),
          textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(foregroundColor: Colors.black87),
          ),
        );

        return Theme(
          data: theme,
          child: AlertDialog(
            scrollable: true,
            insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            clipBehavior: Clip.antiAlias,
            titlePadding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            contentPadding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            actionsPadding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Icon(Icons.info_outline_rounded, color: Colors.black87),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Catatan Income per Mato',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: bodyMaxW),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 4),
                    Text(
                      'Perhitungan Income per Mato idealnya memakai rentang MINIMAL 1 bulan.',
                      style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87),
                    ),
                    SizedBox(height: 8),
                    Text('Jika rentang < 30 hari, angka yang tampil hanya indikatif (untuk gambaran saja).',
                        style: TextStyle(color: Colors.black87)),
                    SizedBox(height: 6),
                    Text('Saran: pilih filter “Bulan Ini” atau atur rentang tanggal ≥ 1 bulan.',
                        style: TextStyle(color: Colors.black87)),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Oke, mengerti')),
            ],
          ),
        );
      },
    );
  }

  int? get _rangeDays =>
      (_startDate != null && _endDate != null) ? _endDate!.difference(_startDate!).inDays + 1 : null;

  Widget _saveHeaderButton(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final label = w < 380 ? 'Simpan' : 'Simpan';

    return FilledButton.icon(
      onPressed: _simpanKeSupabase,
      icon: const Icon(Icons.save_rounded, size: 18),
      label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
      style: FilledButton.styleFrom(
        shape: const StadiumBorder(),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        backgroundColor: Colors.black87,
        foregroundColor: Colors.white,
        elevation: 0,
        minimumSize: const Size(0, 40),
      ),
    );
  }

  Widget _rangeHintBadge() {
    if (_rangeDays == null) return const SizedBox.shrink();
    final bad = _rangeDays! < 30;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: (bad ? Colors.orange.shade50 : Colors.green.shade50),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(bad ? Icons.warning_amber_rounded : Icons.check_circle_rounded,
              size: 16, color: bad ? Colors.orange : Colors.green),
          const SizedBox(width: 8),
          Text(
            'Rentang aktif: $_rangeDays hari • minimal 30 hari',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: bad ? Colors.orange.shade800 : Colors.green.shade800,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_noticeShown) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _showInitialNotice();
        _noticeShown = true;
      });
    }
  }

  // ==== Toast hitam kecil seragam (top) ====
  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle_rounded,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    if (!(context as Element).mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(duration, () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });
        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        message,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved =
        CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
        return FadeTransition(
          opacity: anim,
          child:
          ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
        );
      },
    );
  }

  // ======== UI ========
  @override
  Widget build(BuildContext context) {
    final formatCurrency =
    NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    // ===== Pakai persentase dinamis =====
    final bagianKaryawan = _labaBersih * (_pctKaryawan / 100);
    final bagianDireksi = _labaBersih * ((100 - _pctKaryawan) / 100);
    final incomePerMato = _totalMato > 0 ? bagianKaryawan / _totalMato : 0;

    final fmtChip = DateFormat('d MMM yyyy', 'id_ID');

    // Paksa tema LIGHT + teks default hitam
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle:
        const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: ValueListenableBuilder<bool>(
          valueListenable: _dirty,
          builder: (context, isDirty, child) {
            return PopScope(
              canPop: false,
              onPopInvoked: (didPop) async {
                if (didPop) return;
                final ok = await _confirmLeaveIfDirty();
                if (!ok) return;
                if (Navigator.of(context).canPop()) {
                  Navigator.of(context).pop();
                } else {
                  SystemNavigator.pop(); // kalau di root, benar2 keluar app
                }
              },
              child: child!,
            );
          },
          child: AppBackground(
            child: Scaffold(
              backgroundColor: Colors.transparent,
              drawer: usahaDrawer(
                idUsaha: widget.idUsaha,
                active: 'mato',
                onConfirmLeaveIfDirty: _confirmLeaveIfDirty, // <— guard juga saat pindah menu
              ),
              appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                scrolledUnderElevation: 0,
                iconTheme: const IconThemeData(color: Colors.black87),
                leading: Builder(
                  builder: (ctx) => IconButton(
                    icon: const Icon(Icons.menu),
                    onPressed: () => Scaffold.of(ctx).openDrawer(),
                  ),
                ),
                title: const Text('Update Income Per Mato',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
              ),
              body: SafeArea(
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // === KARTU FILTER ATAS ===
                      _sectionCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('Tanggal (Rentang)',
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                const Spacer(),
                                OutlinedButton.icon(
                                  onPressed: (widget.idUsaha == null || widget.idUsaha!.isEmpty)
                                      ? null
                                      : _openLaporanIncomeMato,
                                  icon: const Icon(Icons.receipt_long_rounded, size: 18),
                                  label: const Text('Lihat Laporan', style: TextStyle(fontWeight: FontWeight.w700)),
                                  style: OutlinedButton.styleFrom(
                                    backgroundColor: const Color(0xFFFFE4E9),
                                    foregroundColor: Colors.black,
                                    side: const BorderSide(color: Colors.black, width: 1),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),

                            Row(
                              children: [
                                ElevatedButton.icon(
                                  onPressed: _openRangePicker,
                                  icon: const Icon(Icons.date_range, size: 18),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFFFFE4E9),
                                    foregroundColor: Colors.black,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(40),
                                      side: const BorderSide(color: Colors.black, width: 1),
                                    ),
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                  ),
                                  label: const Text('Rentang Tanggal'),
                                ),
                                const SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: _clearDates,
                                  style: OutlinedButton.styleFrom(
                                    side: const BorderSide(color: Colors.black, width: 1),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                  ),
                                  child: const Text('Clear'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),

                            Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    onTap: () => _selectDate(context, true),
                                    borderRadius: BorderRadius.circular(40),
                                    child: _DatePill(
                                      label: 'Tanggal Awal',
                                      value: _startDate == null
                                          ? '—'
                                          : DateFormat('d MMM yyyy', 'id_ID').format(_startDate!),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: InkWell(
                                    onTap: () => _selectDate(context, false),
                                    borderRadius: BorderRadius.circular(40),
                                    child: _DatePill(
                                      label: 'Tanggal Akhir',
                                      value:
                                      _endDate == null ? '—' : DateFormat('d MMM yyyy', 'id_ID').format(_endDate!),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),

                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _PresetChip(text: 'Semua Data', onTap: () => _applyPreset('all')),
                                _PresetChip(text: 'Bulan Ini', onTap: () => _applyPreset('month')),
                                _PresetChip(text: '100 Hari Terakhir', onTap: () => _applyPreset('100')),
                              ],
                            ),
                            const SizedBox(height: 8),

                            _rangeHintBadge(),
                            const SizedBox(height: 12),

                            _saveFooterButton(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      _rangeHintBadge(),
                      const SizedBox(height: 24),

                      _buildInfoTile('LABA BERSIH', formatCurrency.format(_labaBersih)),

                      // ===== Kontrol Persentase (menandai dirty) =====
                      Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.6),
                          borderRadius: BorderRadius.circular(40),
                          border: Border.all(color: Colors.black, width: 1),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('Atur Persentase', style: TextStyle(fontWeight: FontWeight.bold)),
                                const Spacer(),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(30),
                                    border: Border.all(color: Colors.black, width: 1),
                                  ),
                                  child: Text('Pemilik: ${(100 - _pctKaryawan).toInt()}%',
                                      style: const TextStyle(fontWeight: FontWeight.w700)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Expanded(
                                  child: Slider(
                                    value: _pctPemilik,            // ← tampilkan porsi Pemilik
                                    min: 0,
                                    max: 100,
                                    divisions: 100,
                                    label: '${_pctPemilik.toInt()}%',   // ← bubble menunjukkan Pemilik
                                    onChanged: (v) {
                                      setState(() {
                                        _pctKaryawan = 100 - v;                // ← simpan kebalikannya
                                        _pctCtrl.text = v.toInt().toString();  // sinkronkan textbox (Pemilik)
                                      });
                                      if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
                                    },
                                  ),
                                ),
                                const SizedBox(width: 8),
                                SizedBox(
                                  width: 64,
                                  child: TextField(
                                    controller: _pctCtrl,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      isDense: true,
                                      contentPadding:
                                      const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                      suffixText: '%',
                                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                                    ),
                                    onChanged: (txt) {
                                      final n = int.tryParse(txt) ?? 0;
                                      final clamped = n.clamp(0, 100);
                                      // jika user ketik porsi Pemilik, kita simpan kebalikannya sebagai porsi Karyawan
                                      final asDouble = clamped.toDouble();
                                      if (asDouble.toInt() != _pctPemilik.toInt()) {
                                        setState(() {
                                          _pctKaryawan = 100 - asDouble;   // ← update internal
                                        });
                                      }
                                      if (clamped.toString() != txt) {
                                        _pctCtrl.value = _pctCtrl.value.copyWith(
                                          text: clamped.toString(),
                                          selection: TextSelection.collapsed(offset: clamped.toString().length),
                                        );
                                      }
                                      if (_hasMeaningfulDraft()) _markDirty(); else _markClean();
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      _buildInfoTile(
                        'BAGIAN KARYAWAN (${_pctKaryawan.toInt()}% LABA BERSIH)',
                        formatCurrency.format(bagianKaryawan),
                      ),
                      _buildInfoTile(
                        'BAGIAN PEMILIK USAHA (${(100 - _pctKaryawan).toInt()}% LABA BERSIH)',
                        formatCurrency.format(bagianDireksi),
                      ),

                      Row(
                        children: [
                          const Text('TOTAL MATO SEMUA PEGAWAI',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(40),
                              border: Border.all(color: Colors.black, width: 1),
                            ),
                            child: Text(_totalMato.toString()),
                          ),
                          const Spacer(),
                          IconButton(
                            icon:
                            Icon(Icons.info_outline, color: _showInfo ? Colors.black : Colors.grey),
                            onPressed: () => setState(() => _showInfo = !_showInfo),
                          ),
                        ],
                      ),

                      if (_showInfo)
                        Container(
                          margin: const EdgeInsets.only(top: 8),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(color: Colors.black, width: 1),
                          ),
                          child: Text.rich(
                            TextSpan(
                              children: [
                                const TextSpan(
                                    text: 'Laba bersih ', style: TextStyle(fontWeight: FontWeight.bold)),
                                const TextSpan(text: 'akan dibagi menjadi dua bagian:\n'),
                                TextSpan(text: '- ${_pctKaryawan.toInt()}% untuk karyawan\n'),
                                TextSpan(
                                    text: '- ${(100 - _pctKaryawan).toInt()}% untuk pemilik usaha\n\n'),
                                const TextSpan(text: 'Untuk menghitung Income per Mato, '),
                                TextSpan(
                                    text: 'ambil ${''}${_pctKaryawan.toInt()}% bagian karyawan ',
                                    style: const TextStyle(fontWeight: FontWeight.bold)),
                                const TextSpan(text: 'lalu dibagi dengan total poin mato seluruh pegawai.\n\n'),
                                const TextSpan(text: 'Rumus:\n'),
                                TextSpan(
                                  text:
                                  'Income per Mato = (${_pctKaryawan.toInt()}% × Laba Bersih) ÷ Total Mato usaha\n\n',
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ),
                      const SizedBox(height: 24),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                        decoration: BoxDecoration(
                          color: const Color(0xFFA0E7C2),
                          borderRadius: BorderRadius.circular(40),
                          border: Border.all(color: Colors.black, width: 1),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('INCOME PER MATO', style: TextStyle(fontWeight: FontWeight.bold)),
                            Text(formatCurrency.format(incomePerMato),
                                style: const TextStyle(fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ====== Small widgets ======
  Widget _buildInfoTile(String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(value,
              style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
