import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:ok_oce/widget/app_background.dart';

enum HelperType { text, video }

class HelperItem {
  final String title;
  final String description;
  final String url;
  final HelperType type;
  const HelperItem({
    required this.title,
    required this.description,
    required this.url,
    required this.type,
  });
}

class HelperPage extends StatelessWidget {
  final List<HelperItem> items;
  final String pageTitle;
  const HelperPage({
    super.key,
    required this.items,
    this.pageTitle = 'Panduan Penggunaan Aplikasi',
  });

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
    }
  }

  @override
  Widget build(BuildContext context) {
    // konsisten dengan halaman lain (LIGHT + wallpaper)
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(bodyColor: Colors.black87, displayColor: Colors.black87),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
            color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.22,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            extendBodyBehindAppBar: false,
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: () => Navigator.of(context).maybePop(),
                splashRadius: 22,
              ),
              title: Text(pageTitle),
            ),
            body: SafeArea(
              top: false,
              minimum: const EdgeInsets.only(bottom: 12),
              child: LayoutBuilder(
                builder: (context, c) {
                  final w = c.maxWidth;
                  final isPhone = w < 800;

                  // grid & padding responsif
                  int cross = 1;
                  if (w >= 1200) cross = 3;
                  else if (w >= 800) cross = 2;

                  final double hPad = w >= 1200 ? 64 : w >= 800 ? 40 : 16;
                  const double vTop = 28;
                  const double vBottom = 16;

                  // tinggi card ala model (sedikit lebih pendek di HP)
                  final double mainExtent = isPhone ? 170 : 200;

                  return GridView.builder(
                    padding: EdgeInsets.fromLTRB(hPad, vTop, hPad, vBottom),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: cross,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      mainAxisExtent: mainExtent,
                    ),
                    itemCount: items.length,
                    itemBuilder: (ctx, i) {
                      final it = items[i];
                      final isVideo = it.type == HelperType.video;

                      // label oranye seperti contoh (“Poin Mato …”),
                      // untuk halaman ini kita pakai “Panduan Video/Teks”
                      final orangeLabel = 'Panduan ${isVideo ? "Video" : "Teks"}';

                      return Container(
                        padding: EdgeInsets.all(isPhone ? 14 : 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(isPhone ? 16 : 20),
                          boxShadow: const [
                            BoxShadow(color: Colors.black12, blurRadius: 4)
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Judul
                            Text(
                              it.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: isPhone ? 16 : 18,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 6),

                            // Subjudul / deskripsi singkat
                            Text(
                              it.description,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: isPhone ? 13 : 14),
                            ),

                            // Spacer kecil di HP, besar di layar lebar
                            SizedBox(height: isPhone ? 6 : 8),
                            if (!isPhone) const Spacer(),

                            // Label oranye (gaya contoh)
                            Text(
                              orangeLabel,
                              style: TextStyle(
                                fontSize: isPhone ? 16 : 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.orange,
                              ),
                            ),
                            const SizedBox(height: 8),

                            // Tombol hijau muda full width “Klik di sini”
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () => _openUrl(it.url),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green.shade100,
                                  foregroundColor: Colors.green.shade800,
                                  elevation: 0,
                                  minimumSize: Size.fromHeight(isPhone ? 36 : 40),
                                  padding: EdgeInsets.symmetric(
                                    vertical: isPhone ? 8 : 10,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                ),
                                child: const Text('Klik di sini'),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
