import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/app_background.dart';

// PDF
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

enum _ColType { date, number }

class _ColSpec {
  final String title;
  final String key;
  final _ColType type;
  const _ColSpec(this.title, this.key, this.type);
}

// === Kolom table ===
final List<_ColSpec> _cols = const [
  _ColSpec('Tanggal', 'tanggal', _ColType.date),
  _ColSpec('Penjualan', 'penjualan', _ColType.number),
  _ColSpec('Beban Pokok', 'hpp', _ColType.number),
  _ColSpec('Laba Kotor', 'laba_kotor', _ColType.number),
  _ColSpec('Beban Usaha', 'beban_usaha', _ColType.number),
  _ColSpec('Sewa & Penyusutan', 'sewa_penyusutan', _ColType.number),
  _ColSpec('Servis Kantor', 'servis_kantor', _ColType.number),
  _ColSpec('Biaya Lain', 'biaya_lain', _ColType.number),
  _ColSpec('Laba Bersih', 'laba_bersih', _ColType.number),
];

class LaporanLBPage extends StatefulWidget {
  final String idUsaha;
  const LaporanLBPage({super.key, required this.idUsaha});

  @override
  State<LaporanLBPage> createState() => _LaporanLBPageState();
}

class _LaporanLBPageState extends State<LaporanLBPage> {
  final _supabase = Supabase.instance.client;
  final logService = LogService();

  DateTime? _startDate;
  DateTime? _endDate;
  final _fmtYmd = DateFormat('yyyy-MM-dd');

  List<Map<String, dynamic>> _rows = [];
  bool _loading = false;

  bool _selectMode = false;
  final Set<String> _selectedDates = {};

  final bool _allocateFixedToLastDay = true;

  final _fmtDate = DateFormat('d MMM yyyy', 'id_ID');
  final _fmtCur = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  final _hHeader = ScrollController();
  final _hBody = ScrollController();

  // --- sticky filter-info (sort badge) ---
  static const double _kStickyBadgeReservedHeight = 42; // tinggi ruang disisihkan untuk badge
  final GlobalKey _filterBarKey = GlobalKey();
  double _filterBarHeight = 0;

  void _measureFilterBarHeight() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _filterBarKey.currentContext;
      if (ctx == null) return;
      final box = ctx.findRenderObject() as RenderBox?;
      final h = box?.size.height ?? 0;
      if (!mounted) return;
      if ((h - _filterBarHeight).abs() > 0.5) {
        setState(() => _filterBarHeight = h);
      }
    });
  }

  // Header untuk export PDF
  final List<String> _headers = const [
    'Tanggal',
    'Penjualan',
    'Beban Pokok',
    'Laba Kotor',
    'Beban Usaha',
    'Sewa & Penyusutan',
    'Servis Kantor',
    'Biaya Lain',
    'Laba Bersih',
  ];
  final List<double> _baseWidths = const [180, 180, 160, 180, 180, 200, 180, 180, 180];

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _startDate = DateTime(now.year, now.month, 1);
    _endDate = DateTime(now.year, now.month + 1, 0);

    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });

    _fetchData();
  }

  @override
  void dispose() {
    _hHeader.dispose();
    _hBody.dispose();
    super.dispose();
  }

  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  int? _sortColumnIndex;
  bool _sortAscending = true;

  void _applySort({int? columnIndex, bool? ascending, bool notify = true}) {
    if (columnIndex != null) {
      if (_sortColumnIndex == columnIndex) {
        _sortAscending = ascending ?? !_sortAscending;
      } else {
        _sortColumnIndex = columnIndex;
        _sortAscending = ascending ?? false;
        if (_cols[columnIndex].type == _ColType.date) _sortAscending = true;
      }
    }

    if (_rows.isEmpty) {
      if (notify) setState(() {});
      return;
    }

    if (_sortColumnIndex == null) {
      _rows.sort((a, b) {
        final ad = DateTime.tryParse((a['tanggal'] ?? '').toString()) ?? DateTime(1970);
        final bd = DateTime.tryParse((b['tanggal'] ?? '').toString()) ?? DateTime(1970);
        return ad.compareTo(bd);
      });
    } else {
      final spec = _cols[_sortColumnIndex!];
      int cmp(Map<String, dynamic> x, Map<String, dynamic> y) {
        if (spec.type == _ColType.date) {
          final dx = DateTime.tryParse((x[spec.key] ?? '').toString()) ?? DateTime(1970);
          final dy = DateTime.tryParse((y[spec.key] ?? '').toString()) ?? DateTime(1970);
          return dx.compareTo(dy);
        } else {
          final nx = _num(x[spec.key]);
          final ny = _num(y[spec.key]);
          return nx.compareTo(ny);
        }
      }

      _rows.sort((a, b) {
        final c = cmp(a, b);
        return _sortAscending ? c : -c;
      });
    }

    if (notify) setState(() {});
  }

  Widget _sortBadgeFixed() {
    if (_sortColumnIndex == null) return const SizedBox.shrink();
    final title = _cols[_sortColumnIndex!].title;
    final dirLabel = _sortAscending ? 'Terendah → Tertinggi' : 'Tertinggi → Terendah';

    return IgnorePointer(
      ignoring: true, // info-only; tidak menghalangi gesture
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.06), blurRadius: 8, offset: const Offset(0, 3)),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.sort, size: 18, color: Colors.black87),
            const SizedBox(width: 6),
            Text('Urut: $title • $dirLabel', style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  // ====== FETCH dari VIEW ======
  Future<void> _fetchData() async {
    setState(() => _loading = true);
    _selectedDates.clear();

    try {
      var qb = _supabase
          .from('laba_bersih_harian_v')
          .select(
        'tanggal:periode, penjualan, hpp:beban_pokok, '
            'laba_kotor, beban_usaha, sewa_penyusutan, servis_kantor, '
            'biaya_lain:nilai_biaya_lain, '
            'laba_bersih',
      )
          .eq('id_usaha', widget.idUsaha) as PostgrestFilterBuilder;

      if (_startDate != null) {
        qb = qb.gte('periode', _fmtYmd.format(_startDate!));
      }
      if (_endDate != null) {
        qb = qb.lte('periode', _fmtYmd.format(_endDate!));
      }

      String orderKey = 'periode';
      bool ascending = true;

      if (_sortColumnIndex != null) {
        final spec = _cols[_sortColumnIndex!];
        final mapOrder = <String, String>{
          'tanggal': 'periode',
          'hpp': 'beban_pokok',
          'biaya_lain': 'nilai_biaya_lain',
          'penjualan': 'penjualan',
          'laba_kotor': 'laba_kotor',
          'beban_usaha': 'beban_usaha',
          'sewa_penyusutan': 'sewa_penyusutan',
          'servis_kantor': 'servis_kantor',
          'laba_bersih': 'laba_bersih',
        };
        orderKey = mapOrder[spec.key] ?? spec.key;
        ascending = _sortAscending;
      }

      final List data = await qb.order(orderKey, ascending: ascending);

      if (!mounted) return;
      setState(() {
        _rows = List<Map<String, dynamic>>.from(data);
        _allocateFixedCostsToLastDay();
      });

      _applySort(notify: true);
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal memuat data: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 1800),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _allocateFixedCostsToLastDay() {
    if (!_allocateFixedToLastDay || _rows.isEmpty) return;

    num totSewa = 0, totServis = 0;
    for (final r in _rows) {
      totSewa += _num(r['sewa_penyusutan']);
      totServis += _num(r['servis_kantor']);
    }

    int lastIdx = 0;
    DateTime? lastDate;
    for (int i = 0; i < _rows.length; i++) {
      final raw = _rows[i]['tanggal'];
      final d = raw is String ? DateTime.tryParse(raw) : (raw is DateTime ? raw : null);
      if (d == null) continue;
      if (lastDate == null || d.isAfter(lastDate)) {
        lastDate = d;
        lastIdx = i;
      }
    }

    for (final r in _rows) {
      r['sewa_penyusutan'] = 0;
      r['servis_kantor'] = 0;
    }
    _rows[lastIdx]['sewa_penyusutan'] = totSewa;
    _rows[lastIdx]['servis_kantor'] = totServis;
  }

  Map<String, num> _sumTotals() {
    num penjualan = 0,
        hpp = 0,
        labaKotor = 0,
        bebanUsaha = 0,
        sewa = 0,
        servis = 0,
        biayaLain = 0,
        labaBersih = 0;
    for (final r in _rows) {
      penjualan += _num(r['penjualan']);
      hpp += _num(r['hpp']);
      labaKotor += _num(r['laba_kotor']);
      bebanUsaha += _num(r['beban_usaha']);
      sewa += _num(r['sewa_penyusutan']);
      servis += _num(r['servis_kantor']);
      biayaLain += _num(r['biaya_lain']);
      labaBersih += _num(r['laba_bersih']);
    }
    return {
      'penjualan': penjualan,
      'hpp': hpp,
      'labaKotor': labaKotor,
      'bebanUsaha': bebanUsaha,
      'sewa': sewa,
      'servis': servis,
      'biayaLain': biayaLain,
      'labaBersih': labaBersih,
    };
  }

  String _periodeLabel() {
    if (_startDate == null && _endDate == null) return 'Semua';
    final s = _startDate != null ? _fmtDate.format(_startDate!) : 'Semua';
    final e = _endDate != null ? _fmtDate.format(_endDate!) : 'Semua';
    return '$s — $e';
  }

  bool get _hasRange => _startDate != null && _endDate != null;

  Future<void> _deleteAll() async {
    if (!_hasRange) {
      await showTopToast(context, 'Pilih rentang tanggal dulu.', icon: Icons.info);
      return;
    }
    if (_rows.isEmpty) {
      await showTopToast(context, 'Tidak ada data pada filter ini.', icon: Icons.info);
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus semua data?'),
        content: Text('Semua data harian pada periode ${_periodeLabel()} akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _supabase
          .from('laba_bersih')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _fmtYmd.format(_startDate!))
          .lte('tanggal', _fmtYmd.format(_endDate!));

      final t = _sumTotals();
      await logService.addLog(
        aktivitas: 'Delete',
        halaman: 'Laporan Laba Bersih',
        detail:
        'Delete All | Periode: ${_periodeLabel()} | '
            'Penjualan: ${_fmtCur.format(t["penjualan"] ?? 0)} | '
            'HPP: ${_fmtCur.format(t["hpp"] ?? 0)} | '
            'Laba Kotor: ${_fmtCur.format(t["labaKotor"] ?? 0)} | '
            'Beban Usaha: ${_fmtCur.format(t["bebanUsaha"] ?? 0)} | '
            'Sewa&Peny: ${_fmtCur.format(t["sewa"] ?? 0)} | '
            'Servis: ${_fmtCur.format(t["servis"] ?? 0)} | '
            'Biaya Lain: ${_fmtCur.format(t["biayaLain"] ?? 0)} | '
            'Laba Bersih: ${_fmtCur.format(t["labaBersih"] ?? 0)}',
      );

      if (!mounted) return;
      await showTopToast(context, 'Semua data pada filter ini berhasil dihapus.', icon: Icons.check_circle);
      await _fetchData();
    } catch (e) {
      await showTopToast(context, 'Gagal hapus semua: $e', icon: Icons.warning_amber_rounded);
    }
  }

  Future<void> _deleteSelected() async {
    if (_selectedDates.isEmpty) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus data terpilih?'),
        content: Text('${_selectedDates.length} data harian akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _supabase
          .from('laba_bersih')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .inFilter('tanggal', _selectedDates.toList());

      await logService.addLog(
        aktivitas: 'Delete',
        halaman: 'Laporan Laba Bersih',
        detail: 'Delete Selected | Jumlah: ${_selectedDates.length} | Periode: ${_periodeLabel()}',
      );

      setState(() {
        _selectedDates.clear();
        _selectMode = false;
      });

      if (!mounted) return;
      await showTopToast(context, 'Data terpilih berhasil dihapus.', icon: Icons.check_circle);
      await _fetchData();
    } catch (e) {
      await showTopToast(context, 'Gagal hapus: $e', icon: Icons.warning_amber_rounded);
    }
  }

  void _toggleSelectMode() {
    setState(() {
      _selectMode = !_selectMode;
      if (!_selectMode) _selectedDates.clear();
    });
  }

  bool _isAllVisibleSelected() {
    final visible = _rows.map((r) => r['tanggal']?.toString() ?? '').where((s) => s.isNotEmpty).toSet();
    return visible.isNotEmpty && _selectedDates.containsAll(visible);
  }

  void _toggleSelectAllVisible() {
    final visible = _rows.map((r) => r['tanggal']?.toString() ?? '').where((s) => s.isNotEmpty).toSet();
    setState(() {
      if (_isAllVisibleSelected()) {
        _selectedDates.removeAll(visible);
      } else {
        _selectedDates.addAll(visible);
      }
    });
  }

  // ===== EXPORT PDF =====
  Future<void> _exportPdf() async {
    if (_loading) {
      await showTopToast(context, 'Tunggu, data masih dimuat…', icon: Icons.hourglass_bottom_rounded);
      return;
    }
    if (_rows.isEmpty) {
      await showTopToast(context, 'Tidak ada data untuk diekspor.', icon: Icons.info_rounded);
      return;
    }

    final doc = pw.Document();
    final t = _sumTotals();

    final headers = _headers;
    final data = <List<String>>[
      [
        _periodeLabel(),
        _fmtCur.format(t['penjualan'] ?? 0),
        _fmtCur.format(t['hpp'] ?? 0),
        _fmtCur.format(t['labaKotor'] ?? 0),
        _fmtCur.format(t['bebanUsaha'] ?? 0),
        _fmtCur.format(t['sewa'] ?? 0),
        _fmtCur.format(t['servis'] ?? 0),
        _fmtCur.format(t['biayaLain'] ?? 0),
        _fmtCur.format(t['labaBersih'] ?? 0),
      ],
    ];

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(24),
        header: (ctx) => pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Rekap Mutasi Laba Bersih', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
            pw.Text(_periodeLabel(), style: const pw.TextStyle(fontSize: 10)),
          ],
        ),
        footer: (ctx) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text('Hal. ${ctx.pageNumber}/${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 10)),
        ),
        build: (ctx) => [
          pw.TableHelper.fromTextArray(
            headers: headers,
            data: data,
            headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
            cellStyle: const pw.TextStyle(fontSize: 9),
            cellAlignment: pw.Alignment.centerRight,
            headerAlignment: pw.Alignment.center,
            cellAlignments: const {0: pw.Alignment.centerLeft},
            border: pw.TableBorder.all(color: PdfColors.grey600, width: .3),
          ),
        ],
      ),
    );

    try {
      await Printing.layoutPdf(onLayout: (_) async => doc.save());
      if (!mounted) return;
      await showTopToast(context, 'PDF siap dicetak / dibagikan', icon: Icons.check_circle_rounded);
    } catch (e) {
      if (!mounted) return;
      await showTopToast(context, 'Gagal membuat PDF: $e', icon: Icons.warning_amber_rounded);
    }
  }

  // ===== UI =====
  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(bodyColor: Colors.black87, displayColor: Colors.black87),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.22,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: () => Navigator.of(context).maybePop(),
                splashRadius: 22,
              ),
              title: const Text('Laporan Laba Bersih'),
              actions: [
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _toggleSelectMode,
                  icon: Icon(_selectMode ? Icons.check_box : Icons.check_box_outline_blank, color: Colors.black87),
                  label: Text(_selectMode ? 'Selesai' : 'Pilih Data',
                      style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _deleteAll,
                  icon: const Icon(Icons.delete_forever, color: Color(0xFF8E101A)),
                  label: const Text('Hapus Semua',
                      style: TextStyle(color: Color(0xFF8E101A), fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ElevatedButton.icon(
                    onPressed: _exportPdf,
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('Export PDF'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF2F2F2),
                      foregroundColor: Colors.black,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    ),
                  ),
                ),
              ],
            ),
            bottomNavigationBar: !_selectMode
                ? null
                : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 10, offset: const Offset(0, -4)),
                  ],
                  border: Border(top: BorderSide(color: Colors.black.withOpacity(.08))),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text('${_selectedDates.length} dipilih',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    OutlinedButton.icon(
                      onPressed: _rows.isEmpty ? null : _toggleSelectAllVisible,
                      icon: Icon(_isAllVisibleSelected() ? Icons.select_all : Icons.checklist),
                      label: Text(_isAllVisibleSelected() ? 'Batalkan Semua' : 'Pilih Semua'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: () => setState(() {
                        _selectedDates.clear();
                        _selectMode = false;
                      }),
                      child: const Text('Batal'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF8E101A), foregroundColor: Colors.white),
                      onPressed: _selectedDates.isEmpty ? null : _deleteSelected,
                      icon: const Icon(Icons.delete),
                      label: const Text('Hapus Terpilih'),
                    ),
                  ],
                ),
              ),
            ),
            body: SafeArea(
              top: false,
              minimum: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: LayoutBuilder(
                builder: (context, c) {
                  final minTotal = _baseWidths.reduce((a, b) => a + b);
                  final available = max(0.0, c.maxWidth - 24);
                  final totalW = max(available, minTotal.toDouble());
                  final scale = totalW / minTotal;
                  final widths = _baseWidths.map((w) => w * scale).toList();
                  final tableWidth = widths.reduce((a, b) => a + b);

                  // ukur tinggi filter bar agar posisi badge pas
                  _measureFilterBarHeight();

                  const double kTopGap = 8; // SizedBox(8) sebelum filter
                  const double kBetweenFilterAndTable = 10; // SizedBox(10) sesudah filter
                  final double badgeTop = kTopGap + _filterBarHeight + kBetweenFilterAndTable;

                  // ruang cadangan untuk menghindari badge menimpa header
                  final double reservedForBadge =
                  (_sortColumnIndex != null) ? _kStickyBadgeReservedHeight : 0;

                  return Stack(
                    children: [
                      // Layer 1: konten scrollable
                      Scrollbar(
                        thumbVisibility: true,
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: kTopGap),
                              _filterBar(),
                              const SizedBox(height: kBetweenFilterAndTable),
                              // sisakan space untuk badge agar tidak menimpa header:
                              SizedBox(height: reservedForBadge),
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.black.withOpacity(0.05),
                                        blurRadius: 14,
                                        offset: const Offset(0, 6))
                                  ],
                                ),
                                padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                                child: Column(
                                  children: [
                                    Scrollbar(
                                      controller: _hHeader,
                                      thumbVisibility: true,
                                      child: SingleChildScrollView(
                                        controller: _hHeader,
                                        scrollDirection: Axis.horizontal,
                                        child: SizedBox(
                                          width: (_selectMode ? 54.0 : 0) + tableWidth,
                                          child: _buildHeader(widths),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Scrollbar(
                                      controller: _hBody,
                                      thumbVisibility: true,
                                      notificationPredicate: (n) => n.depth == 1,
                                      child: SingleChildScrollView(
                                        controller: _hBody,
                                        scrollDirection: Axis.horizontal,
                                        child: SizedBox(
                                          width: (_selectMode ? 54.0 : 0) + tableWidth,
                                          child: _loading
                                              ? const Padding(
                                            padding: EdgeInsets.all(24.0),
                                            child: Center(child: CircularProgressIndicator()),
                                          )
                                              : (_rows.isEmpty
                                              ? _buildPlaceholder(widths)
                                              : _buildDailyRows(widths)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Layer 2: badge sticky kiri
                      Positioned(
                        left: 16,
                        top: badgeTop,
                        child: _sortBadgeFixed(),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _filterBar() {
    return Container(
      key: _filterBarKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Bar atas: judul + aksi kanan
          Row(
            children: [
              const Text('Periode (Rentang)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _openRangePicker,
                icon: const Icon(Icons.date_range, size: 18),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFE4E9),
                  foregroundColor: Colors.black,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                    side: const BorderSide(color: Colors.black, width: 1),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
                label: const Text('Rentang Tanggal'),
              ),
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: _clearDates,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.black, width: 1),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                child: const Text('Clear'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Bar kedua: pill tanggal
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: _openRangePicker,
                  borderRadius: BorderRadius.circular(40),
                  child: _DatePill(
                    label: 'Tanggal Awal',
                    value: _startDate == null ? '—' : _fmtDate.format(_startDate!),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(width: 8),
              Expanded(
                child: InkWell(
                  onTap: _openRangePicker,
                  borderRadius: BorderRadius.circular(40),
                  child: _DatePill(
                    label: 'Tanggal Akhir',
                    value: _endDate == null ? '—' : _fmtDate.format(_endDate!),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Preset chips
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _PresetChip(text: 'Semua Data', onTap: () => _applyPreset('all')),
              _PresetChip(text: 'Bulan Ini', onTap: () => _applyPreset('month')),
              _PresetChip(text: '100 Hari Terakhir', onTap: () => _applyPreset('100')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(List<double> widths) {
    const double kSideInset = 20;
    final headers =
    _selectMode ? [' ', ..._cols.map((c) => c.title).toList()] : _cols.map((c) => c.title).toList();
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;

    Widget buildSortable(int logicalIndex) {
      final colIndex = _selectMode ? logicalIndex - 1 : logicalIndex;
      if (_selectMode && logicalIndex == 0) return const SizedBox();

      final active = _sortColumnIndex == colIndex;
      final icon = !active ? Icons.unfold_more : (_sortAscending ? Icons.arrow_upward : Icons.arrow_downward);

      return InkWell(
        onTap: () => _applySort(columnIndex: colIndex),
        onLongPress: () async {
          final pos = const RelativeRect.fromLTRB(0, 80, 0, 0);
          final choice = await showMenu<String>(
            context: context,
            position: pos,
            items: const [
              PopupMenuItem(value: 'asc', child: Text('Urut Naik (ASC)')),
              PopupMenuItem(value: 'desc', child: Text('Urut Turun (DESC)')),
              PopupMenuItem(value: 'reset', child: Text('Reset ke Tanggal')),
            ],
          );
          if (!mounted || choice == null) return;
          if (choice == 'asc') _applySort(columnIndex: colIndex, ascending: true);
          if (choice == 'desc') _applySort(columnIndex: colIndex, ascending: false);
          if (choice == 'reset') {
            _sortColumnIndex = null;
            _sortAscending = true;
            _applySort();
          }
        },
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Text(
                  headers[logicalIndex],
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    color: active ? const Color(0xFF8E101A) : Colors.black87,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Icon(icon, size: 16, color: active ? const Color(0xFF8E101A) : Colors.black54),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kSideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: {for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i])},
        children: [
          TableRow(children: List.generate(headers.length, (i) => buildSortable(i))),
        ],
      ),
    );
  }

  Widget _buildDailyRows(List<double> widths) {
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;

    return Column(
      children: List.generate(_rows.length, (i) {
        final r = _rows[i];
        final dateStr = (r['tanggal'] ?? '').toString();
        final isSelected = _selectedDates.contains(dateStr);

        final cells = <Widget>[
          _cellText(_fmtDate.format(DateTime.parse(dateStr))),
          _cellText(_fmtCur.format(_num(r['penjualan']))),
          _cellText(_fmtCur.format(_num(r['hpp']))),
          _cellText(_fmtCur.format(_num(r['laba_kotor']))),
          _cellText(_fmtCur.format(_num(r['beban_usaha']))),
          _cellText(_fmtCur.format(_num(r['sewa_penyusutan']))),
          _cellText(_fmtCur.format(_num(r['servis_kantor']))),
          _cellText(_fmtCur.format(_num(r['biaya_lain']))),
          _cellText(_fmtCur.format(_num(r['laba_bersih']))),
        ];

        return GestureDetector(
          onTap: _selectMode && dateStr.isNotEmpty
              ? () {
            setState(() {
              if (isSelected) {
                _selectedDates.remove(dateStr);
              } else {
                _selectedDates.add(dateStr);
              }
            });
          }
              : null,
          child: Container(
            margin: EdgeInsets.only(top: i == 0 ? 12 : 8, left: 6, right: 6),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
            decoration: BoxDecoration(
              color: _selectMode && isSelected ? const Color(0xFFFFE4E9) : Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: _selectMode && isSelected ? const Color(0xFF8E101A) : Colors.black.withOpacity(0.05),
                width: _selectMode && isSelected ? 2 : 1,
              ),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Table(
              columnWidths: {for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i])},
              children: [
                TableRow(children: [
                  if (_selectMode)
                    Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Checkbox(
                        value: isSelected,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              _selectedDates.add(dateStr);
                            } else {
                              _selectedDates.remove(dateStr);
                            }
                          });
                        },
                        side: const BorderSide(color: Colors.black87),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                    ),
                  ...cells,
                ]),
              ],
            ),
          ),
        );
      }),
    );
  }

  Widget _buildPlaceholder(List<double> widths) {
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;
    return Container(
      margin: const EdgeInsets.only(top: 12, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: Table(
        columnWidths: {for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i])},
        children: [TableRow(children: List.generate(widthsAdj.length, (i) => _cellText('–')))],
      ),
    );
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _rows = [];
      _selectedDates.clear();
      _selectMode = false;
    });
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _startDate ?? DateTime(now.year, now.month, 1),
      end: _endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      builder: (ctx, child) => Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
      await _fetchData();
    }
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();
    if (code == 'all') {
      _startDate = DateTime(2020, 1, 1);
      _endDate = now;
    } else if (code == 'month') {
      _startDate = DateTime(now.year, now.month, 1);
      _endDate = DateTime(now.year, now.month + 1, 0);
    } else if (code == '100') {
      _startDate = now.subtract(const Duration(days: 99));
      _endDate = now;
    }
    setState(() {});
    await _fetchData();
  }

  Widget _cellText(String text) => Container(
    alignment: Alignment.center,
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Text(text,
        textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
  );
}

class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

Future<void> showTopToast(
    BuildContext context,
    String message, {
      IconData icon = Icons.check_circle_rounded,
      Duration duration = const Duration(milliseconds: 1600),
    }) async {
  if (!(context as Element).mounted) return;
  await showGeneralDialog(
    context: context,
    barrierColor: Colors.transparent,
    barrierDismissible: true,
    barrierLabel: 'dismiss',
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (ctx, _, __) {
      Future.delayed(duration, () {
        if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
      });
      return SafeArea(
        child: Align(
          alignment: const Alignment(0, -0.92),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                      child:
                      Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
      return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child));
    },
  );
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
