import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/app_background.dart';

// PDF
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

class LaporanIncomeMatoPage extends StatefulWidget {
  final String idUsaha;
  const LaporanIncomeMatoPage({super.key, required this.idUsaha});

  @override
  State<LaporanIncomeMatoPage> createState() => _LaporanIncomeMatoPageState();
}

bool _noticeShown = false;

class _LaporanIncomeMatoPageState extends State<LaporanIncomeMatoPage>
    with WidgetsBindingObserver {
  final _supabase = Supabase.instance.client;
  final logService = LogService();

  DateTime? _startDate;
  DateTime? _endDate;

  final _fmtDate = DateFormat('d MMM yyyy', 'id_ID');
  final _fmtYmd  = DateFormat('yyyy-MM-dd');
  final _fmtCur  = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  // data tabel
  List<Map<String, dynamic>> _rows = [];
  bool _loading = false;

  // sinkron scroll
  final _hHeader = ScrollController();
  final _hBody   = ScrollController();
  final _vBody   = ScrollController();

  // guard ping-pong sinkronisasi header <-> body
  bool _syncing = false;

  // ====== SELECT MODE (konsisten dengan halaman lain) ======
  bool _selectMode = false;
  final Set<String> _selectedIds = {};

  // header & lebar kolom (diskalakan responsif)
  final List<String> _headers = const [
    'Periode',
    'Laba Bersih',
    'Bagian Karyawan',
    'Bagian Pemilik Usaha',
    'Total Mato',
    'Income/Mato',
  ];
  final List<double> _baseWidths = const [220, 180, 180, 180, 140, 170];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    final now = DateTime.now();
    _startDate = DateTime(now.year, now.month, 1);
    _endDate   = DateTime(now.year, now.month + 1, 0);

    _hHeader.addListener(() {
      if (_syncing) return;
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _syncing = true;
        _hBody.jumpTo(_hHeader.offset);
        _syncing = false;
      }
    });
    _hBody.addListener(() {
      if (_syncing) return;
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _syncing = true;
        _hHeader.jumpTo(_hBody.offset);
        _syncing = false;
      }
    });

    _fetchData();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _hHeader.dispose();
    _hBody.dispose();
    _vBody.dispose();
    super.dispose();
  }

  // Dipanggil saat orientasi/ukuran berubah
  @override
  void didChangeMetrics() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _clampScrollOffsets();
    });
    super.didChangeMetrics();
  }

  void _clampScrollOffsets() {
    void clampOne(ScrollController c) {
      if (!c.hasClients) return;
      final pos = c.position;
      final target = c.offset.clamp(pos.minScrollExtent, pos.maxScrollExtent);
      if (target != c.offset) c.jumpTo(target.toDouble());
    }
    clampOne(_hHeader);
    clampOne(_hBody);
    clampOne(_vBody);
  }

  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  void _showInitialNotice() {
    showDialog(
      context: context,
      useRootNavigator: true,
      barrierDismissible: true,
      builder: (ctx) {
        final w = MediaQuery.of(ctx).size.width;
        final bodyMaxW = w < 480 ? (w - 32) : 440.0;

        final theme = Theme.of(ctx).copyWith(
          dialogTheme: Theme.of(ctx).dialogTheme.copyWith(
            backgroundColor: Colors.white,
            titleTextStyle: const TextStyle(
                color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
            contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
          ),
          textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(foregroundColor: Colors.black87),
          ),
        );

        return Theme(
          data: theme,
          child: AlertDialog(
            scrollable: true,
            backgroundColor: Colors.white,
            insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            clipBehavior: Clip.antiAlias,
            titlePadding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            contentPadding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            actionsPadding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Icon(Icons.info_outline_rounded, color: Colors.black87),
                SizedBox(width: 8),
                Expanded(
                  child: Text('Catatan Income per Mato',
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: bodyMaxW),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 4),
                    Text(
                      'Perhitungan Income per Mato idealnya memakai rentang MINIMAL 1 bulan.',
                      style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Jika rentang < 30 hari, angka yang tampil hanya indikatif (untuk gambaran saja).',
                      style: TextStyle(color: Colors.black87),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Saran: pilih filter “Bulan Ini” atau atur rentang tanggal ≥ 1 bulan.',
                      style: TextStyle(color: Colors.black87),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Oke, mengerti'),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
    if (!_noticeShown) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _showInitialNotice();
        _noticeShown = true;
      });
    }
  }

  int? get _rangeDays =>
      (_startDate != null && _endDate != null)
          ? _endDate!.difference(_startDate!).inDays + 1
          : null;

  Widget _rangeHintBadge() {
    if (_rangeDays == null) return const SizedBox.shrink();
    final bad = _rangeDays! < 30;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: bad ? Colors.orange.shade50 : Colors.green.shade50,
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(bad ? Icons.warning_amber_rounded : Icons.check_circle_rounded,
              size: 16, color: bad ? Colors.orange : Colors.green),
          const SizedBox(width: 8),
          Text(
            'Rentang aktif: $_rangeDays hari • minimal 30 hari',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: bad ? Colors.orange.shade800 : Colors.green.shade800,
            ),
          ),
        ],
      ),
    );
  }

  // ===================== DATA =====================
  Future<void> _fetchData() async {
    setState(() => _loading = true);
    try {
      var qb = _supabase
          .from('income_per_mato')
          .select(
        'id, tanggal_awal, tanggal_akhir, total_laba_bersih, bagian_karyawan, bagian_direksi, total_mato, income_per_mato',
      )
          .eq('id_usaha', widget.idUsaha);

      if (_startDate != null) {
        qb = qb.gte('tanggal_akhir', _fmtYmd.format(_startDate!));
      }
      if (_endDate != null) {
        qb = qb.lte('tanggal_awal', _fmtYmd.format(_endDate!));
      }

      final data = await qb.order('tanggal_awal');
      if (!mounted) return;
      setState(() {
        _rows = List<Map<String, dynamic>>.from(data);
        // reset seleksi agar tidak nyangkut setelah refresh
        _selectedIds.clear();
        _selectMode = false;
      });

      if (_vBody.hasClients) _vBody.jumpTo(0);
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal memuat data: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 1800),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ===================== DELETE =====================
  Future<void> _deleteAll() async {
    if (_rows.isEmpty) {
      await showTopToast(context, 'Tidak ada data pada rentang ini.', icon: Icons.info_rounded);
      return;
    }
    if (_startDate == null || _endDate == null) {
      await showTopToast(context, 'Pilih rentang tanggal dulu.', icon: Icons.info_rounded);
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus semua data?'),
        content: Text('Semua income per mato pada periode ${_rangeTitle()} akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );

    if (ok != true) return;

    try {
      await _supabase
          .from('income_per_mato')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal_akhir', _fmtYmd.format(_startDate!))
          .lte('tanggal_awal', _fmtYmd.format(_endDate!));

      await logService.addLog(
        aktivitas: 'Delete',
        halaman: 'Laporan Income per Mato',
        detail: 'Delete All | Periode: ${_rangeTitle()}',
      );

      await showTopToast(context, 'Semua data pada filter ini berhasil dihapus.', icon: Icons.check_circle_rounded);
      await _fetchData();
    } catch (e) {
      await showTopToast(context, 'Gagal hapus semua: $e', icon: Icons.warning_amber_rounded);
    }
  }

  Future<void> _deleteSelected() async {
    if (_selectedIds.isEmpty) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus data terpilih?'),
        content: Text('${_selectedIds.length} data akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _supabase
          .from('income_per_mato')
          .delete()
          .inFilter('id', _selectedIds.toList());

      await logService.addLog(
        aktivitas: 'Delete',
        halaman: 'Laporan Income per Mato',
        detail: 'Delete Selected | Jumlah: ${_selectedIds.length} | Periode: ${_rangeTitle()}',
      );

      setState(() {
        _selectedIds.clear();
        _selectMode = false;
      });

      await showTopToast(context, 'Data terpilih berhasil dihapus.', icon: Icons.check_circle_rounded);
      await _fetchData();
    } catch (e) {
      await showTopToast(context, 'Gagal hapus: $e', icon: Icons.warning_amber_rounded);
    }
  }

  // ===================== FILTER UI =====================
  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _startDate ?? DateTime(now.year, now.month, 1),
      end: _endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate   = picked.end;
      });
      _fetchData();
    }
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate   = null;
      _rows = [];
      _selectedIds.clear();
      _selectMode = false;
    });
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();
    if (code == 'all') {
      setState(() {
        _startDate = DateTime(2020, 1, 1);
        _endDate   = now;
      });
    } else if (code == 'month') {
      setState(() {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate   = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '100') {
      setState(() {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate   = now;
      });
    }
    await _fetchData();
  }

  String _rangeTitle() {
    final s = _startDate != null ? _fmtDate.format(_startDate!) : 'Semua';
    final e = _endDate != null ? _fmtDate.format(_endDate!) : 'Semua';
    return '$s — $e';
  }

  Map<String, num> _sumTotals() {
    num laba = 0, kary = 0, dir = 0, mato = 0;
    for (final r in _rows) {
      laba += _num(r['total_laba_bersih']);
      kary += _num(r['bagian_karyawan']);
      dir  += _num(r['bagian_direksi']);
      mato += _num(r['total_mato']);
    }
    final incomeMatoAgg = mato > 0 ? (kary / mato) : 0;
    return {
      'laba': laba,
      'karyawan': kary,
      'direksi': dir,
      'mato': mato,
      'incomeMato': incomeMatoAgg,
    };
  }

  // ===================== EXPORT PDF =====================
  Future<void> _exportPdf() async {
    if (_loading) {
      await showTopToast(context, 'Tunggu, data masih dimuat…', icon: Icons.hourglass_bottom_rounded);
      return;
    }
    if (_rows.isEmpty) {
      await showTopToast(context, 'Tidak ada data untuk diekspor.', icon: Icons.info_rounded);
      return;
    }

    final doc = pw.Document();

    final table = <List<String>>[];
    table.add(_headers);

    for (final r in _rows) {
      final a = DateTime.parse(r['tanggal_awal'].toString());
      final b = DateTime.parse(r['tanggal_akhir'].toString());
      table.add([
        '${DateFormat('d MMM', 'id_ID').format(a)} - ${_fmtDate.format(b)}',
        _fmtCur.format(_num(r['total_laba_bersih'])),
        _fmtCur.format(_num(r['bagian_karyawan'])),
        _fmtCur.format(_num(r['bagian_direksi'])),
        NumberFormat.decimalPattern('id_ID').format(_num(r['total_mato'])),
        _fmtCur.format(_num(r['income_per_mato'])),
      ]);
    }

    final t = _sumTotals();
    table.add([
      'TOTAL',
      _fmtCur.format(t['laba'] ?? 0),
      _fmtCur.format(t['karyawan'] ?? 0),
      _fmtCur.format(t['direksi'] ?? 0),
      NumberFormat.decimalPattern('id_ID').format(t['mato'] ?? 0),
      _fmtCur.format(t['incomeMato'] ?? 0),
    ]);

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        header: (ctx) => pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Rekap Mutasi Income per Mato', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
            pw.Text(_rangeTitle(), style: const pw.TextStyle(fontSize: 10)),
          ],
        ),
        footer: (ctx) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text('Hal. ${ctx.pageNumber}/${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 10)),
        ),
        build: (ctx) => [
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            data: table,
            headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
            cellStyle: const pw.TextStyle(fontSize: 9),
            cellAlignment: pw.Alignment.centerRight,
            headerAlignment: pw.Alignment.center,
            cellAlignments: const { 0: pw.Alignment.centerLeft },
            border: pw.TableBorder.all(color: PdfColors.grey600, width: 0.3),
            columnWidths: const {
              0: pw.FlexColumnWidth(1.8),
              1: pw.FlexColumnWidth(1.3),
              2: pw.FlexColumnWidth(1.4),
              3: pw.FlexColumnWidth(1.3),
              4: pw.FlexColumnWidth(1.0),
              5: pw.FlexColumnWidth(1.2),
            },
          ),
        ],
      ),
    );

    await Printing.layoutPdf(onLayout: (format) async => doc.save());
    await showTopToast(context, 'PDF siap dicetak / dibagikan', icon: Icons.check_circle_rounded);
  }

  // ==== Toast kecil di dekat atas (seragam) ====
  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle_rounded,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    if (!context.mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(duration, () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });
        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        message,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
        );
      },
    );
  }

  // ===================== UI =====================
  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(bodyColor: Colors.black87, displayColor: Colors.black87),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.22,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            extendBodyBehindAppBar: false,
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: () => Navigator.of(context).maybePop(),
                splashRadius: 22,
              ),
              title: const Text('Laporan Income per Mato'),
              actions: [
                // Toggle Select Mode
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : () {
                    setState(() {
                      _selectMode = !_selectMode;
                      if (!_selectMode) _selectedIds.clear();
                    });
                  },
                  icon: Icon(_selectMode ? Icons.check_box : Icons.check_box_outline_blank, color: Colors.black87),
                  label: Text(_selectMode ? 'Selesai' : 'Pilih Data',
                      style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                // Delete All
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _deleteAll,
                  icon: const Icon(Icons.delete_forever, color: Color(0xFF8E101A)),
                  label: const Text('Hapus Semua',
                      style: TextStyle(color: Color(0xFF8E101A), fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                IconButton(
                  icon: const Icon(Icons.picture_as_pdf),
                  tooltip: 'Export PDF',
                  onPressed: _exportPdf,
                ),
                const SizedBox(width: 6),
              ],
            ),

            // Bottom bar saat select mode (konsisten)
            bottomNavigationBar: !_selectMode ? null : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 10, offset: const Offset(0, -4))],
                  border: Border(top: BorderSide(color: Colors.black.withOpacity(.08))),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text('${_selectedIds.length} dipilih',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    OutlinedButton.icon(
                      onPressed: _rows.isEmpty ? null : _toggleSelectAll,
                      icon: Icon(_isAllSelected() ? Icons.select_all : Icons.checklist),
                      label: Text(_isAllSelected() ? 'Batalkan Semua' : 'Pilih Semua'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: () => setState(() {
                        _selectedIds.clear();
                        _selectMode = false;
                      }),
                      child: const Text('Batal'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF8E101A),
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _selectedIds.isEmpty ? null : _deleteSelected,
                      icon: const Icon(Icons.delete),
                      label: const Text('Hapus Terpilih'),
                    ),
                  ],
                ),
              ),
            ),

            body: SafeArea(
              top: false,
              minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(child: _filterBar()),
                  const SliverToBoxAdapter(child: SizedBox(height: 10)),
                  SliverToBoxAdapter(child: _tableArea()),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ===== Area tabel sebagai widget terpisah (tinggi adaptif) =====
  Widget _tableArea() {
    final screenH = MediaQuery.of(context).size.height;
    final bodyHeight = min(max(300.0, screenH * 0.50), 560.0);

    return LayoutBuilder(
      builder: (context, c) {
        // Skala kolom responsif
        final minTotal  = _baseWidths.reduce((a, b) => a + b);
        final available = c.maxWidth - 24;
        final totalW    = max(available, minTotal.toDouble());
        final scale     = totalW / minTotal;
        final widths    = _baseWidths.map((w) => w * scale).toList();
        final tableW    = widths.reduce((a, b) => a + b);

        // Tambah ruang checkbox ketika select mode
        final headerBodyWidth = (_selectMode ? 54.0 : 0) + tableW;

        return Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.35),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 14, offset: const Offset(0, 6))],
          ),
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
          child: Column(
            children: [
              // HEADER (sinkron scroll H)
              Scrollbar(
                controller: _hHeader,
                thumbVisibility: true,
                child: SingleChildScrollView(
                  controller: _hHeader,
                  scrollDirection: Axis.horizontal,
                  child: SizedBox(
                    width: headerBodyWidth,                 // ⬅️ penting
                    child: _buildHeader(widths),            // (boleh tanpa kolom checkbox)
                  ),
                ),
              ),

              const SizedBox(height: 8),

              // BODY (sinkron scroll V & H)
              SizedBox(
                height: bodyHeight,
                child: Scrollbar(
                  controller: _vBody,
                  thumbVisibility: true,
                  child: SingleChildScrollView(
                    controller: _vBody,
                    child: Scrollbar(
                      controller: _hBody,
                      notificationPredicate: (n) => n.depth == 1,
                      thumbVisibility: true,
                      child: SingleChildScrollView(
                        controller: _hBody,
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: headerBodyWidth,           // ⬅️ match header
                          child: _loading
                              ? const Padding(
                            padding: EdgeInsets.all(24.0),
                            child: Center(child: CircularProgressIndicator()),
                          )
                              : (_rows.isEmpty
                              ? _buildPlaceholder(widths) // placeholder boleh tanpa kolom checkbox
                              : Column(
                            children: List.generate(_rows.length, (i) {
                              final r          = _rows[i];
                              final id         = r['id'].toString();
                              final isSelected = _selectedIds.contains(id);

                              final a = DateTime.parse(r['tanggal_awal'].toString());
                              final b = DateTime.parse(r['tanggal_akhir'].toString());

                              // konten sel
                              final cells = <Widget>[
                                _cellText('${DateFormat('d MMM', 'id_ID').format(a)} - ${_fmtDate.format(b)}'),
                                _cellText(_fmtCur.format(_num(r['total_laba_bersih']))),
                                _cellText(_fmtCur.format(_num(r['bagian_karyawan']))),
                                _cellText(_fmtCur.format(_num(r['bagian_direksi']))),
                                _cellText(NumberFormat.decimalPattern('id_ID').format(_num(r['total_mato']))),
                                _cellText(_fmtCur.format(_num(r['income_per_mato']))),
                              ];

                              // lebar kolom saat select mode
                              final widthsAdj = _selectMode ? [54.0, ...widths] : widths;

                              return GestureDetector(
                                onTap: _selectMode
                                    ? () => setState(() {
                                  if (isSelected) {
                                    _selectedIds.remove(id);
                                  } else {
                                    _selectedIds.add(id);
                                  }
                                })
                                    : null,
                                child: Container(
                                  margin: EdgeInsets.only(top: i == 0 ? 12 : 8, left: 6, right: 6),
                                  padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                                  decoration: BoxDecoration(
                                    color: _selectMode && isSelected ? const Color(0xFFFFE4E9) : Colors.white,
                                    borderRadius: BorderRadius.circular(22),
                                    border: Border.all(
                                      color: _selectMode && isSelected
                                          ? const Color(0xFF8E101A)
                                          : Colors.black.withOpacity(0.05),
                                      width: _selectMode && isSelected ? 2 : 1,
                                    ),
                                    boxShadow: [
                                      BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))
                                    ],
                                  ),
                                  child: Table(
                                    columnWidths: {
                                      for (int j = 0; j < widthsAdj.length; j++)
                                        j: FixedColumnWidth(widthsAdj[j]),
                                    },
                                    children: [
                                      TableRow(
                                        children: [
                                          if (_selectMode)
                                            Container(
                                              alignment: Alignment.center,
                                              padding: const EdgeInsets.symmetric(vertical: 8),
                                              child: Checkbox(
                                                value: isSelected,
                                                onChanged: (v) => setState(() {
                                                  if (v == true) {
                                                    _selectedIds.add(id);
                                                  } else {
                                                    _selectedIds.remove(id);
                                                  }
                                                }),
                                                side: const BorderSide(color: Colors.black87),
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                                activeColor: const Color(0xFF8E101A),
                                              ),
                                            ),
                                          ...cells,
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }),
                          )),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ===== helper UI =====
  Widget _filterBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Tanggal (Rentang)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _openRangePicker,
              icon: const Icon(Icons.date_range, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFE4E9),
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                  side: const BorderSide(color: Colors.black, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
              label: const Text('Rentang Tanggal'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _clearDates,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.black, width: 1),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: _openRangePicker,
                borderRadius: BorderRadius.circular(40),
                child: _DatePill(label: 'Tanggal Awal', value: _startDate == null ? '—' : _fmtDate.format(_startDate!)),
              ),
            ),
            const SizedBox(width: 8),
            const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            Expanded(
              child: InkWell(
                onTap: _openRangePicker,
                borderRadius: BorderRadius.circular(40),
                child: _DatePill(label: 'Tanggal Akhir', value: _endDate == null ? '—' : _fmtDate.format(_endDate!)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _PresetChip(text: 'Semua Data', onTap: () => _applyPreset('all')),
            _PresetChip(text: 'Bulan Ini',   onTap: () => _applyPreset('month')),
            _PresetChip(text: '100 Hari Terakhir', onTap: () => _applyPreset('100')),
          ],
        ),
        const SizedBox(height: 8),
        _rangeHintBadge(),
        Align(
          alignment: Alignment.centerRight,
          child: ElevatedButton.icon(
            onPressed: _exportPdf,
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text('Export PDF'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF2F2F2),
              foregroundColor: Colors.black,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader(List<double> widths) {
    const double kSideInset = 20;

    // ⬇️ samakan dengan Laba Bersih
    final headers   = _selectMode ? [' ', ..._headers] : _headers;
    final widthsAdj = _selectMode ? [54.0, ...widths]  : widths;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kSideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: {
          for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i])
        },
        children: [
          TableRow(
            children: List.generate(headers.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  headers[i],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder(List<double> widths) {
    return Container(
      margin: const EdgeInsets.only(top: 12, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: Table(
        columnWidths: {for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])},
        children: [TableRow(children: List.generate(widths.length, (i) => _cellText('–')))],
      ),
    );
  }

  // ===== util kecil =====
  bool _isAllSelected() {
    final ids = _rows.map((r) => r['id'].toString()).toSet();
    return ids.isNotEmpty && _selectedIds.containsAll(ids);
  }

  void _toggleSelectAll() {
    final ids = _rows.map((r) => r['id'].toString()).toSet();
    setState(() {
      if (_isAllSelected()) {
        _selectedIds.removeAll(ids);
      } else {
        _selectedIds.addAll(ids);
      }
    });
  }

  Widget _cellText(String text) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10), // ⬅️ tambah horizontal
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        overflow: TextOverflow.ellipsis, // aman kalau sel sempit
        maxLines: 1,
      ),
    );
  }
}

class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
