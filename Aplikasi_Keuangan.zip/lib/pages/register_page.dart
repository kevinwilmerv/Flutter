import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/services.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'dart:async';


class UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    return newValue.copyWith(
      text: newValue.text.toUpperCase(),
      selection: newValue.selection,
    );
  }
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

// ==== Toast hitam kecil seragam (top) ====
Future<void> showTopToast(
    BuildContext context,
    String message, {
      IconData icon = Icons.check_circle_rounded,
      Duration duration = const Duration(milliseconds: 1600),
    }) async {
  if (!(context as Element).mounted) return;
  await showGeneralDialog(
    context: context,
    barrierColor: Colors.transparent,
    barrierDismissible: true,
    barrierLabel: 'dismiss',
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (ctx, _, __) {
      Future.delayed(duration, () {
        if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
      });
      return SafeArea(
        child: Align(
          alignment: const Alignment(0, -0.92),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      message,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
      return FadeTransition(
        opacity: anim,
        child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
      );
    },
  );
}

class _RegisterPageState extends State<RegisterPage> {
  final supabase = Supabase.instance.client;

  // controllers
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  final namausahaController = TextEditingController();
  final lokasiusahaController = TextEditingController();
  final adminKeyController = TextEditingController();
  final TextEditingController idUsahaController = TextEditingController();
  final TextEditingController idPreviewController =
  TextEditingController(text: 'USH - NAMA USAHA - LOKASI - XXX');
  Timer? _genDebounce; // ⬅️ baru

  String? selectedRole;
  String? selectedusaha; // (tidak dipakai lagi untuk staff, biarkan supaya tidak rusak referensi lama)
  String? generatedusahaId;
  List<Map<String, dynamic>> usahaList = [];

  bool _obscure = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchUsaha();
    namausahaController.addListener(_updateIdPreview);
    lokasiusahaController.addListener(_updateIdPreview);
    namausahaController.addListener(_scheduleGenerateId);   // ⬅️ baru
    lokasiusahaController.addListener(_scheduleGenerateId); // ⬅️ baru
    _updateIdPreview(); // set awal
  }

  void _scheduleGenerateId() {
    _genDebounce?.cancel();

    // Hanya generate jika Admin & dua field terisi
    if (selectedRole == 'admin_usaha' &&
        namausahaController.text.trim().isNotEmpty &&
        lokasiusahaController.text.trim().isNotEmpty) {
      _genDebounce = Timer(const Duration(milliseconds: 400), () async {
        final id = await generateusahaId();      // hit DB untuk nomor urut terbaru
        if (!mounted) return;
        setState(() {
          idUsahaController.text = id;           // nilai final yang dipakai saat daftar
        });
      });
    } else {
      // Belum cukup data -> kosongkan ID otomatis
      setState(() => idUsahaController.clear());
      _updateIdPreview(); // tetap perbarui preview placeholder (optional)
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
  }

  @override
  void dispose() {
    idPreviewController.dispose();
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    namausahaController.dispose();
    lokasiusahaController.dispose();
    adminKeyController.dispose();
    idUsahaController.dispose();
    super.dispose();
  }

  // ====== LOGO STRIP ======
  Widget _logoStrip() {
    const logos = <String>[
      'assets/IBIKKG.png',
      'assets/Kemendiktisaintek.png',
      'assets/OK_OCE.png',
      'assets/LOGOSR1.png',
    ];

    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        double h;
        if (w < 380) {
          h = 42;
        } else if (w < 600) {
          h = 54;
        } else if (w < 1024) {
          h = 66;
        } else {
          h = 78;
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Wrap(
            spacing: 20,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              for (final path in logos)
                Image.asset(
                  path,
                  height: h,
                  fit: BoxFit.contain,
                  filterQuality: FilterQuality.medium,
                ),
            ],
          ),
        );
      },
    );
  }


  // ====== Data ======
  Future<void> fetchUsaha() async {
    try {
      final response = await supabase.from('usaha').select();
      if (!mounted) return;
      setState(() {
        usahaList = List<Map<String, dynamic>>.from(response);
      });
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal memuat daftar usaha: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 1800),
      );
    }
  }

  String _onlyLetters(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z\s]'), ' ').trim();

  String _nameCode3(String nama) {
    final norm = _onlyLetters(nama);
    if (norm.isEmpty) return 'XXX';
    final parts = norm.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();

    if (parts.length == 1) {
      final w = parts.first;
      final c1 = w[0];
      final c2 = w.length >= 2 ? w[1] : w[0];
      final c3 = w[w.length - 1];
      return (c1 + c2 + c3).padRight(3, 'X').substring(0, 3);
    } else {
      final first = parts.first;
      final second = parts[1];
      final last = parts.last;
      final c1 = first[0];
      final c2 = second[0];
      final c3 = last[last.length - 1];
      return (c1 + c2 + c3).padRight(3, 'X').substring(0, 3);
    }
  }

  String _locCode3(String lokasi) {
    final norm = _onlyLetters(lokasi);
    if (norm.isEmpty) return 'XXX';
    final parts = norm.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();

    bool isVowel(String ch) => 'AEIOU'.contains(ch);

    if (parts.length == 1) {
      final w = parts.first;
      final c1 = w[0];

      // konsonan pertama setelah huruf pertama
      String c2 = w.substring(1).split('').firstWhere(
            (ch) => !isVowel(ch),
        orElse: () => w.length >= 2 ? w[1] : w[0],
      );

      // konsonan terakhir; jika tidak ada, pakai huruf terakhir
      String c3 = w.split('').reversed.firstWhere(
            (ch) => !isVowel(ch),
        orElse: () => w[w.length - 1],
      );

      return (c1 + c2 + c3).padRight(3, 'X').substring(0, 3);
    } else {
      final first = parts.first;
      final second = parts[1];
      final last = parts.last;
      final c1 = first[0];
      final c2 = second[0];
      final c3 = last[last.length - 1];
      return (c1 + c2 + c3).padRight(3, 'X').substring(0, 3);
    }
  }

  Future<String> generateusahaId() async {
    final nama = namausahaController.text;
    final lokasi = lokasiusahaController.text;

    final nameCode = _nameCode3(nama);   // contoh: AGG
    final locCode  = _locCode3(lokasi);  // contoh: JKT

    // Ambil semua id_usaha yang sudah ada
    final rows = await supabase.from('usaha').select('id_usaha');
    final ids = List<String>.from(rows.map((e) => (e['id_usaha'] ?? '').toString().toUpperCase()));

    // Cari nomor urut global terbesar (format USH-XXX-XXX-####)
    final reg = RegExp(r'^USH-[A-Z]{3}-[A-Z]{3}-(\d{3,})$');
    int maxN = 0;
    for (final id in ids) {
      final m = reg.firstMatch(id);
      if (m != null) {
        final n = int.tryParse(m.group(1)!) ?? 0;
        if (n > maxN) maxN = n;
      }
    }

    // Naikkan 1 dan pastikan unik
    int i = maxN + 1;
    while (true) {
      final candidate = 'USH-$nameCode-$locCode-${i.toString().padLeft(3, '0')}';
      if (!ids.contains(candidate)) {
        return candidate;
      }
      i++;
    }
  }

  String _onlyLettersDyn(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z\s]'), ' ').trim();

  String _nameCodeDyn(String nama) {
    final norm = _onlyLettersDyn(nama);
    if (norm.isEmpty) return '';
    final parts = norm.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();

    if (parts.length == 1) {
      final w = parts.first;
      final List<String> out = [];
      if (w.isNotEmpty) out.add(w[0]);
      if (w.length >= 2) out.add(w[1]);
      if (w.length >= 2) out.add(w[w.length - 1]);
      return out.join();
    } else {
      final first = parts.first;
      final second = parts.length >= 2 ? parts[1] : '';
      final last = parts.last;
      final List<String> out = [];
      if (first.isNotEmpty) out.add(first[0]);
      if (second.isNotEmpty) out.add(second[0]);
      if (last.isNotEmpty) out.add(last[last.length - 1]);
      return out.join();
    }
  }

  String _locCodeDyn(String lokasi) {
    final norm = _onlyLettersDyn(lokasi);
    if (norm.isEmpty) return '';
    final parts = norm.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    bool isVowel(String ch) => 'AEIOU'.contains(ch);

    if (parts.length == 1) {
      final w = parts.first;
      final List<String> out = [];
      if (w.isNotEmpty) out.add(w[0]);

      // konsonan pertama setelah huruf pertama (jika sudah ada)
      if (w.length >= 2) {
        String? c2;
        for (int i = 1; i < w.length; i++) {
          if (!isVowel(w[i])) { c2 = w[i]; break; }
        }
        out.add(c2 ?? w[1]);
      }

      if (w.isNotEmpty) {
        // konsonan terakhir; jika belum ada, pakai huruf terakhir
        String? c3;
        for (int i = w.length - 1; i >= 0; i--) {
          if (!isVowel(w[i])) { c3 = w[i]; break; }
        }
        out.add(c3 ?? w[w.length - 1]);
      }
      // potong kalau user baru ngetik 1–2 huruf
      return out.take(w.length >= 3 ? 3 : w.length).join();
    } else {
      final first = parts.first;
      final second = parts.length >= 2 ? parts[1] : '';
      final last = parts.last;
      final List<String> out = [];
      if (first.isNotEmpty) out.add(first[0]);
      if (second.isNotEmpty) out.add(second[0]);
      if (last.isNotEmpty) out.add(last[last.length - 1]);
      return out.join();
    }
  }

  void _updateIdPreview() {
    final nameDyn = _nameCodeDyn(namausahaController.text);
    final locDyn  = _locCodeDyn(lokasiusahaController.text);

    final left  = nameDyn.isEmpty ? 'NAMA USAHA' : nameDyn;
    final right = locDyn.isEmpty  ? 'LOKASI'     : locDyn;

    final preview = 'USH - $left - $right - XXX';
    if (idPreviewController.text != preview) {
      idPreviewController.text = preview;
    }
  }

  // ====== Actions ======
  Future<void> register() async {
    final nama = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();
    final role = selectedRole;
    String? usahaId;

    if (nama.isEmpty || email.isEmpty || password.isEmpty || role == null) {
      await showTopToast(context, 'Semua field wajib diisi', icon: Icons.info_rounded);
      return;
    }

    if (role == 'admin_usaha') {
      if ((namausahaController.text.trim().isEmpty) ||
          (lokasiusahaController.text.trim().isEmpty)) {
        await showTopToast(context, 'Nama usaha & lokasi wajib diisi untuk Admin', icon: Icons.info_rounded);
        return;
      }
    }

    if (role == 'admin_pusat') {
      if (adminKeyController.text.trim() != 'RAHASIA2025') {
        await showTopToast(context, 'Kode rahasia salah', icon: Icons.warning_amber_rounded);
        return;
      }
    }

    setState(() => _isLoading = true);
    try {
      if (role == 'admin_usaha') {
        usahaId = await generateusahaId();
        idUsahaController.text = usahaId;
        await supabase.from('usaha').insert({
          'id_usaha': usahaId,
          'nama_usaha': namausahaController.text.trim(),
          'lokasi': lokasiusahaController.text.trim(),
        });
      } else if (role == 'staff') {
        final id = idUsahaController.text.trim().toUpperCase();
        if (id.isEmpty) {
          await showTopToast(context, 'ID usaha wajib diisi', icon: Icons.info_rounded);
          setState(() => _isLoading = false);
          return;
        }

        final usaha = await supabase
            .from('usaha')
            .select('id_usaha')
            .eq('id_usaha', id)
            .maybeSingle();

        if (usaha == null) {
          await showTopToast(
            context,
            'ID usaha tidak ditemukan. Periksa lagi atau hubungi admin.',
            icon: Icons.warning_amber_rounded,
          );
          setState(() => _isLoading = false);
          return;
        }

        usahaId = id;
      } else if (role == 'admin_pusat') {
        usahaId = '';
      }

      final authResponse = await supabase.auth.signUp(
        email: email,
        password: password,
        emailRedirectTo: 'https://inmato.id/auth-callback/', // ⬅️ WAJIB
        data: {
          'nama': nama,
          'role': role,
          'id_usaha': usahaId ?? '',
        },
      );


      final user = authResponse.user;
      if (user == null) {
        await showTopToast(context, 'Gagal mendapatkan user ID', icon: Icons.warning_amber_rounded);
        setState(() => _isLoading = false);
        return;
      }

      await showTopToast(context, 'Berhasil mendaftar — silakan verifikasi lewat email anda', icon: Icons.check_circle_rounded);
      await Future.delayed(const Duration(milliseconds: 6000));
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, '/login');
    } catch (e) {
      await showTopToast(
        context,
        'Gagal mendaftar: ${e.toString()}',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 6000),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ====== UI Helpers ======
  double _cardMaxWidth(double w) {
    if (w >= 1200) return 520;
    if (w >= 900) return 520;
    if (w >= 600) return 520;
    return 500;
  }

  Widget _buildRoleSpecificFields() {
    if (selectedRole == 'admin_usaha') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ID Usaha otomatis (read-only)
          TextField(
            controller: idUsahaController,
            readOnly: true,
            enableInteractiveSelection: true,
            decoration: const InputDecoration(
              labelText: 'ID Usaha (otomatis)',
              helperText: 'Isi Nama Usaha & Lokasi — ID akan tergenerate otomatis, tidak perlu diisi.',
            ),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: namausahaController,
            decoration: const InputDecoration(labelText: 'Nama Usaha'),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: lokasiusahaController,
            decoration: const InputDecoration(labelText: 'Lokasi'),
          ),
          const SizedBox(height: 12),
        ],
      );
    }
    if (selectedRole == 'staff') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: idUsahaController,
            textInputAction: TextInputAction.done,
            inputFormatters: [
              UsahaIdFormatter(),  // ⬅️ gunakan ini
            ],
            decoration: const InputDecoration(
              labelText: 'ID Usaha',
              helperText: 'Minta ID dari admin usaha tempat Anda bekerja',
            ),
          ),
          const SizedBox(height: 12),
        ],
      );
    }

    if (selectedRole == 'admin_pusat') {
      return Column(
        children: [
          TextField(
            controller: adminKeyController,
            decoration: const InputDecoration(labelText: 'Kode Rahasia Admin Pusat'),
            obscureText: true,
          ),
          const SizedBox(height: 12),
        ],
      );
    }
    return const SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark,
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.22,
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _logoStrip(),

                    ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: _cardMaxWidth(w)),
                      child: Card(
                        color: Colors.white.withOpacity(0.96),
                        elevation: 10,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 22),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text(
                                "Daftar Akun",
                                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
                              ),
                              const SizedBox(height: 22),

                              TextField(
                                controller: nameController,
                                textInputAction: TextInputAction.next,
                                decoration: const InputDecoration(labelText: 'Nama'),
                              ),
                              const SizedBox(height: 14),

                              TextField(
                                controller: emailController,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.next,
                                decoration: const InputDecoration(labelText: 'Email'),
                              ),
                              const SizedBox(height: 14),

                              TextField(
                                controller: passwordController,
                                obscureText: _obscure,
                                decoration: InputDecoration(
                                  labelText: 'Password',
                                  suffixIcon: IconButton(
                                    onPressed: () => setState(() => _obscure = !_obscure),
                                    icon: Icon(_obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),

                              DropdownButtonFormField<String>(
                                decoration: const InputDecoration(labelText: 'Role'),
                                value: selectedRole,
                                items: const [
                                  DropdownMenuItem(value: 'admin_usaha', child: Text('Admin')),
                                  DropdownMenuItem(value: 'staff', child: Text('Karyawan')),
                                ],
                                onChanged: (value) async {
                                  setState(() {
                                    selectedRole = value;
                                    selectedusaha = null;
                                    namausahaController.clear();
                                    lokasiusahaController.clear();
                                    idUsahaController.clear();
                                  });
                                  if (value == 'admin_usaha') {
                                    _updateIdPreview();
                                    _scheduleGenerateId();
                                  }
                                },
                              ),
                              const SizedBox(height: 14),

                              _buildRoleSpecificFields(),

                              const SizedBox(height: 18),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _isLoading ? null : register,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.indigo,
                                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                  ),
                                  child: _isLoading
                                      ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                  )
                                      : const Text('Daftar', style: TextStyle(fontSize: 16, color: Colors.white)),
                                ),
                              ),
                              const SizedBox(height: 10),

                              TextButton(
                                onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                                child: const Text('Sudah punya akun? Masuk di sini'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Formatter khusus ID Usaha: otomatis uppercase + kasih strip tiap 3 huruf.
/// Contoh input: ushaggjua001  =>  USH-AGG-JUA-001
class UsahaIdFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // Bersihkan semua selain huruf/angka, lalu uppercase
    String raw = newValue.text.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toUpperCase();

    // Batasi maksimal 12 karakter (4 kelompok x 3)
    if (raw.length > 12) raw = raw.substring(0, 12);

    // Sisipkan strip setiap 3 karakter
    final buffer = StringBuffer();
    for (int i = 0; i < raw.length; i++) {
      if (i > 0 && i % 3 == 0) buffer.write('-');
      buffer.write(raw[i]);
    }
    final formatted = buffer.toString();

    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}
