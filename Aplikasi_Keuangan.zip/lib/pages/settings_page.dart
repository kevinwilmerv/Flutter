import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:package_info_plus/package_info_plus.dart';

class SettingsPage extends StatefulWidget {
  final String? idUsaha;
  final String? namaUsaha;

  const SettingsPage({super.key, this.idUsaha, this.namaUsaha});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final supabase = Supabase.instance.client;

  bool _loading = true;
  String _email = '';
  String _nama = '';
  String _role = '';
  String _idUsaha = '';
  String _lokasi = '';

  // versi aplikasi (hanya versionName dari pubspec, tanpa +buildNumber)
  String _appVersion = '';

  // ====== THEME ======
  static const _red = Color(0xFFEF5350);
  static const _deepNavy = Color(0xFF1E2A39);

  bool _notifOn = true;
  bool _signingOut = false;
  String _namaUsahaView = '';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
  }

  @override
  void initState() {
    super.initState();
    _loadMe();
    _loadVersion(); // ⬅️ muat versi dari pubspec
  }

  Future<void> _loadVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (!mounted) return;
      setState(() {
        _appVersion = (info.version).trim(); // e.g. "1.2.3"
      });
    } catch (e) {
      // kalau gagal, tampilkan placeholder, supaya tidak "v-"
      if (!mounted) return;
      setState(() {
        _appVersion = ''; // biar subtitle kasih fallback
      });
    }
  }

  Future<void> _loadMe() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) {
        if (!mounted) return;
        Navigator.pushReplacementNamed(context, '/login');
        return;
      }

      final meta = user.userMetadata ?? {};
      final metaIdUsaha = (meta['id_usaha'] ?? '').toString();
      final metaNama = (meta['nama'] ?? '').toString();
      final metaRole = (meta['role'] ?? '').toString();

      String? profIdUsaha, profNama, profRole, profLokasi;
      try {
        final p = await supabase
            .from('profiles')
            .select('nama, role, id_usaha, lokasi')
            .eq('id', user.id)
            .maybeSingle();
        if (p != null) {
          profIdUsaha = (p['id_usaha'] ?? '').toString();
          profNama = (p['nama'] ?? '').toString();
          profRole = (p['role'] ?? '').toString();
          profLokasi = (p['lokasi'] ?? '').toString();
        }
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _email = user.email ?? '';
        _nama = (profNama?.isNotEmpty == true) ? profNama! : metaNama;
        _role = (profRole?.isNotEmpty == true) ? profRole! : metaRole;
        _idUsaha = (profIdUsaha?.isNotEmpty == true)
            ? profIdUsaha!
            : (metaIdUsaha.isNotEmpty ? metaIdUsaha : widget.idUsaha ?? '');
        _lokasi = profLokasi ?? '';
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _snack('Gagal memuat data: $e');
    }
  }

  void _snack(String msg, {bool ok = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: ok ? Colors.green.shade600 : Colors.black87,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _copyIdUsaha() async {
    if (_idUsaha.isEmpty) {
      _snack('ID Usaha belum tersedia');
      return;
    }
    await Clipboard.setData(ClipboardData(text: _idUsaha));
    _snack('ID Usaha disalin', ok: true);
  }

  Future<void> _signOut() async {
    try {
      await supabase.auth.signOut();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false);
    } catch (e) {
      _snack('Gagal keluar: $e');
    }
  }

  double _cardMaxWidth(double w) => w >= 600 ? 560 : w;
  double _outerPadding(double w) =>
      w >= 1200 ? 32 : (w >= 900 ? 28 : (w >= 600 ? 24 : 18));

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    return Scaffold(
      body: AppBackground(
        overlayLight: true,
        overlayOpacity: 0.18,
        child: Column(
          children: [
            // ===== HEADER =====
            Container(
              width: double.infinity,
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 8,
                left: 8,
                right: 8,
                bottom: 14,
              ),
              decoration: const BoxDecoration(
                color: _red,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(24),
                  bottomRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x33000000),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                    onPressed: () => Navigator.maybePop(context),
                    tooltip: 'Kembali',
                  ),
                  const Spacer(),
                  const Text(
                    'Pengaturan',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 20,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(width: 48),
                ],
              ),
            ),

            // ===== KONTEN =====
            Expanded(
              child: SafeArea(
                top: false,
                child: Center(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.fromLTRB(_outerPadding(w), 20, _outerPadding(w), 24),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: _cardMaxWidth(w)),
                      child: _settingsContent(),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _settingsContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // ===== HERO CARD =====
        Container(
          decoration: BoxDecoration(
            color: _red,
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [
              BoxShadow(color: Color(0x33EF5350), blurRadius: 16, offset: Offset(0, 8)),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 48, width: 48,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.85),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.person_rounded, color: _red),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_nama.isEmpty ? 'Pengguna' : _nama,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18)),
                    Text(_email.isEmpty ? '-' : _email,
                        style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
                  ],
                ),
              ),
              InkWell(
                onTap: _copyIdUsaha,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(.9), borderRadius: BorderRadius.circular(999)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('ID Usaha: ', style: TextStyle(color: _red, fontWeight: FontWeight.w700, fontSize: 12)),
                      Text(_idUsaha.isEmpty ? '-' : _idUsaha,
                          style: const TextStyle(color: _red, fontWeight: FontWeight.w800, fontSize: 12)),
                      const SizedBox(width: 6),
                      const Icon(Icons.copy_rounded, size: 16, color: _red),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 14),

        // ===== KARTU ISI =====
        Card(
          color: Colors.white,
          elevation: 8,
          shadowColor: Colors.black12,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: _loading
                ? const Padding(
              padding: EdgeInsets.all(24.0),
              child: Center(child: CircularProgressIndicator()),
            )
                : Column(
              children: [
                // Akun
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFE8F5E9),
                    child: Icon(Icons.person, color: Colors.green.shade700),
                  ),
                  title: Text(_nama.isEmpty ? 'Pengguna' : _nama,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(_email.isEmpty ? '-' : _email),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: Colors.indigo.shade50, borderRadius: BorderRadius.circular(999)),
                    child: Text(
                      (_role.isEmpty ? 'USER' : _role).toUpperCase(),
                      style: const TextStyle(fontSize: 12, color: Colors.indigo, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),

                const Divider(),

                // Nama Usaha
                if (_namaUsahaView.isNotEmpty) ...[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.store_mall_directory_outlined),
                    title: const Text('Nama Usaha'),
                    subtitle: Text(_namaUsahaView),
                  ),
                  const Divider(),
                ],

                // ID Usaha
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.qr_code_2_rounded),
                  title: const Text('ID Usaha'),
                  subtitle: Text(_idUsaha.isEmpty ? 'Belum tersedia' : _idUsaha),
                  trailing: IconButton(
                    tooltip: 'Salin',
                    icon: const Icon(Icons.copy_all_rounded),
                    onPressed: _copyIdUsaha,
                  ),
                ),

                if (_lokasi.isNotEmpty) ...[
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.location_on_outlined),
                    title: const Text('Lokasi'),
                    subtitle: Text(_lokasi),
                  ),
                ],

                const Divider(),

                // Notifikasi
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Notifikasi'),
                  subtitle: const Text('Terima pemberitahuan penting'),
                  value: _notifOn,
                  onChanged: (v) => setState(() => _notifOn = v),
                ),

                // Tentang (versi dari pubspec)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.info_outline_rounded),
                  title: const Text('Tentang Aplikasi'),
                  subtitle: Text(
                    _appVersion.isEmpty
                        ? 'Sistem Keuangan Inmato.ID'
                        : 'Sistem Keuangan Inmato.ID • v$_appVersion',
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 14),

        // ===== TOMBOL KELUAR =====
        SizedBox(
          height: 46,
          child: ElevatedButton.icon(
            onPressed: _signingOut
                ? null
                : () async {
              setState(() => _signingOut = true);
              try {
                await _signOut();
              } finally {
                if (mounted) setState(() => _signingOut = false);
              }
            },
            icon: const Icon(Icons.logout_rounded),
            label: Text(_signingOut ? 'Keluar...' : 'Keluar',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            style: ElevatedButton.styleFrom(
              backgroundColor: _deepNavy,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 2,
            ),
          ),
        ),
      ],
    );
  }
}
