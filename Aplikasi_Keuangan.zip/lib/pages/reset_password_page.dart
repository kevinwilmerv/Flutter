// reset_password_page.dart  — versi EMAIL-ONLY (kirim link reset)
import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/widget/pop_notifier.dart';

class ResetPasswordPage extends StatefulWidget {
  const ResetPasswordPage({super.key});
  @override
  State<ResetPasswordPage> createState() => _ResetPasswordPageState();
}

class _ResetPasswordPageState extends State<ResetPasswordPage> {
  final supabase = Supabase.instance.client;

  final _email = TextEditingController();
  bool _loading = false;

  // pastikan URL ini ada di Redirect URLs Supabase
  static const String _resetRedirectUrl =
      'https://www.inmato.id/auth-callback/reset-password.html';

  @override
  void initState() {
    super.initState();
    if (kIsWeb) {
      // optional
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
  }

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  void _toast(String title, String message, {bool success = false}) {
    PopNotifier.I.show(
      context,
      title: title,
      message: message,
      type: success ? NoticeType.success : NoticeType.error,
      duration: const Duration(seconds: 2),
    );
  }

  // Kirim email reset password (diarahkan ke halaman web)
  Future<void> _sendResetEmail() async {
    final email = _email.text.trim();
    final base = 'https://www.inmato.id/auth-callback/request-reset.html';
    final url = Uri.parse(
      email.isNotEmpty ? '$base?email=${Uri.encodeComponent(email)}' : base,
    );

    final ok = await launchUrl(url, mode: LaunchMode.externalApplication);
    if (!ok) {
      _toast('Gagal', 'Tidak bisa membuka halaman reset di browser.');
    }
  }

  // Strip logo (sama seperti AuthPage)
  Widget _logoStrip() {
    const logos = <String>[
      'assets/IBIKKG.png',
      'assets/Kemendiktisaintek.png',
      'assets/OK_OCE.png',
      'assets/LOGOSR1.png',
    ];
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        double h;
        if (w < 380)      h = 42;
        else if (w < 600) h = 54;
        else if (w < 1024)h = 66;
        else              h = 78;
        return Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Wrap(
            spacing: 20,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [for (final p in logos) Image.asset(p, height: h)],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // ---------- FORCE LIGHT THEME (paksa teks & ikon hitam) ----------
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: Colors.brown), // “Kembali ke Login”
      ),
    );
    // ----------------------------------------------------------------

    final scaffold = Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.25,
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _logoStrip(),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: Card(
                        color: Colors.white.withOpacity(0.96),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 10,
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text(
                                'Lupa Password',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87, // paksa hitam
                                ),
                              ),
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.amber.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    Icon(Icons.info_outline_rounded, color: Colors.black87),
                                    SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        'Klik tombol dibawah ini kemudian masukkan email Anda. Kami akan mengirimkan tautan untuk mengatur ulang password. '
                                            'Setelah mengetuk tautan, Anda akan menulis password barunya di halaman web.',
                                        style: TextStyle(fontSize: 13.5, color: Colors.black87),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 12),

                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _loading ? null : _sendResetEmail,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF6B1F1A),
                                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                  ),
                                  child: _loading
                                      ? const SizedBox(
                                    height: 22, width: 22,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                  )
                                      : const Text('Kirim Link Reset', style: TextStyle(color: Colors.white)),
                                ),
                              ),
                              const SizedBox(height: 8),
                              TextButton(
                                onPressed: _loading
                                    ? null
                                    : () => Navigator.pushNamedAndRemoveUntil(context, '/login', (r) => false),
                                child: const Text('Kembali ke Login'), // warnanya di-force via TextButtonTheme di atas
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );

    // Bungkus dengan Theme override agar tidak mengikuti tema sistem
    return Theme(data: forceLight, child: scaffold);
  }
}
