// laporan_transaksi_page.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/app_background.dart';

// PDF
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

enum _ColType { date, number, text }

class _ColSpec {
  final String title;
  final String key;
  final _ColType type;
  const _ColSpec(this.title, this.key, this.type);
}

/// Kolom untuk LAPORAN TRANSAKSI (Aksi ditangani khusus di header/body)
final List<_ColSpec> _cols = const [
  _ColSpec('Tanggal',     'tanggal',     _ColType.date),
  _ColSpec('Penjualan',   'penjualan',   _ColType.number),
  _ColSpec('Beban Usaha', 'beban_usaha', _ColType.number),
  _ColSpec('Laba Kotor',  'laba_kotor',  _ColType.number),
  _ColSpec('Keterangan',  'keterangan',  _ColType.text),
];

class LaporanTransaksiPage extends StatefulWidget {
  final String idUsaha;
  const LaporanTransaksiPage({super.key, required this.idUsaha});

  @override
  State<LaporanTransaksiPage> createState() => _LaporanTransaksiPageState();
}

class _LaporanTransaksiPageState extends State<LaporanTransaksiPage> {
  // services
  final _supabase = Supabase.instance.client;
  final logService = LogService();

  // tanggal (periode aktif)
  DateTime? _startDate;
  DateTime? _endDate;
  final _fmtYmd = DateFormat('yyyy-MM-dd');

  // data harian
  List<Map<String, dynamic>> _rows = [];
  bool _loading = false;

  // SELECT MODE (kaya Laporan LB/Stok)
  bool _selectMode = false;
  final Set<String> _selectedDates = {}; // simpan yyyy-MM-dd

  // formatters
  final _fmtDate = DateFormat('d MMM yyyy', 'id_ID');
  final _fmtCur  = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  // sinkron scroll H
  final _hHeader = ScrollController();
  final _hBody   = ScrollController();

  // header & lebar kolom (tambah 120 untuk kolom Aksi)
  final List<double> _baseWidths = const [180, 180, 180, 180, 260, 120];

  // === STATE SORT ===
  int? _sortColumnIndex;   // 0..4, null = default (tanggal naik). Kolom 5 = Aksi (non-sortable)
  bool _sortAscending = true;

  // === Sticky badge (posisi kiri, tidak menimpa header) ===
  static const double _kStickyBadgeReservedHeight = 42; // ruang kosong di atas header
  final GlobalKey _filterBarKey = GlobalKey();
  double _filterBarHeight = 0;
  void _measureFilterBarHeight() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _filterBarKey.currentContext;
      if (ctx == null) return;
      final box = ctx.findRenderObject() as RenderBox?;
      final h = box?.size.height ?? 0;
      if (!mounted) return;
      if ((h - _filterBarHeight).abs() > 0.5) {
        setState(() => _filterBarHeight = h);
      }
    });
  }

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _startDate = DateTime(now.year, now.month, 1);
    _endDate   = DateTime(now.year, now.month + 1, 0);

    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });

    _fetchData();
  }

  @override
  void dispose() {
    _hHeader.dispose();
    _hBody.dispose();
    super.dispose();
  }

  num _num(dynamic v) => (v is num) ? v : num.tryParse(v?.toString() ?? '') ?? 0;
  num _abs(num v) => v < 0 ? -v : v;

  // === APPLY SORT (dipakai saat data berubah / header diklik) ===
  void _applySort({int? columnIndex, bool? ascending, bool notify = true}) {
    if (_rows.isEmpty) {
      if (notify) setState(() {});
      return;
    }

    // abaikan jika yang dipilih kolom Aksi (index terakhir)
    if (columnIndex != null) {
      if (columnIndex >= _cols.length) return;
      if (_sortColumnIndex == columnIndex) {
        _sortAscending = ascending ?? !_sortAscending;
      } else {
        _sortColumnIndex = columnIndex;
        _sortAscending = ascending ?? (_cols[columnIndex].type == _ColType.date ? true : false);
      }
    }

    int cmp(Map<String, dynamic> a, Map<String, dynamic> b) {
      if (_sortColumnIndex == null) {
        final ad = DateTime.tryParse((a['tanggal'] ?? '').toString()) ?? DateTime(1970);
        final bd = DateTime.tryParse((b['tanggal'] ?? '').toString()) ?? DateTime(1970);
        return ad.compareTo(bd);
      }
      final spec = _cols[_sortColumnIndex!];
      switch (spec.type) {
        case _ColType.date:
          final ax = DateTime.tryParse((a[spec.key] ?? '').toString()) ?? DateTime(1970);
          final bx = DateTime.tryParse((b[spec.key] ?? '').toString()) ?? DateTime(1970);
          return ax.compareTo(bx);
        case _ColType.number:
          final ax = _num(a[spec.key]);
          final bx = _num(b[spec.key]);
          return ax.compareTo(bx);
        case _ColType.text:
          final ax = (a[spec.key] ?? '').toString().toLowerCase();
          final bx = (b[spec.key] ?? '').toString().toLowerCase();
          return ax.compareTo(bx);
      }
    }

    _rows.sort((a, b) {
      final c = cmp(a, b);
      return _sortAscending ? c : -c;
    });

    if (notify) setState(() {});
  }

  // Badge sticky di kiri
  Widget _sortBadgeFixed() {
    if (_sortColumnIndex == null) return const SizedBox.shrink();
    final title = _cols[_sortColumnIndex!].title;
    final dirLabel = _sortAscending ? 'Terendah → Tertinggi' : 'Tertinggi → Terendah';
    return IgnorePointer(
      ignoring: true,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(.06), blurRadius: 8, offset: const Offset(0, 3))],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.sort, size: 18, color: Colors.black87),
            const SizedBox(width: 6),
            Text('Urut: $title • $dirLabel', style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  // ====== FETCH dari tabel transaksi_harian ======
  Future<void> _fetchData() async {
    setState(() { _loading = true; _selectedDates.clear(); });

    try {
      // Ambil raw transaksi
      var qb = _supabase
          .from('transaksi_harian')
          .select('tanggal, jenis_transaksi, jumlah, keterangan, kategori, sub_kategori, custom_label')
          .eq('id_usaha', widget.idUsaha) as PostgrestFilterBuilder;

      if (_startDate != null) qb = qb.gte('tanggal', _fmtYmd.format(_startDate!));
      if (_endDate != null)   qb = qb.lte('tanggal', _fmtYmd.format(_endDate!));

      final List raw = await qb.order('tanggal');

      // Grup per tanggal
      final Map<String, Map<String, dynamic>> byDate = {};

      for (final r in raw) {
        final tgl = (r['tanggal'] ?? '').toString();
        if (tgl.isEmpty) continue;

        // gunakan ABS untuk pastikan tidak tampil minus, agar Laba Kotor benar
        final j = _abs(_num(r['jumlah']));
        final jenis = (r['jenis_transaksi'] ?? '').toString().toLowerCase();

        final bucket = byDate.putIfAbsent(tgl, () => {
          'tanggal': tgl,
          'penjualan': 0,
          'beban_usaha': 0,
          'laba_kotor': 0,
          'keterangan': '',
        });

        if (jenis == 'penjualan') {
          bucket['penjualan'] = (bucket['penjualan'] as num) + j;
        } else if (jenis == 'beban_usaha') {
          bucket['beban_usaha'] = (bucket['beban_usaha'] as num) + j;
        }

        // isi keterangan kalau kosong
        final ket = (r['keterangan'] ?? '').toString().trim();
        if (ket.isNotEmpty && (bucket['keterangan'] as String).isEmpty) {
          bucket['keterangan'] = ket;
        }
      }

      // Hitung laba kotor
      final rows = byDate.values.map((m) {
        m['laba_kotor'] = _num(m['penjualan']) - _num(m['beban_usaha']);
        if ((m['keterangan'] as String).isEmpty) m['keterangan'] = '—';
        return m;
      }).toList();

      if (!mounted) return;
      setState(() { _rows = rows; });
      _applySort(notify: true);
    } catch (e) {
      if (!mounted) return;
      await showTopToast(context, 'Gagal memuat data: $e',
          icon: Icons.warning_amber_rounded);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ====== TOTAL periode ======
  Map<String, num> _sumTotals() {
    num penjualan = 0, bebanUsaha = 0, labaKotor = 0;
    for (final r in _rows) {
      penjualan  += _num(r['penjualan']);
      bebanUsaha += _num(r['beban_usaha']);
      labaKotor  += _num(r['laba_kotor']);
    }
    return {
      'penjualan': penjualan,
      'bebanUsaha': bebanUsaha,
      'labaKotor': labaKotor,
    };
  }

  String _periodeLabel() {
    if (_startDate == null && _endDate == null) return 'Semua';
    final s = _startDate != null ? _fmtDate.format(_startDate!) : 'Semua';
    final e = _endDate != null ? _fmtDate.format(_endDate!) : 'Semua';
    return '$s — $e';
  }

  // ================= DELETE =================
  bool get _hasRange => _startDate != null && _endDate != null;

  Future<void> _deleteAll() async {
    if (_rows.isEmpty || !_hasRange) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus semua data?'),
        content: Text('Semua transaksi pada periode ${_periodeLabel()} akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _fmtYmd.format(_startDate!))
          .lte('tanggal', _fmtYmd.format(_endDate!));

      // LOG
      await logService.addLog(
        aktivitas: 'hapus_transaksi',
        halaman: 'Laporan Transaksi',
        detail: 'Hapus semua transaksi periode ${_periodeLabel()}',
      );

      await showTopToast(context, 'Berhasil menghapus data periode ${_periodeLabel()}');
      await _fetchData();
    } catch (e) {
      await showTopToast(context, 'Gagal menghapus: $e', icon: Icons.warning_amber_rounded);
    }
  }

  Future<void> _deleteSelected() async {
    if (_selectedDates.isEmpty) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus data terpilih?'),
        content: Text('${_selectedDates.length} tanggal akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      final dates = _selectedDates.toList()..sort();
      await _supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .inFilter('tanggal', dates);

      // LOG
      await logService.addLog(
        aktivitas: 'hapus_transaksi',
        halaman: 'Laporan Transaksi',
        detail: 'Hapus ${dates.length} tanggal: ${dates.join(', ')}',
      );

      setState(() { _selectedDates.clear(); _selectMode = false; });
      await showTopToast(context, 'Berhasil menghapus ${dates.length} data');
      await _fetchData();
    } catch (e) {
      await showTopToast(context, 'Gagal menghapus: $e', icon: Icons.warning_amber_rounded);
    }
  }

  void _toggleSelectMode() {
    setState(() {
      _selectMode = !_selectMode;
      if (!_selectMode) _selectedDates.clear();
    });
  }

  bool _isAllVisibleSelected() {
    final visible = _rows
        .map((r) => r['tanggal']?.toString() ?? '')
        .where((s) => s.isNotEmpty)
        .toSet();
    return visible.isNotEmpty && _selectedDates.containsAll(visible);
  }

  void _toggleSelectAllVisible() {
    final visible = _rows
        .map((r) => r['tanggal']?.toString() ?? '')
        .where((s) => s.isNotEmpty)
        .toSet();
    setState(() {
      if (_isAllVisibleSelected()) {
        _selectedDates.removeAll(visible);
      } else {
        _selectedDates.addAll(visible);
      }
    });
  }

  // ===== EXPORT PDF (rekap periode) =====
  Future<void> _exportPdf() async {
    if (_loading) {
      await showTopToast(context, 'Tunggu, data masih dimuat…', icon: Icons.hourglass_bottom_rounded);
      return;
    }
    if (_rows.isEmpty) {
      await showTopToast(context, 'Tidak ada data untuk diekspor.', icon: Icons.info_rounded);
      return;
    }

    final doc = pw.Document();
    final t = _sumTotals();

    final headers = [..._cols.map((c) => c.title)];
    final data = <List<String>>[
      [
        _periodeLabel(),
        _fmtCur.format(t['penjualan'] ?? 0),
        _fmtCur.format(t['bebanUsaha'] ?? 0),
        _fmtCur.format(t['labaKotor'] ?? 0),
        '—',
      ],
    ];

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(24),
        header: (ctx) => pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Rekap Mutasi Transaksi', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
            pw.Text(_periodeLabel(), style: const pw.TextStyle(fontSize: 10)),
          ],
        ),
        footer: (ctx) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text('Hal. ${ctx.pageNumber}/${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 10)),
        ),
        build: (ctx) => [
          pw.TableHelper.fromTextArray(
            headers: headers,
            data: data,
            headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
            cellStyle: const pw.TextStyle(fontSize: 9),
            cellAlignment: pw.Alignment.centerRight,
            headerAlignment: pw.Alignment.center,
            cellAlignments: const {0: pw.Alignment.centerLeft, 4: pw.Alignment.centerLeft},
            border: pw.TableBorder.all(color: PdfColors.grey600, width: .3),
          ),
        ],
      ),
    );

    try {
      await Printing.layoutPdf(onLayout: (_) async => doc.save());
      if (!mounted) return;
      await showTopToast(context, 'PDF siap dicetak / dibagikan', icon: Icons.check_circle_rounded);
    } catch (e) {
      if (!mounted) return;
      await showTopToast(context, 'Gagal membuat PDF: $e', icon: Icons.warning_amber_rounded);
    }
  }

  // ===== UI =====
  @override
  Widget build(BuildContext context) {
    // Force light – sama seperti LaporanLBPage
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(bodyColor: Colors.black87, displayColor: Colors.black87),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87, backgroundColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light, onSurface: Colors.black87, onBackground: Colors.black87, onPrimary: Colors.white, onSecondary: Colors.black87,
      ),
    );

    final headers = [..._cols.map((c) => c.title), 'Aksi'];

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: AppBackground(
          overlayLight: true, overlayOpacity: 0.22,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: () => Navigator.of(context).maybePop(),
                splashRadius: 22,
              ),
              title: const Text('Laporan Transaksi'),
              actions: [
                // Toggle Select Mode
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _toggleSelectMode,
                  icon: Icon(_selectMode ? Icons.check_box : Icons.check_box_outline_blank, color: Colors.black87),
                  label: Text(_selectMode ? 'Selesai' : 'Pilih Data',
                      style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                // Delete All (rentang)
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _deleteAll,
                  icon: const Icon(Icons.delete_forever, color: Color(0xFF8E101A)),
                  label: const Text('Hapus Semua',
                      style: TextStyle(color: Color(0xFF8E101A), fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ElevatedButton.icon(
                    onPressed: _exportPdf,
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('Export PDF'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF2F2F2),
                      foregroundColor: Colors.black,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    ),
                  ),
                ),
              ],
            ),

            // Footer saat Select Mode
            bottomNavigationBar: !_selectMode ? null : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 10, offset: const Offset(0, -4))],
                  border: Border(top: BorderSide(color: Colors.black.withOpacity(.08))),
                ),
                child: Row(
                  children: [
                    Expanded(child: Text('${_selectedDates.length} dipilih', style: const TextStyle(fontWeight: FontWeight.w800))),
                    OutlinedButton.icon(
                      onPressed: _rows.isEmpty ? null : _toggleSelectAllVisible,
                      icon: Icon(_isAllVisibleSelected() ? Icons.select_all : Icons.checklist),
                      label: Text(_isAllVisibleSelected() ? 'Batalkan Semua' : 'Pilih Semua'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: () => setState(() { _selectedDates.clear(); _selectMode = false; }),
                      child: const Text('Batal'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: const Color(0xFF8E101A), foregroundColor: Colors.white),
                      onPressed: _selectedDates.isEmpty ? null : _deleteSelected,
                      icon: const Icon(Icons.delete),
                      label: const Text('Hapus Terpilih'),
                    ),
                  ],
                ),
              ),
            ),

            body: SafeArea(
              top: false,
              minimum: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: LayoutBuilder(
                builder: (context, c) {
                  final minTotal = _baseWidths.reduce((a, b) => a + b);
                  final available = max(0.0, c.maxWidth - 24);
                  final totalW = max(available, minTotal.toDouble());
                  final scale = totalW / minTotal;
                  final widths = _baseWidths.map((w) => w * scale).toList();
                  final tableWidth = widths.reduce((a, b) => a + b);

                  // ukur tinggi filter bar dan hitung posisi badge
                  _measureFilterBarHeight();
                  const double kTopGap = 8;
                  const double kBetweenFilterAndTable = 10;
                  final double badgeTop = kTopGap + _filterBarHeight + kBetweenFilterAndTable;
                  final double reservedForBadge = (_sortColumnIndex != null) ? _kStickyBadgeReservedHeight : 0;

                  return Stack(
                    children: [
                      // Konten utama scrollable
                      Scrollbar(
                        thumbVisibility: true,
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: kTopGap),
                              _filterBar(),
                              const SizedBox(height: kBetweenFilterAndTable),
                              // sisakan ruang agar badge tidak menimpa header
                              SizedBox(height: reservedForBadge),

                              // KARTU TABEL
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 14, offset: const Offset(0, 6))],
                                ),
                                padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                                child: Column(
                                  children: [
                                    // Header
                                    Scrollbar(
                                      controller: _hHeader,
                                      thumbVisibility: true,
                                      child: SingleChildScrollView(
                                        controller: _hHeader,
                                        scrollDirection: Axis.horizontal,
                                        child: SizedBox(
                                          width: (_selectMode ? 54.0 : 0) + tableWidth,
                                          child: _buildHeader(headers, widths),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 8),

                                    // Body
                                    Scrollbar(
                                      controller: _hBody,
                                      thumbVisibility: true,
                                      notificationPredicate: (n) => n.depth == 1,
                                      child: SingleChildScrollView(
                                        controller: _hBody,
                                        scrollDirection: Axis.horizontal,
                                        child: SizedBox(
                                          width: (_selectMode ? 54.0 : 0) + tableWidth,
                                          child: _loading
                                              ? const Padding(
                                            padding: EdgeInsets.all(24.0),
                                            child: Center(child: CircularProgressIndicator()),
                                          )
                                              : (_rows.isEmpty ? _buildPlaceholder(widths) : _buildDailyRows(widths)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Badge sticky di kiri atas tabel
                      Positioned(
                        left: 16,
                        top: badgeTop,
                        child: _sortBadgeFixed(),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ===== FILTER BAR =====
  Widget _filterBar() {
    return Container(
      key: _filterBarKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('Periode (Rentang)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _openRangePicker,
                icon: const Icon(Icons.date_range, size: 18),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFE4E9),
                  foregroundColor: Colors.black,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                    side: const BorderSide(color: Colors.black, width: 1),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
                label: const Text('Rentang Tanggal'),
              ),
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: _clearDates,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.black, width: 1),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                child: const Text('Clear'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: _openRangePicker,
                  borderRadius: BorderRadius.circular(40),
                  child: _DatePill(label: 'Tanggal Awal', value: _startDate == null ? '—' : _fmtDate.format(_startDate!)),
                ),
              ),
              const SizedBox(width: 8),
              const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(width: 8),
              Expanded(
                child: InkWell(
                  onTap: _openRangePicker,
                  borderRadius: BorderRadius.circular(40),
                  child: _DatePill(label: 'Tanggal Akhir', value: _endDate == null ? '—' : _fmtDate.format(_endDate!)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: [
              _PresetChip(text: 'Semua Data', onTap: () => _applyPreset('all')),
              _PresetChip(text: 'Bulan Ini',   onTap: () => _applyPreset('month')),
              _PresetChip(text: '100 Hari Terakhir', onTap: () => _applyPreset('100')),
            ],
          ),
        ],
      ),
    );
  }

  // ===== HEADER TABLE (Aksi non-sortable; + kolom checkbox saat select mode)
  Widget _buildHeader(List<String> headers, List<double> widths) {
    const double kSideInset = 20;
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;
    final titles    = _selectMode ? [' ', ...headers] : headers;

    Widget buildCell(int logicalIndex) {
      // jika kolom checkbox
      if (_selectMode && logicalIndex == 0) {
        return const SizedBox.shrink();
      }

      // tentukan index kolom sebenarnya (tanpa checkbox)
      final colIndex = _selectMode ? logicalIndex - 1 : logicalIndex;

      // kolom Aksi → non-sortable
      final isAksi = colIndex == _cols.length; // karena headers = _cols + 'Aksi'
      if (isAksi) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          child: Center(
            child: Text(
              titles[logicalIndex],
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ),
        );
      }

      final active = _sortColumnIndex == colIndex;
      final icon = !active ? Icons.unfold_more : (_sortAscending ? Icons.arrow_upward : Icons.arrow_downward);

      return InkWell(
        onTap: () => _applySort(columnIndex: colIndex),
        onLongPress: () async {
          final pos = const RelativeRect.fromLTRB(0, 80, 0, 0);
          final choice = await showMenu<String>(
            context: context,
            position: pos,
            items: const [
              PopupMenuItem(value: 'asc',  child: Text('Urut Naik (ASC)')),
              PopupMenuItem(value: 'desc', child: Text('Urut Turun (DESC)')),
              PopupMenuItem(value: 'reset', child: Text('Reset ke Tanggal')),
            ],
          );
          if (!mounted || choice == null) return;
          if (choice == 'asc')  _applySort(columnIndex: colIndex, ascending: true);
          if (choice == 'desc') _applySort(columnIndex: colIndex, ascending: false);
          if (choice == 'reset') {
            _sortColumnIndex = null; _sortAscending = true; _applySort();
          }
        },
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Text(
                  titles[logicalIndex],
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontWeight: FontWeight.w700, fontSize: 16,
                    color: active ? const Color(0xFF8E101A) : Colors.black87,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Icon(icon, size: 16, color: active ? const Color(0xFF8E101A) : Colors.black54),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kSideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: { for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i]) },
        children: [
          TableRow(children: List.generate(titles.length, (i) => buildCell(i))),
        ],
      ),
    );
  }

  // ===== BODY: baris harian (mutasi)
  Widget _buildDailyRows(List<double> widths) {
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;

    return Column(
      children: List.generate(_rows.length, (i) {
        final r = _rows[i];
        final dateStr = (r['tanggal'] ?? '').toString(); // yyyy-MM-dd
        final isSelected = _selectedDates.contains(dateStr);

        List<Widget> cells = [
          _cellCenter(_fmtDate.format(DateTime.parse(dateStr))),
          _cellCenter(_fmtCur.format(_num(r['penjualan']))),
          _cellCenter(_fmtCur.format(_num(r['beban_usaha']))),
          _cellCenter(_fmtCur.format(_num(r['laba_kotor']))),
          _cellCenter((r['keterangan'] ?? '—').toString()),
          Center(
            child: Wrap(
              spacing: 2,
              children: [
                IconButton(
                  tooltip: 'Lihat Detail',
                  icon: const Icon(Icons.remove_red_eye_outlined),
                  onPressed: () => _openDetail(dateStr),
                ),
                IconButton(
                  tooltip: 'Edit Keterangan',
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => _editKeterangan(dateStr, r['keterangan']?.toString() ?? ''),
                ),
              ],
            ),
          ),
        ];

        return GestureDetector(
          onTap: _selectMode && dateStr.isNotEmpty
              ? () {
            setState(() {
              if (isSelected) {
                _selectedDates.remove(dateStr);
              } else {
                _selectedDates.add(dateStr);
              }
            });
          }
              : null,
          child: Container(
            margin: EdgeInsets.only(top: i == 0 ? 12 : 8, left: 6, right: 6),
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
            decoration: BoxDecoration(
              color: _selectMode && isSelected ? const Color(0xFFFFE4E9) : Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: _selectMode && isSelected ? const Color(0xFF8E101A) : Colors.black.withOpacity(0.05),
                width: _selectMode && isSelected ? 2 : 1,
              ),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Table(
              columnWidths: { for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i]) },
              children: [
                TableRow(children: [
                  if (_selectMode)
                    Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Checkbox(
                        value: isSelected,
                        onChanged: (v) {
                          setState(() {
                            if (v == true) {
                              _selectedDates.add(dateStr);
                            } else {
                              _selectedDates.remove(dateStr);
                            }
                          });
                        },
                        side: const BorderSide(color: Colors.black87),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                    ),
                  ...cells,
                ]),
              ],
            ),
          ),
        );
      }),
    );
  }

  Widget _buildPlaceholder(List<double> widths) {
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;
    return Container(
      margin: const EdgeInsets.only(top: 12, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: Table(
        columnWidths: { for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i]) },
        children: [ TableRow(children: List.generate(widthsAdj.length, (i) => _cellCenter('–'))) ],
      ),
    );
  }

  // ===== RANGE & PRESET =====
  void _clearDates() {
    setState(() { _startDate = null; _endDate = null; _rows = []; _selectedDates.clear(); _selectMode = false; });
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _startDate ?? DateTime(now.year, now.month, 1),
      end:   _endDate   ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      builder: (ctx, child) => Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );

    if (picked != null) {
      setState(() { _startDate = picked.start; _endDate = picked.end; });
      await _fetchData();
    }
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();
    if (code == 'all') {
      _startDate = DateTime(2020, 1, 1); _endDate = now;
    } else if (code == 'month') {
      _startDate = DateTime(now.year, now.month, 1);
      _endDate   = DateTime(now.year, now.month + 1, 0);
    } else if (code == '100') {
      _startDate = now.subtract(const Duration(days: 99));
      _endDate   = now;
    }
    setState(() {});
    await _fetchData();
  }

  // ===== util widgets (alignments disamakan dengan LB) =====
  Widget _cellCenter(String text) => Container(
    alignment: Alignment.center, padding: const EdgeInsets.symmetric(vertical: 12),
    child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
  );

  Widget _cellLeft(String text) => Container(
    alignment: Alignment.centerLeft,
    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
    child: Text(
      text,
      overflow: TextOverflow.ellipsis,
      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
    ),
  );

  String _resolveLabel(Map<String, dynamic> r) {
    String pick(String k) => (r[k] ?? '').toString().trim();
    final a = pick('custom_label');
    if (a.isNotEmpty) return a;
    final b = pick('sub_kategori');
    if (b.isNotEmpty) return b;
    final c = pick('kategori');
    if (c.isNotEmpty) return c;
    final d = pick('keterangan');
    if (d.isNotEmpty) return d;
    return '—';
  }

  // ===== DETAIL (dialog di tengah) =====
  Future<void> _openDetail(String ymd) async {
    try {
      final List rows = await _supabase
          .from('transaksi_harian')
          .select(
          'jenis_transaksi,jumlah,kategori,sub_kategori,custom_label,keterangan')
          .eq('id_usaha', widget.idUsaha)
          .eq('tanggal', ymd)
          .order('jenis_transaksi')
          .order('kategori', ascending: true)
          .order('sub_kategori', ascending: true);

      final penjualan = <Map<String, dynamic>>[];
      final beban = <Map<String, dynamic>>[];

      for (final r0 in rows) {
        final r = Map<String, dynamic>.from(r0 as Map);
        final item = {
          'label': _resolveLabel(r),
          'jumlah': _abs(_num(r['jumlah'])),
        };
        final jenis = (r['jenis_transaksi'] ?? '').toString().toLowerCase();
        if (jenis == 'penjualan') {
          penjualan.add(item);
        } else {
          beban.add(item);
        }
      }

      num totP = 0, totB = 0;
      for (final x in penjualan) totP += _num(x['jumlah']);
      for (final x in beban) totB += _num(x['jumlah']);

      if (!mounted) return;
      await showDialog(
        context: context,
        barrierDismissible: true,
        builder: (ctx) {
          final screen = MediaQuery.of(ctx).size;
          final maxW = min(screen.width * .92, 720.0);
          final maxH = screen.height * .9;

          return Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxW, maxHeight: maxH),
              child: Material(
                color: const Color(0xFFF3F7F4),
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Detail Transaksi ${_fmtDate.format(DateTime.parse(ymd))}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 18),
                        ),
                        const SizedBox(height: 12),

                        _detailGroup(
                          title: 'penjualan',
                          color: Colors.green,
                          items: penjualan,
                          total: totP,
                        ),
                        const SizedBox(height: 10),
                        _detailGroup(
                          title: 'beban_usaha',
                          color: Colors.red,
                          items: beban,
                          total: totB,
                        ),
                        const SizedBox(height: 10),

                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: const Text('Tutup'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
    } catch (e) {
      await showTopToast(context, 'Gagal memuat detail: $e',
          icon: Icons.warning_amber);
    }
  }

  Widget _detailGroup({
    required String title,
    required Color color,
    required List<Map<String,dynamic>> items,
    required num total,
  }) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
      child: Column(
        children: [
          ListTile(
            dense: true,
            leading: Icon(title == 'penjualan' ? Icons.add_circle : Icons.remove_circle, color: color),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            trailing: Text(_fmtCur.format(total), style: TextStyle(fontWeight: FontWeight.w800, color: color)),
          ),
          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: Align(alignment: Alignment.centerLeft, child: Text('Tidak ada data')),
            ),
          ...items.map((e) => Padding(
            padding: const EdgeInsets.fromLTRB(72, 0, 16, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(child: Text(e['label'] ?? '—')),
                Text(_fmtCur.format(_num(e['jumlah']))),
              ],
            ),
          )),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  // ===== EDIT KETERANGAN =====
  Future<void> _editKeterangan(String ymd, String current) async {
    final ctrl = TextEditingController(text: current == '—' ? '' : current);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Keterangan'),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Isi keterangan untuk tanggal ini'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok == true) {
      final newKet = ctrl.text.trim();
      try {
        await _supabase
            .from('transaksi_harian')
            .update({'keterangan': newKet})
            .eq('id_usaha', widget.idUsaha)
            .eq('tanggal', ymd);

        // LOG
        await logService.addLog(
          aktivitas: 'edit_keterangan_transaksi',
          halaman: 'Laporan Penjualan & Beban Usaha',
          detail: 'Ubah keterangan ${ymd} menjadi: "${newKet.isEmpty ? '(kosong)' : newKet}"',
        );

        await showTopToast(context, 'Keterangan diperbarui', icon: Icons.check_circle);
        await _fetchData();
      } catch (e) {
        await showTopToast(context, 'Gagal simpan: $e', icon: Icons.warning_amber);
      }
    }
  }
}

// ====== Reusable kecil (sama seperti di LaporanLBPage) ======
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ==== Toast kecil di dekat atas ====
Future<void> showTopToast(
    BuildContext context,
    String message, {
      IconData icon = Icons.check_circle_rounded,
      Duration duration = const Duration(milliseconds: 1600),
    }) async {
  if (!(context as Element).mounted) return;
  await showGeneralDialog(
    context: context,
    barrierColor: Colors.transparent,
    barrierDismissible: true,
    barrierLabel: 'dismiss',
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (ctx, _, __) {
      Future.delayed(duration, () { if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop(); });
      return SafeArea(
        child: Align(
          alignment: const Alignment(0, -0.92),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black87, borderRadius: BorderRadius.circular(12),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Flexible(child: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
      return FadeTransition(
        opacity: anim,
        child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
      );
    },
  );
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
