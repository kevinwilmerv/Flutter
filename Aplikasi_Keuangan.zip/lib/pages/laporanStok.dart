import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/app_background.dart';

// PDF
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class LaporanStok extends StatefulWidget {
  final String idUsaha;
  const LaporanStok({super.key, required this.idUsaha});

  @override
  State<LaporanStok> createState() => _LaporanStokState();
}

class _LaporanStokState extends State<LaporanStok> {
  final supabase = Supabase.instance.client;

  String? selectedKategori;
  List<String> kategoriList = [];

  // baris laporan hasil agregasi per bahan
  List<Map<String, dynamic>> _rows = [];
  bool _loading = false;

  DateTime? startDate;
  DateTime? endDate;

  // ====== NEW: select mode ======
  bool _selectMode = false;
  final Set<String> _selectedIds = {};

  // formatter
  final DateFormat _fmtChip = DateFormat('d MMM yyyy', 'id_ID');
  final DateFormat _fmtIso  = DateFormat('yyyy-MM-dd');
  final NumberFormat _nf    = NumberFormat.decimalPattern('id_ID');

  // sinkron scroll header-body
  final _hHeader = ScrollController();
  final _hBody   = ScrollController();

  // header tabel & lebar dasar kolom (akan diskalakan responsif)
  final List<String> _headers = const [
    'Nama', 'Awal', 'Beli', 'Ambil', 'Stok Akhir', 'Total Harga', 'Satuan',
  ];
  final List<double> _baseWidths = const [220, 130, 130, 130, 150, 170, 140];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // preload semua varian supaya transisinya halus
    AppBackground.precacheAll(context);
  }

  @override
  void initState() {
    super.initState();

    // sinkronisasi scroll header <-> body
    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });

    _fetchKategori();
  }

  @override
  void dispose() {
    _hHeader.dispose();
    _hBody.dispose();
    super.dispose();
  }

  // ================== HELPERS ==================
  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  String _rowId(Map<String, dynamic> r) =>
      (r['id'] ?? r['id_bahan'] ?? '').toString();

  bool get _hasRange => startDate != null && endDate != null;

  // ================== DATA: kategori (master) ==================
  Future<void> _fetchKategori() async {
    // 🚫 Jangan load kategori kalau belum pilih rentang
    if (startDate == null || endDate == null) {
      setState(() {
        kategoriList = [];
        selectedKategori = null;
      });
      return;
    }

    try {
      var q = supabase
          .from('laporan_stok')
          .select('kategori')
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _fmtIso.format(startDate!))
          .lte('tanggal', _fmtIso.format(endDate!));

      final rows = await q;
      final list = (rows as List<dynamic>)
          .map<String>((r) => (r['kategori'] ?? '').toString().trim())
          .where((s) => s.isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      list.insert(0, 'Semua Kategori');

      if (!mounted) return;
      setState(() {
        kategoriList = list;
        if (selectedKategori != null && !kategoriList.contains(selectedKategori)) {
          selectedKategori = null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal memuat kategori: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 1800),
      );
    }
  }

  // ================== DATA: laporan dari InputPBP ==================
  Future<void> _fetchReport() async {
    final kat = selectedKategori; // snapshot

    // reset pilihan saat data diganti
    _selectedIds.clear();

    if (kat == null || startDate == null || endDate == null) {
      setState(() => _rows = []);
      return;
    }

    setState(() => _loading = true);

    try {
      var q = supabase
          .from('laporan_stok')
          .select(
          'id_bahan, nama_bahan, satuan, awal, beli, ambil, stok_akhir, total_harga, tanggal, kategori'
      )
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _fmtIso.format(startDate!))
          .lte('tanggal', _fmtIso.format(endDate!));

      if (kat != 'Semua Kategori') {
        q = q.eq('kategori', kat);
      }

      // penting: urutkan tanggal ASC supaya first/last akurat
      final data = await q.order('tanggal', ascending: true).order('nama_bahan');
      final list = List<Map<String, dynamic>>.from(data);

      // agregasi per id_bahan (awal = dari hari pertama, akhir = stok_akhir hari terakhir)
      final Map<String, Map<String, dynamic>> agg = {};
      for (final r in list) {
        final id   = (r['id_bahan'] ?? '').toString();
        final nama = (r['nama_bahan'] ?? '').toString();
        final sat  = (r['satuan'] ?? '').toString();

        final awal       = _num(r['awal']);
        final beli       = _num(r['beli']);
        final ambil      = _num(r['ambil']);
        final stokAkhir  = _num(r['stok_akhir']);
        final totalHarga = _num(r['total_harga']);

        final bucket = agg.putIfAbsent(id, () => {
          'id': id,
          'nama_bahan': nama,
          'satuan': sat,
          'awal': null,          // akan diisi pertama kali muncul
          'beli': 0,
          'ambil': 0,
          'total_harga': 0,
          'akhir': null,         // akan di-update setiap baris (jadi last)
        });

        if (bucket['awal'] == null) bucket['awal'] = awal;

        bucket['beli']        = (_num(bucket['beli'])  + beli);
        bucket['ambil']       = (_num(bucket['ambil']) + ambil);
        bucket['total_harga'] = (_num(bucket['total_harga']) + totalHarga);

        bucket['akhir'] = stokAkhir;

        if ((bucket['satuan'] as String).isEmpty && sat.isNotEmpty) {
          bucket['satuan'] = sat;
        }
      }

      for (final m in agg.values) {
        if (m['akhir'] == null) {
          final a = _num(m['awal']);
          final b = _num(m['beli']);
          final c = _num(m['ambil']);
          m['akhir'] = a + b - c;
        }
        m['awal']  = _num(m['awal']);
        m['akhir'] = _num(m['akhir']);
      }

      final rows = agg.values.toList()
        ..sort((a, b) => (a['nama_bahan'] as String)
            .compareTo(b['nama_bahan'] as String));

      if (!mounted) return;
      setState(() {
        _rows = rows;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      await showTopToast(
        context,
        'Gagal memuat laporan: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 1800),
      );
    }
  }

  // ====== DELETE (baru) ======

  Future<void> _deleteAll() async {
    if (!_hasRange) {
      await showTopToast(context, 'Pilih rentang tanggal dulu.', icon: Icons.info);
      return;
    }
    if (_rows.isEmpty) {
      await showTopToast(context, 'Tidak ada data pada filter ini.', icon: Icons.info);
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus semua data?'),
        content: Text(
          'Semua data pada periode '
              '${_fmtChip.format(startDate!)} s/d ${_fmtChip.format(endDate!)} '
              '(${selectedKategori ?? "Semua Kategori"}) akan dihapus permanen.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      var del = supabase
          .from('laporan_stok')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _fmtIso.format(startDate!))
          .lte('tanggal', _fmtIso.format(endDate!));

      if (selectedKategori != null && selectedKategori != 'Semua Kategori') {
        del = del.eq('kategori', selectedKategori ?? '');
      }

      await del;

      await LogService().addLog(
        aktivitas: 'Delete',
        halaman: 'Laporan Persediaan Bahan Pokok (PBP)',
        detail: 'Delete All | Periode: ${_fmtChip.format(startDate!)} s/d ${_fmtChip.format(endDate!)} | '
            'Kategori: ${selectedKategori ?? "Semua Kategori"}',
      );

      await showTopToast(context, 'Semua data pada filter ini berhasil dihapus.', icon: Icons.check_circle);
      await _fetchKategori();
      await _fetchReport();
    } catch (e) {
      await showTopToast(context, 'Gagal hapus semua: $e', icon: Icons.warning_amber_rounded);
    }
  }

  Future<void> _deleteSelected() async {
    if (_selectedIds.isEmpty) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus data terpilih?'),
        content: Text('${_selectedIds.length} data akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      var del = supabase
          .from('laporan_stok')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .inFilter('id_bahan', _selectedIds.toList());

      // batasi sesuai rentang & kategori aktif (biar selaras ekspektasi user)
      if (_hasRange) {
        del = del
            .gte('tanggal', _fmtIso.format(startDate!))
            .lte('tanggal', _fmtIso.format(endDate!));
      }
      if (selectedKategori != null && selectedKategori != 'Semua Kategori') {
        del = del.eq('kategori', selectedKategori ?? '');
      }

      await del;

      await LogService().addLog(
        aktivitas: 'Delete',
        halaman: 'Laporan Persediaan Bahan Pokok (PBP)',
        detail: 'Delete Selected | Jumlah: ${_selectedIds.length} | '
            'Periode: ${_hasRange ? "${_fmtChip.format(startDate!)} s/d ${_fmtChip.format(endDate!)}" : "-"} | '
            'Kategori: ${selectedKategori ?? "-"}',
      );

      setState(() {
        _selectedIds.clear();
        _selectMode = false;
      });

      await showTopToast(context, 'Data terpilih berhasil dihapus.', icon: Icons.check_circle);
      await _fetchReport();
    } catch (e) {
      await showTopToast(context, 'Gagal hapus: $e', icon: Icons.warning_amber_rounded);
    }
  }

  void _toggleSelectMode() {
    setState(() {
      _selectMode = !_selectMode;
      if (!_selectMode) _selectedIds.clear();
    });
  }

  bool _isAllVisibleSelected() {
    final visible = _rows.map(_rowId).where((id) => id.isNotEmpty).toSet();
    return visible.isNotEmpty && _selectedIds.containsAll(visible);
  }

  void _toggleSelectAllVisible() {
    final visible = _rows.map(_rowId).where((id) => id.isNotEmpty).toSet();
    setState(() {
      if (_isAllVisibleSelected()) {
        _selectedIds.removeAll(visible);
      } else {
        _selectedIds.addAll(visible);
      }
    });
  }

  // ========== Date range helpers ==========
  void _clearRange() {
    setState(() {
      startDate = null;
      endDate   = null;
      _rows     = [];
      _selectedIds.clear();
      _selectMode = false;
    });
    _fetchKategori();
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: startDate ?? DateTime(now.year, now.month, 1),
      end: endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      builder: (ctx, child) =>
          Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );

    if (picked != null) {
      setState(() {
        startDate = picked.start;
        endDate   = picked.end;
      });
      await _fetchKategori();
      await _fetchReport();
    }
  }

  Future<void> _applyPresetRange(String code) async {
    final now = DateTime.now();
    if (code == 'all') {
      startDate = DateTime(2020, 1, 1);
      endDate   = now;
    } else if (code == 'month') {
      startDate = DateTime(now.year, now.month, 1);
      endDate   = DateTime(now.year, now.month + 1, 0);
    } else if (code == '7') {
      startDate = now.subtract(const Duration(days: 6));
      endDate   = now;
    } else if (code == '30') {
      startDate = now.subtract(const Duration(days: 29));
      endDate   = now;
    }
    setState(() {});
    await _fetchKategori();
    await _fetchReport();
  }

  // ========== Export PDF ==========
  Future<void> _exportPdf() async {
    if (selectedKategori == null || selectedKategori!.isEmpty) {
      await showTopToast(
        context,
        "Pilih kategori terlebih dahulu",
        icon: Icons.info_rounded,
      );
      return;
    }
    if (startDate == null || endDate == null) {
      await showTopToast(
        context,
        "Pilih rentang tanggal terlebih dahulu",
        icon: Icons.info_rounded,
      );
      return;
    }
    if (_rows.isEmpty) {
      await showTopToast(
        context,
        "Tidak ada data untuk diexport",
        icon: Icons.info_rounded,
      );
      return;
    }

    final doc = pw.Document();
    final headers = <String>[
      'Nama', 'Awal', 'Beli', 'Ambil', 'Stok Akhir', 'Total Harga', 'Satuan',
    ];

    final data = <List<String>>[
      for (final r in _rows)
        [
          r['nama_bahan'].toString(),
          _nf.format(r['awal']),
          _nf.format(r['beli']),
          _nf.format(r['ambil']),
          _nf.format(r['akhir']),
          _nf.format(r['total_harga']),
          (r['satuan'] ?? '-').toString(),
        ],
    ];

    num tAwal = 0, tBeli = 0, tAmbil = 0, tAkhir = 0;
    for (final r in _rows) {
      tAwal  += _num(r['awal']);
      tBeli  += _num(r['beli']);
      tAmbil += _num(r['ambil']);
      tAkhir += _num(r['akhir']);
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(24),
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Laporan ALPB (Analisa Pemakaian Bahan Pokok)',
                  style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
              pw.Text('Kode Usaha: ${widget.idUsaha}', style: const pw.TextStyle(fontSize: 12)),
            ],
          ),
          pw.SizedBox(height: 6),
          pw.Text('Kategori: ${selectedKategori ?? "-"}', style: const pw.TextStyle(fontSize: 12)),
          pw.Text(
            'Periode: ${_fmtChip.format(startDate!)} s/d ${_fmtChip.format(endDate!)}',
            style: const pw.TextStyle(fontSize: 12),
          ),
          pw.SizedBox(height: 12),
          pw.TableHelper.fromTextArray(
            headers: headers,
            data: data,
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.blueGrey800),
            cellAlignments: const {
              0: pw.Alignment.centerLeft,
              1: pw.Alignment.centerRight,
              2: pw.Alignment.centerRight,
              3: pw.Alignment.centerRight,
              4: pw.Alignment.centerRight,
              5: pw.Alignment.centerRight,
              6: pw.Alignment.center,
            },
            cellStyle: const pw.TextStyle(fontSize: 10),
            headerHeight: 24,
            cellHeight: 22,
            border: null,
            oddRowDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF5F5F5)),
          ),
          pw.SizedBox(height: 12),
          pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Container(
              padding: const pw.EdgeInsets.all(8),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey),
                borderRadius: pw.BorderRadius.circular(6),
              ),
              child: pw.Row(
                mainAxisSize: pw.MainAxisSize.min,
                children: [
                  pw.Text('Total  ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(width: 10),
                  pw.Text('Awal: ${_nf.format(tAwal)}   '
                      'Beli: ${_nf.format(tBeli)}   '
                      'Ambil: ${_nf.format(tAmbil)}   '
                      'Akhir: ${_nf.format(tAkhir)}'),
                ],
              ),
            ),
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => doc.save(),
      name: 'Laporan_ALPB_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.pdf',
    );

    await showTopToast(
      context,
      'PDF siap dicetak / dibagikan',
      icon: Icons.check_circle_rounded,
    );
  }

  // ================== UI (filter tanggal bar) ==================
  Widget _dateRangeBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Tanggal (Rentang)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _openRangePicker,
              icon: const Icon(Icons.date_range, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFE4E9),
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                  side: const BorderSide(color: Colors.black, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
              label: const Text('Rentang Tanggal'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _clearRange,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.black, width: 1),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _DatePill(
                label: 'Tanggal Awal',
                value: startDate == null ? '—' : _fmtChip.format(startDate!),
                onTap: _openRangePicker,
              ),
            ),
            const SizedBox(width: 8),
            const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            Expanded(
              child: _DatePill(
                label: 'Tanggal Akhir',
                value: endDate == null ? '—' : _fmtChip.format(endDate!),
                onTap: _openRangePicker,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _PresetChip(text: 'Semua Data', onTap: () => _applyPresetRange('all')),
            _PresetChip(text: 'Bulan Ini', onTap: () => _applyPresetRange('month')),
            _PresetChip(text: '7 Hari', onTap: () => _applyPresetRange('7')),
            _PresetChip(text: '30 Hari', onTap: () => _applyPresetRange('30')),
          ],
        ),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: ElevatedButton.icon(
            onPressed: _exportPdf,
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text('Export PDF'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF2F2F2),
              foregroundColor: Colors.black,
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
          ),
        ),
      ],
    );
  }

  // ================== UI: header & row kapsul ==================
  Widget _buildHeader(List<double> widths) {
    const double sideInset = 20;
    final headers = _selectMode
        ? [' ', ..._headers] // spasi untuk kolom checkbox overlay
        : _headers;

    final widthsAdj = _selectMode
        ? [54.0, ...widths] // kolom checkbox
        : widths;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: sideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: { for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i]) },
        children: [
          TableRow(
            children: List.generate(headers.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(headers[i], textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholderStock(List<double> widths) {
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;
    return _capsuleRow(
      child: Table(
        columnWidths: { for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i]) },
        children: [
          TableRow(children: List.generate(widthsAdj.length, (i) => _cellText('–'))),
        ],
      ),
    );
  }

  Widget _tableRowStock(List<double> widths, Map<String, dynamic> r) {
    final widthsAdj = _selectMode ? [54.0, ...widths] : widths;
    return _capsuleRow(
      child: Table(
        columnWidths: { for (int i = 0; i < widthsAdj.length; i++) i: FixedColumnWidth(widthsAdj[i]) },
        children: [
          TableRow(
            children: [
              if (_selectMode)
              // kolom checkbox
                Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Checkbox(
                    value: _selectedIds.contains(_rowId(r)),
                    onChanged: (v) {
                      final id = _rowId(r);
                      if (id.isEmpty) return;
                      setState(() {
                        if (v == true) {
                          _selectedIds.add(id);
                        } else {
                          _selectedIds.remove(id);
                        }
                      });
                    },
                    side: const BorderSide(color: Colors.black87),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                  ),
                ),
              _cellText(r['nama_bahan'].toString()),
              _cellText(_nf.format(_num(r['awal']))),
              _cellText(_nf.format(_num(r['beli']))),
              _cellText(_nf.format(_num(r['ambil']))),
              _cellText(_nf.format(_num(r['akhir']))),
              _cellText(_nf.format(_num(r['total_harga']))),
              _cellText((r['satuan'] ?? '-').toString()),
            ],
          ),
        ],
      ),
    );
  }

  Widget _dataRowStock({
    required List<double> widths,
    required Map<String, dynamic> r,
    required bool isFirst,
  }) {
    final idBahan = _rowId(r);
    final isSelected = _selectedIds.contains(idBahan);

    return GestureDetector(
      onTap: _selectMode && idBahan.isNotEmpty
          ? () {
        setState(() {
          if (isSelected) {
            _selectedIds.remove(idBahan);
          } else {
            _selectedIds.add(idBahan);
          }
        });
      }
          : null,
      child: Container(
        margin: EdgeInsets.only(top: isFirst ? 12 : 8, left: 6, right: 6),
        decoration: BoxDecoration(
          color: _selectMode && isSelected ? const Color(0xFFFFE4E9) : Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: _selectMode && isSelected ? const Color(0xFF8E101A) : Colors.black.withOpacity(0.05),
            width: _selectMode && isSelected ? 2 : 1,
          ),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: _tableRowStock(widths, r),
      ),
    );
  }

  Widget _capsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4))],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _cellText(String text) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Paksa LIGHT theme hanya untuk halaman ini
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      dropdownMenuTheme: base.dropdownMenuTheme.copyWith(
        textStyle: const TextStyle(color: Colors.black87),
      ),
      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        hintStyle: const TextStyle(color: Colors.black54),
        labelStyle: const TextStyle(color: Colors.black87),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,   // teks tombol primary tetap putih
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.22,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            extendBodyBehindAppBar: false,
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: () => Navigator.pop(context),
              ),
              title: const Text("Laporan Persediaan Bahan Pokok",
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
              centerTitle: false,
              actions: [
                // Toggle Select Mode
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _toggleSelectMode,
                  icon: Icon(_selectMode ? Icons.check_box : Icons.check_box_outline_blank, color: Colors.black87),
                  label: Text(_selectMode ? 'Selesai' : 'Pilih Data',
                      style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
                // Delete All
                TextButton.icon(
                  onPressed: _rows.isEmpty ? null : _deleteAll,
                  icon: const Icon(Icons.delete_forever, color: Color(0xFF8E101A)),
                  label: const Text('Hapus Semua',
                      style: TextStyle(color: Color(0xFF8E101A), fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 6),
              ],
            ),

            // ===== Bilah aksi bawah ketika Select Mode aktif =====
            bottomNavigationBar: !_selectMode
                ? null
                : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 10, offset: const Offset(0, -4))],
                  border: Border(top: BorderSide(color: Colors.black.withOpacity(.08))),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${_selectedIds.length} dipilih',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: _rows.isEmpty ? null : _toggleSelectAllVisible,
                      icon: Icon(_isAllVisibleSelected() ? Icons.select_all : Icons.checklist),
                      label: Text(_isAllVisibleSelected() ? 'Batalkan Semua' : 'Pilih Semua'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: () => setState(() {
                        _selectedIds.clear();
                        _selectMode = false;
                      }),
                      child: const Text('Batal'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF8E101A),
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _selectedIds.isEmpty ? null : _deleteSelected,
                      icon: const Icon(Icons.delete),
                      label: const Text('Hapus Terpilih'),
                    ),
                  ],
                ),
              ),
            ),

            body: SafeArea(
              top: false,
              minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: LayoutBuilder(
                builder: (context, c) {
                  final minTotal   = _baseWidths.reduce((a, b) => a + b);
                  final available  = c.maxWidth - 24; // padding card
                  final totalW     = (available >= minTotal) ? available : minTotal.toDouble();
                  final scale      = totalW / minTotal;
                  final widths     = _baseWidths.map((w) => w * scale).toList();
                  final tableWidth = widths.reduce((a, b) => a + b);

                  return Scrollbar(
                    thumbVisibility: true,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 8),

                          // Rentang Tanggal
                          _dateRangeBar(),
                          const SizedBox(height: 10),

                          // ===== UI: Filter Kategori =====
                          if (startDate != null && endDate != null)
                            Container(
                              margin: const EdgeInsets.only(top: 2, bottom: 10),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.92),
                                borderRadius: BorderRadius.circular(22),
                                border: Border.all(color: Colors.black.withOpacity(0.10)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.10),
                                    blurRadius: 16,
                                    offset: const Offset(0, 6),
                                  ),
                                ],
                              ),
                              padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Filter Kategori',
                                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                                  ),
                                  const SizedBox(height: 8),

                                  DropdownButtonFormField<String>(
                                    value: selectedKategori,
                                    isExpanded: true,
                                    menuMaxHeight: 320,
                                    hint: const Text("Pilih Kategori"),
                                    style: const TextStyle(color: Colors.black87),
                                    dropdownColor: Colors.white,
                                    iconEnabledColor: Colors.black87,
                                    items: kategoriList.map((k) => DropdownMenuItem(
                                      value: k,
                                      child: Text(k, style: const TextStyle(color: Colors.black87)),
                                    )).toList(),
                                    onChanged: (v) async {
                                      setState(() => selectedKategori = v);
                                      await _fetchReport();
                                    },
                                    decoration: InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      prefixIcon: const Icon(Icons.category_outlined, size: 18, color: Colors.black87),
                                      hintStyle: const TextStyle(color: Colors.black54),
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30),
                                        borderSide: BorderSide(color: Colors.black.withOpacity(.22)),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(30),
                                        borderSide: BorderSide(color: Colors.black.withOpacity(.22)),
                                      ),
                                      focusedBorder: const OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(30)),
                                        borderSide: BorderSide(color: Colors.black, width: 1.2),
                                      ),
                                    ),
                                  ),

                                  if (_selectMode) ...[
                                    const SizedBox(height: 10),
                                    Row(
                                      children: const [
                                        Icon(Icons.touch_app, size: 16),
                                        SizedBox(width: 6),
                                        Expanded(
                                          child: Text(
                                            'Tap baris untuk memilih. Gunakan bilah di bawah untuk Hapus Terpilih.',
                                            style: TextStyle(fontSize: 12),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ],
                              ),
                            )
                          else
                            Container(
                              margin: const EdgeInsets.only(top: 2, bottom: 10),
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.92),
                                borderRadius: BorderRadius.circular(22),
                                border: Border.all(color: Colors.black.withOpacity(0.10)),
                              ),
                              child: const Text(
                                'Silakan pilih rentang tanggal untuk melihat kategori.',
                                style: TextStyle(color: Colors.black54),
                              ),
                            ),

                          const SizedBox(height: 10),

                          // ====== KARTU TABEL ======
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.35),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 14,
                                  offset: const Offset(0, 6),
                                )
                              ],
                            ),
                            padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                            child: Column(
                              children: [
                                // HEADER (HS)
                                Scrollbar(
                                  controller: _hHeader,
                                  thumbVisibility: true,
                                  child: SingleChildScrollView(
                                    controller: _hHeader,
                                    scrollDirection: Axis.horizontal,
                                    child: SizedBox(width: (_selectMode ? 54.0 : 0) + tableWidth, child: _buildHeader(widths)),
                                  ),
                                ),
                                const SizedBox(height: 8),

                                // BODY (HS)
                                Scrollbar(
                                  controller: _hBody,
                                  thumbVisibility: true,
                                  notificationPredicate: (n) => n.depth == 1,
                                  child: SingleChildScrollView(
                                    controller: _hBody,
                                    scrollDirection: Axis.horizontal,
                                    child: SizedBox(
                                      width: (_selectMode ? 54.0 : 0) + tableWidth,
                                      child: _loading
                                          ? const Padding(
                                        padding: EdgeInsets.all(24.0),
                                        child: Center(child: CircularProgressIndicator()),
                                      )
                                          : (_rows.isEmpty
                                          ? _buildPlaceholderStock(widths)
                                          : Column(
                                        children: List.generate(
                                          _rows.length,
                                              (i) => _dataRowStock(
                                            widths: widths,
                                            r: _rows[i],
                                            isFirst: i == 0,
                                          ),
                                        ),
                                      )),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ===== Reusable kecil: pill & preset chip =====
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback? onTap;
  const _DatePill({required this.label, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    final pill = Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );

    return MouseRegion(
      cursor: onTap == null ? SystemMouseCursors.basic : SystemMouseCursors.click,
      child: InkWell(borderRadius: BorderRadius.circular(40), onTap: onTap, child: pill),
    );
  }
}

// ==== Toast hitam kecil seragam (top) ====
Future<void> showTopToast(
    BuildContext context,
    String message, {
      IconData icon = Icons.check_circle_rounded,
      Duration duration = const Duration(milliseconds: 1600),
    }) async {
  if (!context.mounted) return;
  await showGeneralDialog(
    context: context,
    barrierColor: Colors.transparent,
    barrierDismissible: true,
    barrierLabel: 'dismiss',
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (ctx, _, __) {
      Future.delayed(duration, () {
        if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
      });
      return SafeArea(
        child: Align(
          alignment: const Alignment(0, -0.92),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      message,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
      return FadeTransition(
        opacity: anim,
        child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
      );
    },
  );
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
