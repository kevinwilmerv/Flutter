import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:ok_oce/dashboard/dashboard_usaha.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/pop_notifier.dart';
import 'package:ok_oce/widget/app_background.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final supabase = Supabase.instance.client;
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool isLoading = false;

  void _toast(String title, String message, {bool success = false}) {
    PopNotifier.I.show(
      context,
      title: title,
      message: message,
      type: success ? NoticeType.success : NoticeType.error,
      duration: const Duration(seconds: 2),
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
  }

  // ▶ Perketat: hanya deteksi pesan "belum terverifikasi"
  bool _looksUnverified(AuthApiException e) {
    final msg = (e.message ?? '').toLowerCase();
    return e.statusCode == 400 && msg.contains('belum terverifikasi');
  }

  Future<void> _resendVerification(String email) async {
    try {
      await supabase.auth.resend(type: OtpType.signup, email: email);
      _toast('Terkirim', 'Email verifikasi sudah dikirim ke $email.', success: true);
    } catch (_) {
      _toast('Gagal', 'Tidak bisa mengirim ulang email verifikasi. Coba lagi nanti.');
    }
  }

  Future<void> _showUnverifiedDialog(String email) async {
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Perlu Verifikasi'),
        content: Text('Akun belum diverifikasi. Cek email $email untuk verifikasi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _resendVerification(email);
            },
            child: const Text('Kirim Ulang'),
          ),
        ],
      ),
    );
  }

  /// 🔹 Fungsi Forgot Password
  Future<void> _forgotPasswordDialog() async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Lupa Password'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            labelText: 'Masukkan email Anda',
            hintText: 'contoh@email.com',
          ),
          keyboardType: TextInputType.emailAddress,
          autofillHints: const [AutofillHints.email],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              final email = controller.text.trim();
              if (email.isEmpty) {
                _toast('Gagal', 'Email wajib diisi.');
                return;
              }
              // Validasi format email sederhana
              final emailOk = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email);
              if (!emailOk) {
                _toast('Gagal', 'Format email tidak valid.');
                return;
              }
              Navigator.pop(context);
              await _resetPassword(email);
            },
            child: const Text('Kirim'),
          ),
        ],
      ),
    );
  }

  /// Kirim email reset password (pesan generik)
  Future<void> _resetPassword(String email) async {
    try {
      await supabase.auth.resetPasswordForEmail(
        email,
        redirectTo: 'https://www.inmato.id/auth-callback/reset-password.html',
      );
      _toast('Cek email Anda', 'Jika email terdaftar, tautan reset sudah dikirim.', success: true);
    } on AuthApiException catch (e) {
      _toast('Gagal', e.message ?? 'Gagal mengirim email reset password.');
    } catch (_) {
      _toast('Gagal', 'Terjadi kesalahan saat mengirim email reset password.');
    }
  }

  /// 🔹 Proses Login (tetap)
  Future<void> login() async {
    if (isLoading) return;
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _toast('Gagal', 'Email dan password wajib diisi.');
      return;
    }

    setState(() => isLoading = true);
    try {
      final response = await supabase.auth
          .signInWithPassword(email: email, password: password)
          .timeout(const Duration(seconds: 15));

      final user = response.user;
      if (user == null) {
        _toast('Gagal', 'Login gagal. Pengguna tidak ditemukan.');
        return;
      }

      final userData = await supabase
          .from('profiles')
          .select('nama, role, id_usaha')
          .eq('id', user.id)
          .maybeSingle()
          .timeout(const Duration(seconds: 15));

      if (userData == null) {
        _toast('Gagal', 'Data pengguna tidak ditemukan.');
        return;
      }

      final role = (userData['role'] ?? '').toString();
      final nama = (userData['nama'] ?? '').toString();
      final idUsaha = userData['id_usaha'];

      try {
        await LogService().addLog(
          aktivitas: "Login",
          halaman: "Auth",
          detail: "User $nama ($role) berhasil login",
        );
      } catch (_) {}

      if (role == 'admin_pusat') {
        if (!mounted) return;
        Navigator.pushReplacementNamed(
          context,
          '/dashboard-admin',
          arguments: {'showWelcome': true, 'welcomeText': 'Selamat datang, $nama!'},
        );
      } else if (role == 'admin_usaha') {
        if (idUsaha == null) {
          _toast('Gagal', 'ID usaha tidak ditemukan untuk admin_usaha.');
          return;
        }
        final usahaData = await supabase
            .from('usaha')
            .select('nama_usaha')
            .eq('id_usaha', idUsaha)
            .maybeSingle();
        final namausaha = usahaData?['nama_usaha'] ?? 'Usaha';

        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => Dashboardusaha(idUsaha: idUsaha, namausaha: namausaha),
          ),
        );
      } else if (role == 'staff') {
        if (!mounted) return;
        Navigator.pushReplacementNamed(
          context,
          '/dashboard_staff',
          arguments: {'showWelcome': true, 'welcomeText': 'Selamat datang, $nama!'},
        );
      } else {
        _toast('Gagal', 'Role tidak dikenali.');
      }
    } on AuthApiException catch (e, stackTrace) {
      if (_looksUnverified(e)) await _showUnverifiedDialog(email);
      _toast('Gagal', e.message ?? 'Autentikasi gagal.');
      debugPrintStack(stackTrace: stackTrace);
    } on TimeoutException {
      _toast('Gagal', 'Koneksi lambat atau server tidak merespons.');
    } catch (e, stackTrace) {
      _toast('Gagal', 'Kesalahan: $e');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // ====== LOGO STRIP ======
  Widget _logoStrip() {
    const logos = <String>[
      'assets/IBIKKG.png',
      'assets/Kemendiktisaintek.png',
      'assets/OK_OCE.png',
      'assets/LOGOSR1.png'
    ];
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        double h;
        if (w < 380) {
          h = 42;
        } else if (w < 600) {
          h = 54;
        } else if (w < 1024) {
          h = 66;
        } else {
          h = 78;
        }
        return Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Wrap(
            spacing: 20,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              for (final path in logos)
                Image.asset(path, height: h, fit: BoxFit.contain, filterQuality: FilterQuality.medium),
            ],
          ),
        );
      },
    );
  }

  // ====== CARD LOGIN ======
  Widget _loginCard() {
    return LayoutBuilder(
      builder: (context, c) {
        final double maxCardWidth = c.maxWidth <= 600 ? c.maxWidth : 520;
        bool _obscure = true;

        return Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxCardWidth),
            child: Card(
              color: Colors.white.withOpacity(0.96),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: StatefulBuilder(
                  builder: (context, setSB) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            "Masuk Akun",
                            style: TextStyle(
                              fontSize: c.maxWidth < 360 ? 20 : 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          autofillHints: const [AutofillHints.username, AutofillHints.email],
                          decoration: const InputDecoration(labelText: 'Email'),
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 14),
                        TextField(
                          controller: passwordController,
                          obscureText: _obscure,
                          autofillHints: const [AutofillHints.password],
                          decoration: InputDecoration(
                            labelText: 'Password',
                            suffixIcon: IconButton(
                              onPressed: () => setSB(() => _obscure = !_obscure),
                              icon: Icon(_obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                            ),
                          ),
                          onSubmitted: (_) {
                            if (!isLoading) login();
                          },
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: _forgotPasswordDialog,
                            child: const Text('Lupa password?'),
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : login,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.indigo,
                              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: isLoading
                                ? const SizedBox(
                              height: 22,
                              width: 22,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                                : const Text('Login', style: TextStyle(fontSize: 16, color: Colors.white)),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Align(
                          alignment: Alignment.center,
                          child: TextButton(
                            onPressed: () => Navigator.pushReplacementNamed(context, '/register'),
                            child: const Text('Belum punya akun? Daftar di sini'),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.25,
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _logoStrip(),
                    _loginCard(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
