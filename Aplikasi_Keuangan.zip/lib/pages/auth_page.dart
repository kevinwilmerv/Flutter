// auth_page.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:ok_oce/dashboard/dashboard_usaha.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/pop_notifier.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/pages/reset_password_page.dart';

/// ——— Toast kecil hitam (atas) ———
Future<void> showTopToast(
    BuildContext context,
    String message, {
      IconData icon = Icons.check_circle_rounded,
      Duration duration = const Duration(milliseconds: 1600),
    }) async {
  if (!(context as Element).mounted) return;
  await showGeneralDialog(
    context: context,
    barrierColor: Colors.transparent,
    barrierDismissible: true,
    barrierLabel: 'dismiss',
    transitionDuration: const Duration(milliseconds: 220),
    pageBuilder: (ctx, _, __) {
      Future.delayed(duration, () {
        if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
      });
      return SafeArea(
        child: Align(
          alignment: const Alignment(0, -0.92),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [
                  BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      message,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (ctx, anim, __, child) {
      final curved = CurvedAnimation(
        parent: anim,
        curve: Curves.easeOutBack,
        reverseCurve: Curves.easeIn,
      );
      return FadeTransition(
        opacity: anim,
        child: ScaleTransition(
          scale: Tween<double>(begin: .92, end: 1).animate(curved),
          child: child,
        ),
      );
    },
  );
}

/// Formatter ID Usaha (USH-XXX-XXX-000)
class UsahaIdFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    String raw = newValue.text.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '').toUpperCase();
    if (raw.length > 12) raw = raw.substring(0, 12);
    final b = StringBuffer();
    for (int i = 0; i < raw.length; i++) {
      if (i > 0 && i % 3 == 0) b.write('-');
      b.write(raw[i]);
    }
    final t = b.toString();
    return TextEditingValue(text: t, selection: TextSelection.collapsed(offset: t.length));
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final supabase = Supabase.instance.client;

  // ===== Palette / Styles
  static const Color _kMaroon = Color(0xFF6B2B23);
  static const Color _kPillInactive = Color(0xFFF1E8E4);
  static const Color _kBorder = Color(0xFFE6DAD6);

  InputDecoration _dec(String label) => InputDecoration(
    labelText: label,
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: _kBorder, width: 1),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: _kMaroon, width: 1.2),
    ),
  );

  ButtonStyle _btnPrimary() => ButtonStyle(
    backgroundColor: MaterialStateProperty.resolveWith((s) {
      if (s.contains(MaterialState.disabled)) return _kMaroon.withOpacity(.45);
      if (s.contains(MaterialState.pressed)) return _kMaroon.withOpacity(.95);
      return _kMaroon;
    }),
    foregroundColor: const MaterialStatePropertyAll(Colors.white),
    minimumSize: const MaterialStatePropertyAll(Size(160, 44)),
    padding: const MaterialStatePropertyAll(EdgeInsets.symmetric(horizontal: 20)),
    shape: MaterialStatePropertyAll(
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
    elevation: const MaterialStatePropertyAll(3),
    textStyle: const MaterialStatePropertyAll(
      TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
    ),
  );

  // ===== Login ctrls
  final loginEmailController = TextEditingController();
  final loginPasswordController = TextEditingController();

  // ===== Sign up ctrls
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController(); // ⬅️ persist confirm
  final nameController = TextEditingController();
  final namausahaController = TextEditingController();
  final lokasiusahaController = TextEditingController();
  final idUsahaController = TextEditingController();
  final idPreviewController = TextEditingController(text: 'USH - NAMA USAHA - LOKASI - XXX');
  final adminKeyController = TextEditingController(); // <<— untuk admin_pusat

  // Obscure flags dipersist di State (tidak reset saat rebuild)
  bool _signupObscure = true;
  bool _signupObscureConfirm = true;

  String? selectedRole; // 'admin_pusat' | 'admin_usaha' | 'staff'
  Timer? _genDebounce;

  bool isLoadingLogin = false;
  bool isLoadingSign = false;

  bool _isLogin = true;

  @override
  void initState() {
    super.initState();
    namausahaController.addListener(_updateIdPreview);
    lokasiusahaController.addListener(_updateIdPreview);
    namausahaController.addListener(_scheduleGenerateId);
    lokasiusahaController.addListener(_scheduleGenerateId);
    _updateIdPreview();
  }

  @override
  void dispose() {
    loginEmailController.dispose();
    loginPasswordController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose(); // ⬅️ penting
    nameController.dispose();
    namausahaController.dispose();
    lokasiusahaController.dispose();
    idUsahaController.dispose();
    idPreviewController.dispose();
    adminKeyController.dispose();
    _genDebounce?.cancel();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
  }

  // ===== Helpers generate ID Usaha
  String _onlyLetters(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z\s]'), ' ').trim();

  String _nameCode3(String nama) {
    final n = _onlyLetters(nama);
    if (n.isEmpty) return 'XXX';
    final parts = n.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.length == 1) {
      final w = parts.first;
      final c1 = w[0], c2 = w.length >= 2 ? w[1] : w[0], c3 = w[w.length - 1];
      return (c1 + c2 + c3).padRight(3, 'X').substring(0, 3);
    }
    final f = parts.first, s = parts[1], l = parts.last;
    return (f[0] + s[0] + l[l.length - 1]).padRight(3, 'X').substring(0, 3);
  }

  String _locCode3(String lokasi) {
    final n = _onlyLetters(lokasi);
    if (n.isEmpty) return 'XXX';
    final parts = n.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    bool v(String c) => 'AEIOU'.contains(c);
    if (parts.length == 1) {
      final w = parts.first;
      final c1 = w[0];
      final c2 = w
          .substring(1)
          .split('')
          .firstWhere((ch) => !v(ch), orElse: () => w.length >= 2 ? w[1] : w[0]);
      final c3 = w.split('').reversed.firstWhere((ch) => !v(ch), orElse: () => w[w.length - 1]);
      return (c1 + c2 + c3).padRight(3, 'X').substring(0, 3);
    }
    final f = parts.first, s = parts[1], l = parts.last;
    return (f[0] + s[0] + l[l.length - 1]).padRight(3, 'X').substring(0, 3);
  }

  Future<String> generateusahaId() async {
    final nameCode = _nameCode3(namausahaController.text);
    final locCode = _locCode3(lokasiusahaController.text);
    final rows = await supabase.from('usaha').select('id_usaha');
    final ids = List<String>.from(rows.map((e) => '${e['id_usaha']}'.toUpperCase()));
    final reg = RegExp(r'^USH-[A-Z]{3}-[A-Z]{3}-(\d{3,})$');
    int maxN = 0;
    for (final id in ids) {
      final m = reg.firstMatch(id);
      if (m != null) {
        final n = int.tryParse(m.group(1)!) ?? 0;
        if (n > maxN) maxN = n;
      }
    }
    int i = maxN + 1;
    while (true) {
      final cand = 'USH-$nameCode-$locCode-${i.toString().padLeft(3, '0')}';
      if (!ids.contains(cand)) return cand;
      i++;
    }
  }

  String _onlyLettersDyn(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z\s]'), ' ').trim();
  String _nameCodeDyn(String nama) {
    final n = _onlyLettersDyn(nama);
    if (n.isEmpty) return '';
    final parts = n.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.length == 1) {
      final w = parts.first;
      final out = <String>[];
      if (w.isNotEmpty) out.add(w[0]);
      if (w.length >= 2) out.add(w[1]);
      if (w.length >= 2) out.add(w[w.length - 1]);
      return out.join();
    }
    final f = parts.first, s = parts.length >= 2 ? parts[1] : '', l = parts.last;
    final out = <String>[];
    if (f.isNotEmpty) out.add(f[0]);
    if (s.isNotEmpty) out.add(s[0]);
    if (l.isNotEmpty) out.add(l[l.length - 1]);
    return out.join();
  }

  String _locCodeDyn(String lokasi) {
    final n = _onlyLettersDyn(lokasi);
    if (n.isEmpty) return '';
    final parts = n.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    bool v(String c) => 'AEIOU'.contains(c);
    if (parts.length == 1) {
      final w = parts.first;
      final out = <String>[];
      if (w.isNotEmpty) out.add(w[0]);
      if (w.length >= 2) {
        String? c2;
        for (int i = 1; i < w.length; i++) {
          if (!v(w[i])) {
            c2 = w[i];
            break;
          }
        }
        out.add(c2 ?? w[1]);
      }
      if (w.isNotEmpty) {
        String? c3;
        for (int i = w.length - 1; i >= 0; i--) {
          if (!v(w[i])) {
            c3 = w[i];
            break;
          }
        }
        out.add(c3 ?? w[w.length - 1]);
      }
      return out.take(w.length >= 3 ? 3 : w.length).join();
    }
    final f = parts.first, s = parts.length >= 2 ? parts[1] : '', l = parts.last;
    final out = <String>[];
    if (f.isNotEmpty) out.add(f[0]);
    if (s.isNotEmpty) out.add(s[0]);
    if (l.isNotEmpty) out.add(l[l.length - 1]);
    return out.join();
  }

  void _updateIdPreview() {
    final left = _nameCodeDyn(namausahaController.text).isEmpty
        ? 'NAMA USAHA'
        : _nameCodeDyn(namausahaController.text);
    final right =
    _locCodeDyn(lokasiusahaController.text).isEmpty ? 'LOKASI' : _locCodeDyn(lokasiusahaController.text);
    final preview = 'USH - $left - $right - XXX';
    if (idPreviewController.text != preview) idPreviewController.text = preview;
  }

  void _scheduleGenerateId() {
    _genDebounce?.cancel();
    if (selectedRole == 'admin_usaha' &&
        namausahaController.text.trim().isNotEmpty &&
        lokasiusahaController.text.trim().isNotEmpty) {
      _genDebounce = Timer(const Duration(milliseconds: 400), () async {
        final id = await generateusahaId();
        if (!mounted) return;
        setState(() => idUsahaController.text = id);
      });
    } else {
      setState(() => idUsahaController.clear());
      _updateIdPreview();
    }
  }

  // ===== Login / Sign up =====
  bool _looksUnverified(AuthApiException e) {
    final msg = (e.message ?? '').toLowerCase();
    return e.statusCode == 400 && msg.contains('belum terverifikasi');
  }

  Future<void> _resendVerification(String email) async {
    try {
      await supabase.auth.resend(type: OtpType.signup, email: email);
      _toast('Terkirim', 'Email verifikasi sudah dikirim ke $email.', success: true);
    } catch (_) {
      _toast('Gagal', 'Tidak bisa mengirim ulang email verifikasi.');
    }
  }

  Future<void> _showUnverifiedDialog(String email) async {
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Perlu Verifikasi'),
        content: Text('Akun belum diverifikasi. Cek email $email untuk verifikasi.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _resendVerification(email);
            },
            child: const Text('Kirim Ulang'),
          ),
        ],
      ),
    );
  }

  void _toast(String title, String message, {bool success = false}) {
    PopNotifier.I.show(
      context,
      title: title,
      message: message,
      type: success ? NoticeType.success : NoticeType.error,
      duration: const Duration(seconds: 2),
    );
  }

  /// >>> arahkan langsung ke halaman ResetPasswordPage
  Future<void> _forgotPasswordNavigate() async {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ResetPasswordPage()),
    );
  }

  Future<void> _login() async {
    if (isLoadingLogin) return;
    final email = loginEmailController.text.trim();
    final password = loginPasswordController.text.trim();
    if (email.isEmpty || password.isEmpty) {
      _toast('Gagal', 'Email dan password wajib diisi.');
      return;
    }
    setState(() => isLoadingLogin = true);
    try {
      final response = await supabase.auth
          .signInWithPassword(email: email, password: password)
          .timeout(const Duration(seconds: 15));
      final user = response.user;
      if (user == null) {
        _toast('Gagal', 'Login gagal. Pengguna tidak ditemukan.');
        return;
      }
      final userData = await supabase
          .from('profiles')
          .select('nama, role, id_usaha')
          .eq('id', user.id)
          .maybeSingle()
          .timeout(const Duration(seconds: 15));
      if (userData == null) {
        _toast('Gagal', 'Data pengguna tidak ditemukan.');
        return;
      }
      final role = (userData['role'] ?? '').toString();
      final nama = (userData['nama'] ?? '').toString();
      final idUsaha = userData['id_usaha'];

      try {
        await LogService().addLog(
            aktivitas: "Login", halaman: "Auth", detail: "User $nama ($role) berhasil login");
      } catch (_) {}

      if (!mounted) return;
      if (role == 'admin_usaha') {
        if (idUsaha == null) {
          _toast('Gagal', 'ID usaha tidak ditemukan untuk admin_usaha.');
          return;
        }
        final usahaData =
        await supabase.from('usaha').select('nama_usaha').eq('id_usaha', idUsaha).maybeSingle();
        final namausaha = usahaData?['nama_usaha'] ?? 'Usaha';
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => Dashboardusaha(idUsaha: idUsaha, namausaha: namausaha)),
        );
      } else if (role == 'staff') {
        Navigator.pushReplacementNamed(
          context,
          '/dashboard_staff',
          arguments: {'showWelcome': true, 'welcomeText': 'Selamat datang, $nama!'},
        );
      } else if (role == 'admin_pusat') {
        Navigator.pushReplacementNamed(
          context,
          '/dashboard-admin',
          arguments: {'showWelcome': true, 'welcomeText': 'Selamat datang, $nama!'},
        );
      } else {
        _toast('Gagal', 'Role tidak dikenali.');
      }
    } on AuthApiException catch (e, st) {
      if (_looksUnverified(e)) {
        await _showUnverifiedDialog(loginEmailController.text.trim());
      }
      _toast('Gagal', e.message ?? 'Autentikasi gagal.');
      debugPrintStack(stackTrace: st);
    } on TimeoutException {
      _toast('Gagal', 'Koneksi lambat atau server tidak merespons.');
    } catch (e, st) {
      _toast('Gagal', 'Kesalahan: $e');
      debugPrintStack(stackTrace: st);
    } finally {
      if (mounted) setState(() => isLoadingLogin = false);
    }
  }

  Future<void> _signUp() async {
    if (isLoadingSign) return;
    final nama = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text;
    final role = selectedRole;
    String? usahaId;

    if (nama.isEmpty || email.isEmpty || password.isEmpty || role == null) {
      await showTopToast(context, 'Semua field wajib diisi', icon: Icons.info_rounded);
      return;
    }

    // Validasi khusus role
    if (role == 'admin_usaha') {
      if (namausahaController.text.trim().isEmpty || lokasiusahaController.text.trim().isEmpty) {
        await showTopToast(context, 'Nama usaha & lokasi wajib diisi untuk Admin',
            icon: Icons.info_rounded);
        return;
      }
    } else if (role == 'admin_pusat') {
      if (adminKeyController.text.trim() != 'RAHASIA2025') {
        await showTopToast(context, 'Kode rahasia salah', icon: Icons.warning_amber_rounded);
        return;
      }
    }

    setState(() => isLoadingSign = true);
    try {
      if (role == 'admin_usaha') {
        usahaId = await generateusahaId();
        idUsahaController.text = usahaId;
        await supabase.from('usaha').insert({
          'id_usaha': usahaId,
          'nama_usaha': namausahaController.text.trim(),
          'lokasi': lokasiusahaController.text.trim(),
        });
      } else if (role == 'staff') {
        final id = idUsahaController.text.trim().toUpperCase();
        if (id.isEmpty) {
          await showTopToast(context, 'ID usaha wajib diisi', icon: Icons.info_rounded);
          setState(() => isLoadingSign = false);
          return;
        }
        final usaha =
        await supabase.from('usaha').select('id_usaha').eq('id_usaha', id).maybeSingle();
        if (usaha == null) {
          await showTopToast(context, 'ID usaha tidak ditemukan. Periksa lagi atau hubungi admin.',
              icon: Icons.warning_amber_rounded);
          setState(() => isLoadingSign = false);
          return;
        }
        usahaId = id;
      } else if (role == 'admin_pusat') {
        usahaId = ''; // tidak terikat ke usaha tertentu
      }

      await supabase.auth.signUp(
        email: email,
        password: password,
        emailRedirectTo: 'https://www.inmato.id/auth-callback/index.html',
        data: {
          'nama': nama,
          'role': role,
          'id_usaha': usahaId ?? '',
        },
      );

      await showTopToast(context, 'Berhasil mendaftar — silakan verifikasi lewat email anda',
          icon: Icons.check_circle_rounded);
      _goToLogin();

      // Bersihkan field setelah sukses
      nameController.clear();
      emailController.clear();
      passwordController.clear();
      confirmPasswordController.clear(); // ⬅️ penting
      namausahaController.clear();
      lokasiusahaController.clear();
      idUsahaController.clear();
      adminKeyController.clear();
    } catch (e) {
      await showTopToast(context, 'Gagal mendaftar: $e',
          icon: Icons.warning_amber_rounded, duration: const Duration(milliseconds: 6000));
    } finally {
      if (mounted) setState(() => isLoadingSign = false);
    }
  }

  void _goToSignUp() {
    setState(() => _isLogin = false);
  }

  void _goToLogin() {
    setState(() => _isLogin = true);
  }

  // ===== UI
  Widget _logoStrip() {
    const logos = <String>[
      'assets/IBIKKG.png',
      'assets/Kemendiktisaintek.png',
      'assets/OK_OCE.png',
      'assets/LOGOSR1.png',
    ];
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        double h;
        if (w < 380) {
          h = 42;
        } else if (w < 600) {
          h = 54;
        } else if (w < 1024) {
          h = 66;
        } else {
          h = 78;
        }
        return Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Wrap(
            spacing: 20,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [for (final p in logos) Image.asset(p, height: h)],
          ),
        );
      },
    );
  }

  Widget _authToggle(double width) {
    final maxW = 460.0;
    final w = width < maxW ? width - 48 : maxW;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Center(
        child: SizedBox(
          width: w,
          height: 44,
          child: Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: _goToLogin,
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: _isLogin ? _kMaroon : _kPillInactive,
                      borderRadius: BorderRadius.circular(22),
                      border: _isLogin ? null : Border.all(color: _kBorder),
                      boxShadow: _isLogin
                          ? [
                        BoxShadow(
                            color: Colors.black.withOpacity(.1),
                            blurRadius: 6,
                            offset: const Offset(0, 3))
                      ]
                          : null,
                    ),
                    alignment: Alignment.center,
                    child: Text('LOGIN',
                        style: TextStyle(
                            color: _isLogin ? Colors.white : const Color(0xFF8E8E8E),
                            fontWeight: FontWeight.w800)),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: GestureDetector(
                  onTap: _goToSignUp,
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: !_isLogin ? _kMaroon : _kPillInactive,
                      borderRadius: BorderRadius.circular(22),
                      border: !_isLogin ? null : Border.all(color: _kBorder),
                      boxShadow: !_isLogin
                          ? [
                        BoxShadow(
                            color: Colors.black.withOpacity(.1),
                            blurRadius: 6,
                            offset: const Offset(0, 3))
                      ]
                          : null,
                    ),
                    alignment: Alignment.center,
                    child: Text('REGISTER',
                        style: TextStyle(
                            color: !_isLogin ? Colors.white : const Color(0xFF8E8E8E),
                            fontWeight: FontWeight.w800)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _loginCard(BuildContext cxt) {
    return LayoutBuilder(
      builder: (context, c) {
        final double maxCardWidth = c.maxWidth <= 600 ? c.maxWidth : 520;
        bool _obscure = true;

        return Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxCardWidth),
            child: Card(
              color: Colors.white.withOpacity(0.96),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                child: StatefulBuilder(
                  builder: (context, setSB) {
                    final btnWidth = maxCardWidth * 0.9;
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(height: 6),
                        Text("Masuk Akun",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: c.maxWidth < 360 ? 18 : 20,
                                fontWeight: FontWeight.w800,
                                color: Colors.black87)),
                        const SizedBox(height: 14),
                        TextField(
                          controller: loginEmailController,
                          keyboardType: TextInputType.emailAddress,
                          autofillHints: const [AutofillHints.username, AutofillHints.email],
                          decoration: _dec('Email'),
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: loginPasswordController,
                          obscureText: _obscure,
                          autofillHints: const [AutofillHints.password],
                          decoration: _dec('Password').copyWith(
                            suffixIcon: IconButton(
                              onPressed: () => setSB(() => _obscure = !_obscure),
                              icon: Icon(
                                _obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded,
                                color: Colors.black54,
                              ),
                            ),
                          ),
                          onSubmitted: (_) => !isLoadingLogin ? _login() : null,
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: _forgotPasswordNavigate,
                            style: TextButton.styleFrom(foregroundColor: _kMaroon),
                            child: const Text('Lupa password?'),
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: btnWidth,
                          child: ElevatedButton(
                            onPressed: isLoadingLogin ? null : _login,
                            style: _btnPrimary(),
                            child: isLoadingLogin
                                ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                : const Text('Login'),
                          ),
                        ),
                        const SizedBox(height: 6),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _roleSpecificFields() {
    if (selectedRole == 'admin_usaha') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: idUsahaController,
            readOnly: true,
            enableInteractiveSelection: true,
            decoration: const InputDecoration(
              labelText: 'ID Usaha (otomatis)',
              helperText: 'Isi Nama Usaha & Lokasi — ID akan tergenerate otomatis, tidak perlu diisi.',
            ),
          ),
          const SizedBox(height: 10),
          TextField(controller: namausahaController, decoration: _dec('Nama Usaha')),
          const SizedBox(height: 10),
          TextField(controller: lokasiusahaController, decoration: _dec('Lokasi')),
          const SizedBox(height: 10),
        ],
      );
    }

    if (selectedRole == 'staff') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: idUsahaController,
            inputFormatters: [UsahaIdFormatter()],
            decoration: const InputDecoration(
              labelText: 'ID Usaha',
              helperText: 'Minta ID dari admin usaha tempat Anda bekerja',
            ),
          ),
          const SizedBox(height: 10),
        ],
      );
    }

    // if (selectedRole == 'admin_pusat') { ... }

    return const SizedBox.shrink();
  }

  Widget _signUpCard(BuildContext cxt) {
    return LayoutBuilder(
      builder: (context, c) {
        final double maxCardWidth = c.maxWidth <= 600 ? c.maxWidth : 520;

        return Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxCardWidth),
            child: Card(
              color: Colors.white.withOpacity(0.96),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                child: StatefulBuilder(builder: (context, setSB) {
                  final btnWidth = maxCardWidth * 0.9;
                  return ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 520),
                    child: Scrollbar(
                      thumbVisibility: true,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const SizedBox(height: 6),
                            Text("Daftar Akun",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: c.maxWidth < 360 ? 18 : 20,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.black87)),
                            const SizedBox(height: 14),
                            TextField(
                                controller: nameController,
                                textInputAction: TextInputAction.next,
                                decoration: _dec('Nama')),
                            const SizedBox(height: 10),
                            TextField(
                                controller: emailController,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.next,
                                decoration: _dec('Email')),
                            const SizedBox(height: 10),
                            TextField(
                              controller: passwordController,
                              obscureText: _signupObscure,
                              decoration: _dec('Password').copyWith(
                                suffixIcon: IconButton(
                                  onPressed: () => setState(() => _signupObscure = !_signupObscure),
                                  icon: Icon(
                                      _signupObscure
                                          ? Icons.visibility_rounded
                                          : Icons.visibility_off_rounded,
                                      color: Colors.black54),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: confirmPasswordController,
                              obscureText: _signupObscureConfirm,
                              decoration: _dec('Confirm Password').copyWith(
                                suffixIcon: IconButton(
                                  onPressed: () =>
                                      setState(() => _signupObscureConfirm = !_signupObscureConfirm),
                                  icon: Icon(
                                      _signupObscureConfirm
                                          ? Icons.visibility_rounded
                                          : Icons.visibility_off_rounded,
                                      color: Colors.black54),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            DropdownButtonFormField<String>(
                              decoration: _dec('Role'),
                              value: selectedRole,
                              items: const [
                                // DropdownMenuItem(value: 'admin_pusat', child: Text('Admin Pusat')),
                                DropdownMenuItem(value: 'admin_usaha', child: Text('Admin Usaha')),
                                DropdownMenuItem(value: 'staff', child: Text('Karyawan')),
                              ],
                              onChanged: (v) async {
                                setState(() {
                                  selectedRole = v;
                                  // kosongkan field saat ganti role (hanya yang perlu)
                                  namausahaController.clear();
                                  lokasiusahaController.clear();
                                  idUsahaController.clear();
                                  adminKeyController.clear();
                                  // NOTE: tidak menghapus confirm/password supaya tetap persist
                                });
                                if (v == 'admin_usaha') {
                                  _updateIdPreview();
                                  _scheduleGenerateId();
                                }
                              },
                            ),
                            const SizedBox(height: 10),

                            // Preview ID Usaha: tampil hanya untuk Admin Usaha
                            if (selectedRole == 'admin_usaha') ...[
                              TextField(
                                controller: idPreviewController,
                                readOnly: true,
                                decoration: _dec('Preview ID Usaha'),
                              ),
                              const SizedBox(height: 10),
                            ],

                            _roleSpecificFields(),

                            const SizedBox(height: 8),
                            SizedBox(
                              width: btnWidth,
                              child: ElevatedButton(
                                onPressed: isLoadingSign
                                    ? null
                                    : () async {
                                  if (passwordController.text !=
                                      confirmPasswordController.text) {
                                    await showTopToast(context, 'Password konfirmasi tidak sama',
                                        icon: Icons.warning_amber_rounded);
                                    return;
                                  }
                                  await _signUp();
                                },
                                style: _btnPrimary(),
                                child: isLoadingSign
                                    ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2, color: Colors.white))
                                    : const Text('Daftar'),
                              ),
                            ),
                            const SizedBox(height: 6),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent),
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.25,
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _logoStrip(),
                    _authToggle(MediaQuery.of(context).size.width),
                    const SizedBox(height: 10),
                    // Tinggi container luar tetap stabil; isi register bisa scroll sendiri
                    SizedBox(
                      height: 560,
                      child: IndexedStack(
                        index: _isLogin ? 0 : 1,
                        children: [_loginCard(context), _signUpCard(context)],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
