import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/widget/app_background.dart';

class lupaPWPage extends StatefulWidget {
  const lupaPWPage({super.key});

  @override
  State<lupaPWPage> createState() => _lupaPWPageState();
}

class _lupaPWPageState extends State<lupaPWPage> {
  final supabase = Supabase.instance.client;

  final emailController = TextEditingController();
  bool isSending = false;

  // untuk mencegah dialog muncul dua kali
  bool _dialogShown = false;

  StreamSubscription<AuthState>? _sub;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
  }

  @override
  void initState() {
    super.initState();
    _handleRecoveryOnWeb(); // coba pulihkan sesi dari URL (?code=... / #access_token)

    // Fallback: jika SDK memicu event passwordRecovery
    _sub = supabase.auth.onAuthStateChange.listen((data) {
      if (!mounted) return;
      if (data.event == AuthChangeEvent.passwordRecovery && !_dialogShown) {
        _dialogShown = true;
        _showCreateNewPasswordDialog();
      }
    });
  }

  // WEB ONLY: pulihkan sesi dari URL lalu munculkan dialog ubah password
  Future<void> _handleRecoveryOnWeb() async {
    if (!kIsWeb) return;
    try {
      final res = await supabase.auth.getSessionFromUrl(Uri.base);
      if (!mounted) return;
      if (res.session != null && !_dialogShown) {
        _dialogShown = true;
        _showCreateNewPasswordDialog();
      }
    } on AuthApiException catch (e) {
      _toast(context, 'Gagal memproses tautan reset\n[${e.statusCode}] ${e.message}');
    } catch (_) {
      _toast(context, 'Gagal memproses tautan reset');
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    emailController.dispose();
    super.dispose();
  }

  void _toast(BuildContext context, String text, {bool success = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: success ? Colors.green.shade700 : Colors.black87,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // Kirim link reset (redirect port mengikuti origin aktif)
  Future<void> _sendResetLink() async {
    final email = emailController.text.trim();
    if (email.isEmpty) {
      _toast(context, 'Email wajib diisi');
      return;
    }

    setState(() => isSending = true);
    try {
      final redirect = kIsWeb ? '${Uri.base.origin}/#/lupa-password' : 'inmato://reset';
      await supabase.auth.resetPasswordForEmail(email, redirectTo: redirect);
      _toast(context, 'Link reset dikirim. Cek email kamu.', success: true);
    } on AuthApiException catch (e) {
      _toast(context, 'Gagal kirim link reset\n[${e.statusCode}] ${e.message}');
    } finally {
      if (mounted) setState(() => isSending = false);
    }
  }

  // Dialog ubah password
  Future<void> _showCreateNewPasswordDialog() async {
    final c1 = TextEditingController();
    final c2 = TextEditingController();
    bool saving = false;

    if (!mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSB) => AlertDialog(
          title: const Text('Buat Password Baru'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: c1,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Password baru'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: c2,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Ulangi password'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: saving ? null : () => Navigator.pop(ctx),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: saving
                  ? null
                  : () async {
                final p1 = c1.text.trim();
                final p2 = c2.text.trim();
                if (p1.isEmpty || p2.isEmpty) {
                  _toast(context, 'Password tidak boleh kosong');
                  return;
                }
                if (p1 != p2) {
                  _toast(context, 'Password tidak sama');
                  return;
                }

                setSB(() => saving = true);
                try {
                  await supabase.auth.updateUser(UserAttributes(password: p1));
                  if (mounted) {
                    Navigator.pop(ctx);
                    _toast(context, 'Password berhasil diubah', success: true);
                  }
                } on AuthApiException catch (e) {
                  _toast(context, e.message);
                } catch (_) {
                  _toast(context, 'Terjadi kesalahan');
                } finally {
                  setSB(() => saving = false);
                }
              },
              child: saving
                  ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
                  : const Text('Simpan'),
            ),
          ],
        ),
      ),
    );

    c1.dispose();
    c2.dispose();
  }

  // ================= UI =================

  Widget _logoStrip() {
    const logos = <String>[
      'assets/IBIKKG.png',
      'assets/OK_OCE.png',
      'assets/Kemendiktisaintek.png',
      'assets/Simpang_Raya.png',
    ];
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        double h;
        if (w < 380) {
          h = 36;
        } else if (w < 600) {
          h = 48;
        } else if (w < 1024) {
          h = 60;
        } else {
          h = 72;
        }
        return Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Wrap(
            spacing: 20,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              for (final path in logos)
                Image.asset(path, height: h, fit: BoxFit.contain, filterQuality: FilterQuality.medium),
            ],
          ),
        );
      },
    );
  }

  Widget _resetCard() {
    return LayoutBuilder(
      builder: (context, c) {
        final double maxCardWidth = c.maxWidth <= 600 ? c.maxWidth : 520;
        return Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxCardWidth),
            child: Card(
              color: Colors.white.withOpacity(0.96),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        'Lupa Password',
                        style: TextStyle(
                          fontSize: c.maxWidth < 360 ? 20 : 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.username, AutofillHints.email],
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => isSending ? null : _sendResetLink(),
                      decoration: const InputDecoration(labelText: 'Email'),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: isSending ? null : _sendResetLink,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.indigo,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: isSending
                            ? const SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                            : const Text('Kirim Link Reset', style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Align(
                      alignment: Alignment.center,
                      child: TextButton(
                        onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                        child: const Text('Kembali ke login'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark,
        child: AppBackground(
          overlayLight: true,
          overlayOpacity: 0.22,
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _logoStrip(),
                    _resetCard(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
