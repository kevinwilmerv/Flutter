import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

// ====== komponen/proyek kamu ======
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/widget/save_button.dart';
import 'package:ok_oce/widget/usaha_drawer.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/pages/laporan_transaksi_page.dart';

class ThousandSeparatorInputFormatter extends TextInputFormatter {
  final NumberFormat _nf = NumberFormat.decimalPattern('id_ID');
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) {
      return const TextEditingValue(
        text: '',
        selection: TextSelection.collapsed(offset: 0),
      );
    }
    final formatted = _nf.format(int.parse(digits));
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}

class InputTransaksiPage extends StatefulWidget {
  final String usahaId;
  const InputTransaksiPage({Key? key, required this.usahaId}) : super(key: key);

  @override
  State<InputTransaksiPage> createState() => _InputTransaksiPageState();
}

class _InputTransaksiPageState extends State<InputTransaksiPage> {
  final SupabaseClient supabase = Supabase.instance.client;
  final logService = LogService();

  final TextEditingController _jenisBaruController = TextEditingController();
  final TextEditingController _jenisBebanUsahaBaruController =
  TextEditingController();
  final manualLabelController = TextEditingController();

  // key = "Penjualan #1" / "Beban Usaha #1"
  final Map<String, TextEditingController> _controllerMap = {};
  final Map<String, TextEditingController> _bebanUsahaControllerMap = {};
  final Map<String, TextEditingController> namaLainnyaControllerMap = {};
  final Map<String, String> manualBebanUsahaLabel = {};
  final Map<String, String> manualPenjualanLabel = {};
  final Map<String, String> selectedKategoriPenjualan = {};
  final Map<String, String?> selectedSubkategoriPenjualan = {};
  final Map<String, String> selectedKategoriBebanUsaha = {};

  final currencyFormat =
  NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  DateTime get _todayDate {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  DateTime _selectedDate = DateTime.now();

  // Rekap tersimpan (server) untuk tanggal aktif
  List<Map<String, dynamic>> _savedRows = [];
  int _savedTotalPenjualan = 0;
  int _savedTotalBeban = 0;

  int get _totalPenjualan => _controllerMap.values
      .map((e) => int.tryParse(e.text.replaceAll('.', '')) ?? 0)
      .fold(0, (a, b) => a + b);

  int get _totalBebanUsaha => _bebanUsahaControllerMap.values
      .map((e) => int.tryParse(e.text.replaceAll('.', '')) ?? 0)
      .fold(0, (a, b) => a + b);

  int get _labaBersih => _totalPenjualan - _totalBebanUsaha;

  // ====== Kategori ======
  final Map<String, List<String>> kategoriPenjualan = const {
    'Cash': [],
    'Debit': [],
    'Kredit': [],
    'E-Wallet': ['Gopay', 'OVO', 'ShopeePay', 'Lainnya'],
    'Pesanan Online': ['GoFood', 'GrabFood', 'ShopeeFood', 'Lainnya'],
  };

  final List<String> kategoriBebanUsaha = const [
    'Pajak Pengahsilan UMKM',
    'Makan Siang Karyawan',
    'Iuran Sampah & Honorer',
    'Bensin dan Servis Kendaraan',
    'Listrik, Telepon & PAM',
    'Lainnya',
  ];

  // ===== Unsaved-changes guard =====
  final _dirty = ValueNotifier<bool>(false);
  bool get _isDirty => _dirty.value;
  bool _dirtyToastShown = false;

  void _markDirty() {
    if (!_dirty.value) {
      _dirty.value = true;
    }
  }

  void _markClean() {
    if (_dirty.value) _dirty.value = false;
    _dirtyToastShown = false;
  }

  bool _hasMeaningfulDraft() {
    bool anyPenjualan = _controllerMap.values.any((c) {
      final n = int.tryParse(c.text.replaceAll('.', '')) ?? 0;
      return n > 0; // cuma dianggap bermakna kalau > 0
    });
    bool anyBeban = _bebanUsahaControllerMap.values.any((c) {
      final n = int.tryParse(c.text.replaceAll('.', '')) ?? 0;
      return n > 0;
    });
    bool anyManual = manualPenjualanLabel.values.any((s) => s.trim().isNotEmpty) ||
        manualBebanUsahaLabel.values.any((s) => s.trim().isNotEmpty);
    return anyPenjualan || anyBeban || anyManual;
  }

  // key gabungan utk grouping
  String _keyOf(String jenis, String kategori, String? sub, String? custom) {
    final safeSub = sub ?? '';
    final safeCustom = (custom ?? '').trim();
    return '$jenis|$kategori|$safeSub|$safeCustom';
  }

// ambil total existing per key utk tanggal aktif
  Future<Map<String, int>> _fetchExistingTotals() async {
    final tanggal = DateFormat('yyyy-MM-dd').format(_selectedDate);
    final rows = await supabase
        .from('transaksi_harian')
        .select('jenis_transaksi,kategori,sub_kategori,custom_label,jumlah')
        .eq('id_usaha', widget.usahaId)
        .eq('tanggal', tanggal);

    final m = <String, int>{};
    for (final r in rows) {
      final k = _keyOf(
        (r['jenis_transaksi'] ?? '').toString(),
        (r['kategori'] ?? '').toString(),
        r['sub_kategori'] as String?,
        r['custom_label'] as String?,
      );
      m[k] = (m[k] ?? 0) + ((r['jumlah'] as int?) ?? 0); // ← SUM, bukan replace
    }
    return m;
  }

// kelompokkan input form -> delta per key + meta utk upsert
  List<Map<String, dynamic>> _buildGroupedDelta() {
    final tanggal = DateFormat('yyyy-MM-dd').format(_selectedDate);
    final uid = supabase.auth.currentUser?.id;

    final acc = <String, int>{};
    final meta = <String, Map<String, dynamic>>{};

    // Penjualan (+)
    for (final e in _controllerMap.entries) {
      final label = e.key;
      final nilai = int.tryParse(e.value.text.replaceAll('.', '')) ?? 0;
      if (nilai <= 0) continue;

      final kategori = selectedKategoriPenjualan[label] ?? 'Tidak diketahui';
      final sub = selectedSubkategoriPenjualan[label];
      final isLainnya = sub == 'Lainnya';
      final custom = isLainnya ? (manualPenjualanLabel[label]?.trim() ?? '') : null;

      final k = _keyOf('penjualan', kategori, isLainnya ? null : sub, custom);
      acc[k] = (acc[k] ?? 0) + nilai;
      meta[k] = {
        'id_usaha': widget.usahaId,
        'tanggal': tanggal,
        'jenis_transaksi': 'penjualan',
        'kategori': kategori,
        'sub_kategori': isLainnya ? null : sub,          // <-- null jika tidak ada
        'custom_label': (custom?.isEmpty ?? true) ? null : custom,  // <-- null jika kosong
        'created_by': uid,
      };
    }

    // Beban Usaha (disimpan negatif)
    for (final e in _bebanUsahaControllerMap.entries) {
      final label = e.key;
      final nilai = int.tryParse(e.value.text.replaceAll('.', '')) ?? 0;
      if (nilai <= 0) continue;

      final kategori = selectedKategoriBebanUsaha[label] ?? 'Tidak diketahui';
      final isLainnya = kategori == 'Lainnya';
      final custom = isLainnya ? (manualBebanUsahaLabel[label]?.trim() ?? '') : null;

      final k = _keyOf('beban_usaha', kategori, null, custom);
      acc[k] = (acc[k] ?? 0) - nilai; // negatif
      meta[k] = {
        'id_usaha': widget.usahaId,
        'tanggal': tanggal,
        'jenis_transaksi': 'beban_usaha',
        'kategori': kategori,
        'sub_kategori': null,
        'custom_label': (custom?.isEmpty ?? true) ? null : custom,
        'created_by': uid,
      };
    }

    final nowIso = DateTime.now().toIso8601String();
    return acc.entries.map((e) {
      final base = meta[e.key]!;
      return {
        'id': const Uuid().v4(),
        ...base,
        'jumlah': e.value, // masih delta (akan dijumlahkan dg existing)
        'created_at': nowIso,
      };
    }).toList();
  }

  Future<_DiscardAction> _confirmDiscardDialog() async {
    return await showDialog<_DiscardAction>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Perubahan belum disimpan'),
        content: const Text(
            'Kamu sudah mengubah data tapi belum menekan Simpan. Mau gimana?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardAction.cancel),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardAction.discard),
            child: const Text('Tinggalkan'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, _DiscardAction.save),
            icon: const Icon(Icons.save),
            label: const Text('Simpan sekarang'),
          ),
        ],
      ),
    ) ??
        _DiscardAction.cancel;
  }

  Future<void> _deleteExistingRowsForKey({
    required String idUsaha,
    required String tanggal,
    required String jenis,
    required String kategori,
    String? subKategori,      // null = IS NULL
    String? customLabel,      // null = IS NULL
  }) async {
    final tbl = supabase.from('transaksi_harian');

    // 1) Hapus varian NULL
    var qNull = tbl.delete().match({
      'id_usaha': idUsaha,
      'tanggal': tanggal,
      'jenis_transaksi': jenis,
      'kategori': kategori,
    });
    qNull = (subKategori == null)
        ? qNull.filter('sub_kategori', 'is', null)
        : qNull.eq('sub_kategori', subKategori);
    qNull = (customLabel == null)
        ? qNull.filter('custom_label', 'is', null)
        : qNull.eq('custom_label', customLabel);
    await qNull;

    // 2) Hapus juga varian string kosong '' (jika pernah tersimpan begitu)
    await tbl.delete().match({
      'id_usaha': idUsaha,
      'tanggal': tanggal,
      'jenis_transaksi': jenis,
      'kategori': kategori,
      'sub_kategori': subKategori ?? '',
      'custom_label': customLabel ?? '',
    });
  }

  Future<bool> _confirmLeaveIfDirty() async {
    if (!_isDirty) return true;

    // ⇩⇩ kalau cuma nambah baris tapi semua nominal kosong/0 & tak ada label manual
    if (!_hasMeaningfulDraft()) {
      _markClean();
      return true; // langsung boleh pergi, tanpa dialog
    }

    final action = await _confirmDiscardDialog();
    if (action == _DiscardAction.save) {
      await _saveToPrefs();
      await _simpanKeSupabase();
      return true;
    } else if (action == _DiscardAction.discard) {
      return true;
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
    _loadFromPrefs();
    _fetchSavedForDate();
  }

  @override
  void dispose() {
    for (var c in _controllerMap.values) c.dispose();
    for (var c in _bebanUsahaControllerMap.values) c.dispose();
    for (var c in namaLainnyaControllerMap.values) c.dispose();
    _jenisBaruController.dispose();
    _jenisBebanUsahaBaruController.dispose();
    manualLabelController.dispose();
    _dirty.dispose();
    super.dispose();
  }

  // ================== Local draft ==================
  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final key = _generatePrefsKey();
    final jsonString = prefs.getString(key);

    setState(() {
      _controllerMap.clear();
      _bebanUsahaControllerMap.clear();
      namaLainnyaControllerMap.clear();
      selectedKategoriPenjualan.clear();
      selectedSubkategoriPenjualan.clear();
      selectedKategoriBebanUsaha.clear();
      manualBebanUsahaLabel.clear();
      manualPenjualanLabel.clear();
    });

    if (jsonString == null) {
      _markClean();
      return;
    }

    try {
      final decoded = json.decode(jsonString);

      // ====== MODE BARU ======
      if (decoded is Map &&
          (decoded.containsKey('penjualan') || decoded.containsKey('beban'))) {
        // PENJUALAN
        final Map<String, dynamic> pj =
        Map<String, dynamic>.from(decoded['penjualan'] ?? {});
        final Map<String, dynamic> katPj =
        Map<String, dynamic>.from(decoded['kat_penjualan'] ?? {});
        final Map<String, dynamic> subPj =
        Map<String, dynamic>.from(decoded['subkat_penjualan'] ?? {});
        final Map<String, dynamic> manualPj =
        Map<String, dynamic>.from(decoded['manual_penjualan'] ?? {});

        pj.forEach((jenis, nilai) {
          final c = TextEditingController(text: (nilai ?? '').toString())
            ..addListener(() {
              setState(() {});
              _markDirty();
            });
          _controllerMap[jenis] = c;

          final kat = (katPj[jenis]?.toString().isNotEmpty ?? false)
              ? katPj[jenis].toString()
              : kategoriPenjualan.keys.first;
          selectedKategoriPenjualan[jenis] = kat;

          final sub = subPj[jenis];
          selectedSubkategoriPenjualan[jenis] =
          (sub == null || sub.toString().isEmpty) ? null : sub.toString();

          if (manualPj[jenis]?.toString().isNotEmpty ?? false) {
            manualPenjualanLabel[jenis] = manualPj[jenis].toString();
          }

          namaLainnyaControllerMap[jenis] =
          TextEditingController()..addListener(_markDirty);
        });
        _reindexPenjualan();

        // BEBAN USAHA
        final Map<String, dynamic> bu =
        Map<String, dynamic>.from(decoded['beban'] ?? {});
        final Map<String, dynamic> katBu =
        Map<String, dynamic>.from(decoded['kat_beban'] ?? {});
        final Map<String, dynamic> manualBu =
        Map<String, dynamic>.from(decoded['manual_beban'] ?? {});

        bu.forEach((jenis, nilai) {
          final c = TextEditingController(text: (nilai ?? '').toString())
            ..addListener(() {
              setState(() {});
              _markDirty();
            });
          _bebanUsahaControllerMap[jenis] = c;

          final k = (katBu[jenis]?.toString().isNotEmpty ?? false)
              ? katBu[jenis].toString()
              : kategoriBebanUsaha.first;
          selectedKategoriBebanUsaha[jenis] = k;

          if (manualBu[jenis]?.toString().isNotEmpty ?? false) {
            manualBebanUsahaLabel[jenis] = manualBu[jenis].toString();
          }
        });
        _reindexBebanUsaha();
        setState(() {});
        _markClean(); // draft yang diload dianggap bersih
        return;
      }

      // ====== MODE LAMA (kompatibel) ======
      if (decoded is Map<String, dynamic>) {
        decoded.forEach((jenis, jumlah) {
          final c = TextEditingController(text: (jumlah ?? '').toString())
            ..addListener(() {
              setState(() {});
              _markDirty();
            });
          _controllerMap[jenis] = c;
          selectedKategoriPenjualan[jenis] = kategoriPenjualan.keys.first;
          selectedSubkategoriPenjualan[jenis] = null;
          namaLainnyaControllerMap[jenis] =
          TextEditingController()..addListener(_markDirty);
        });
        _reindexPenjualan();
        setState(() {});
      }
      _markClean();
    } catch (_) {
      // abaikan jika corrupt
      _markClean();
    }
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();

    final data = {
      'penjualan':
      _controllerMap.map((key, ctl) => MapEntry(key, ctl.text)), // amount
      'beban': _bebanUsahaControllerMap
          .map((key, ctl) => MapEntry(key, ctl.text)), // amount
      'kat_beban': selectedKategoriBebanUsaha,
      'manual_beban': manualBebanUsahaLabel,
      // penting: simpan pilihan kategori penjualan
      'kat_penjualan': selectedKategoriPenjualan,
      'subkat_penjualan': selectedSubkategoriPenjualan,
      'manual_penjualan': manualPenjualanLabel,
    };

    await prefs.setString(_generatePrefsKey(), json.encode(data));
  }

  String _generatePrefsKey() {
    final formattedDate = DateFormat('yyyy-MM-dd').format(_selectedDate);
    return 'transaksi_${widget.usahaId}_$formattedDate';
  }

  // ================== Server: fetch & save ==================
  Future<void> _fetchSavedForDate() async {
    try {
      final tanggal = DateFormat('yyyy-MM-dd').format(_selectedDate);

      final rows = await supabase
          .from('transaksi_harian')
          .select('jenis_transaksi,jumlah,kategori,sub_kategori,custom_label')
          .eq('id_usaha', widget.usahaId)
          .eq('tanggal', tanggal);

      // helper kunci gabungan utk grouping
      String keyOf(String jenis, String kategori, String? sub, String? custom) =>
          '${jenis}|${kategori}|${sub ?? ''}|${(custom ?? '').trim()}';

      // group & akumulasi
      final Map<String, Map<String, dynamic>> grouped = {};
      int totalPenjualan = 0;
      int totalBeban = 0;

      for (final r in rows) {
        final jenis = (r['jenis_transaksi'] ?? '').toString();
        final kategori = (r['kategori'] ?? '').toString();
        final sub = r['sub_kategori'] as String?;
        final custom = r['custom_label'] as String?;
        final jumlah = (r['jumlah'] as int?) ?? 0;

        final k = keyOf(jenis, kategori, sub, custom);

        if (!grouped.containsKey(k)) {
          grouped[k] = {
            'jenis_transaksi': jenis,
            'kategori': kategori,
            'sub_kategori': sub,
            'custom_label': (custom ?? ''),
            'jumlah': 0,
          };
        }
        grouped[k]!['jumlah'] = (grouped[k]!['jumlah'] as int) + jumlah;

        if (jenis == 'penjualan') {
          totalPenjualan += jumlah;        // penjualan disimpan positif
        } else {
          totalBeban += jumlah.abs();      // beban disimpan negatif
        }
      }

      // opsional: urutkan agar penjualan tampil dulu lalu beban, dan per kategori
      final groupedList = grouped.values.toList()
        ..sort((a, b) {
          final jp = a['jenis_transaksi'] == 'penjualan' ? 0 : 1;
          final bp = b['jenis_transaksi'] == 'penjualan' ? 0 : 1;
          if (jp != bp) return jp.compareTo(bp);
          final ak = (a['kategori'] ?? '').toString().compareTo((b['kategori'] ?? '').toString());
          if (ak != 0) return ak;
          return ((a['sub_kategori'] ?? '') as String)
              .compareTo((b['sub_kategori'] ?? '') as String);
        });

      setState(() {
        _savedRows = groupedList;              // ← sekarang 1 baris per kategori
        _savedTotalPenjualan = totalPenjualan;
        _savedTotalBeban = totalBeban;
      });
    } catch (_) {
      // abaikan error fetch
    }
  }

  String _rowLabel(Map<String, dynamic> r) {
    final jenis = r['jenis_transaksi']?.toString() ?? '';
    final kat = r['kategori']?.toString() ?? '';
    final sub = (r['sub_kategori']?.toString() ?? '');
    final custom = (r['custom_label']?.toString() ?? '');

    final base = jenis == 'penjualan' ? 'Penjualan' : 'Beban';
    if (sub.isNotEmpty) return '$base • $kat';
    if (custom.isNotEmpty) return '$base • $kat';
    return '$base • $kat';
  }

  Future<void> _simpanKeSupabase() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      await showTopToast(context, 'Anda belum login', icon: Icons.info_rounded);
      return;
    }

    try {
      final deltaRows = _buildGroupedDelta();
      if (deltaRows.isEmpty) {
        await showTopToast(context, 'Tidak ada data untuk disimpan', icon: Icons.info_rounded);
        return;
      }

      // existing total (sudah menganggap null/'' sama karena _keyOf pakai '' utk null)
      final existing = await _fetchExistingTotals();

      final tanggal = DateFormat('yyyy-MM-dd').format(_selectedDate);
      final uid = user.id;
      final nowIso = DateTime.now().toIso8601String();

      final keys = <String, Map<String, dynamic>>{};
      final finalRows = <Map<String, dynamic>>[];

      for (final row in deltaRows) {
        final key = _keyOf(
          row['jenis_transaksi'] as String,
          row['kategori'] as String,
          row['sub_kategori'] as String?,
          (row['custom_label'] as String?)?.trim(),
        );

        final totalBaru = (existing[key] ?? 0) + (row['jumlah'] as int);

        // --- Normalisasi: simpan NULL ketika kosong ---
        String? sub = (row['sub_kategori'] as String?)?.trim();
        sub = (sub == null || sub.isEmpty) ? null : sub;

        String? custom = (row['custom_label'] as String?)?.trim();
        custom = (custom == null || custom.isEmpty) ? null : custom;

        final base = {
          'id_usaha': widget.usahaId,
          'tanggal': tanggal,
          'jenis_transaksi': row['jenis_transaksi'],
          'kategori': (row['kategori'] as String?) ?? '',
          'sub_kategori': sub,      // NULL kalau kosong
          'custom_label': custom,   // NULL kalau kosong
        };

        keys[key] = base;
        finalRows.add({
          'id': const Uuid().v4(),
          ...base,
          'jumlah': totalBaru,
          'created_at': nowIso,
          'created_by': uid,
        });
      }

      // --- Hapus baris lama untuk setiap key (tangani NULL dan '') ---
      for (final base in keys.values) {
        await _deleteByKey(
          idUsaha: base['id_usaha'] as String,
          tanggal: base['tanggal'] as String,
          jenis: base['jenis_transaksi'] as String,
          kategori: base['kategori'] as String,
          subKategori: base['sub_kategori'] as String?,   // bisa null
          customLabel: base['custom_label'] as String?,    // bisa null
        );
      }

      // Insert total akhir (1 baris per key)
      await supabase.from('transaksi_harian').insert(finalRows);

      await _saveToPrefs();
      await showTopToast(context, 'Data berhasil disimpan (terakumulasi)');
      await _fetchSavedForDate();

      setState(() {
        _controllerMap.clear();
        _bebanUsahaControllerMap.clear();
        selectedKategoriPenjualan.clear();
        selectedSubkategoriPenjualan.clear();
        selectedKategoriBebanUsaha.clear();
        manualPenjualanLabel.clear();
        manualBebanUsahaLabel.clear();
        namaLainnyaControllerMap.clear();
      });
      _markClean();
    } catch (e, st) {
      debugPrint('❌ Error saat simpan: $e\n$st');
      await showTopToast(
        context,
        'Gagal menyimpan data: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 2200),
      );
    }
  }

  /// Hapus baris lama utk key tertentu. Menghapus kedua varian: NULL dan ''.
  Future<void> _deleteByKey({
    required String idUsaha,
    required String tanggal,
    required String jenis,
    required String kategori,
    String? subKategori,
    String? customLabel,
  }) async {
    // 1️⃣ Hapus varian NULL menggunakan filter 'is'
    final filters = {
      'id_usaha': idUsaha,
      'tanggal': tanggal,
      'jenis_transaksi': jenis,
      'kategori': kategori,
    };

    // Supabase tidak bisa langsung .is_(...), jadi kita pakai filter string mentah:
    final baseTable = supabase.from('transaksi_harian');

    // Hapus subkategori NULL
    if (subKategori == null) {
      await baseTable.delete().match(filters).filter('sub_kategori', 'is', null).filter('custom_label', 'is', null);
    } else {
      await baseTable
          .delete()
          .match(filters)
          .eq('sub_kategori', subKategori)
          .filter('custom_label', 'is', null);
    }

    // Hapus custom_label kosong
    if (customLabel == null) {
      await baseTable.delete().match(filters).filter('custom_label', 'is', null);
    } else {
      await baseTable.delete().match(filters).eq('custom_label', customLabel);
    }

    // 2️⃣ Hapus juga varian lama ('') jika pernah tersimpan
    await baseTable
        .delete()
        .match({
      ...filters,
      'sub_kategori': subKategori ?? '',
      'custom_label': customLabel ?? '',
    });
  }

  // ==== Toast hitam kecil seragam (muncul di bagian atas) ====
  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle_rounded,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    if (!(context as Element).mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(duration, () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });
        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        offset: Offset(0, 4))
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        message,
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved = CurvedAnimation(
            parent: anim,
            curve: Curves.easeOutBack,
            reverseCurve: Curves.easeIn);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(
              scale: Tween<double>(begin: .92, end: 1).animate(curved),
              child: child),
        );
      },
    );
  }

  void _addPenjualanRow() {
    final label = 'Penjualan #${_controllerMap.length + 1}';
    final controller = TextEditingController()
      ..addListener(() {
        setState(() {});
        _markDirty(); // tetap dirty saat user mulai mengetik
      });
    setState(() {
      _controllerMap[label] = controller;
      selectedKategoriPenjualan[label] = kategoriPenjualan.keys.first;
      selectedSubkategoriPenjualan[label] = null;
      namaLainnyaControllerMap[label] = TextEditingController()..addListener(_markDirty);
    });
  }

  void _addBebanUsahaRow() {
    final label = 'Beban Usaha #${_bebanUsahaControllerMap.length + 1}';
    final controller = TextEditingController()
      ..addListener(() {
        setState(() {});
        _markDirty(); // baru dirty ketika ada input
      });
    setState(() {
      _bebanUsahaControllerMap[label] = controller;
      selectedKategoriBebanUsaha[label] = kategoriBebanUsaha.first;
    });
  }

  Widget _summaryPill(String title, int value, {IconData? icon}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.08)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.05),
              blurRadius: 12,
              offset: const Offset(0, 6))
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 18),
            const SizedBox(width: 8),
          ],
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(''),
              Text(title,
                  style: const TextStyle(fontSize: 12, color: Colors.black54)),
              Text(currencyFormat.format(value),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 14)),
            ],
          ),
        ],
      ),
    );
  }

  int _extractIndex(String label, String prefix) {
    final reg = RegExp('^' + RegExp.escape(prefix) + r' #(\d+)$');
    final m = reg.firstMatch(label);
    if (m != null) return int.tryParse(m.group(1)!) ?? 9999;
    return 9999;
  }

  void _reindexPenjualan() {
    final oldKeys = _controllerMap.keys.toList()
      ..sort((a, b) =>
          _extractIndex(a, 'Penjualan').compareTo(_extractIndex(b, 'Penjualan')));

    final newMap = <String, TextEditingController>{};
    final newKat = <String, String>{};
    final newSub = <String, String?>{};
    final newManual = <String, String>{};
    final newNamaCtl = <String, TextEditingController>{};

    for (int i = 0; i < oldKeys.length; i++) {
      final oldKey = oldKeys[i];
      final newKey = 'Penjualan #${i + 1}';

      newMap[newKey] = _controllerMap[oldKey]!;
      if (selectedKategoriPenjualan.containsKey(oldKey)) {
        newKat[newKey] = selectedKategoriPenjualan[oldKey]!;
      }
      if (selectedSubkategoriPenjualan.containsKey(oldKey)) {
        newSub[newKey] = selectedSubkategoriPenjualan[oldKey];
      }
      if (manualPenjualanLabel.containsKey(oldKey)) {
        newManual[newKey] = manualPenjualanLabel[oldKey]!;
      }
      if (namaLainnyaControllerMap.containsKey(oldKey)) {
        newNamaCtl[newKey] = namaLainnyaControllerMap[oldKey]!;
      }
    }

    _controllerMap
      ..clear()
      ..addAll(newMap);
    selectedKategoriPenjualan
      ..clear()
      ..addAll(newKat);
    selectedSubkategoriPenjualan
      ..clear()
      ..addAll(newSub);
    manualPenjualanLabel
      ..clear()
      ..addAll(newManual);
    namaLainnyaControllerMap
      ..clear()
      ..addAll(newNamaCtl);
  }

  void _reindexBebanUsaha() {
    final oldKeys = _bebanUsahaControllerMap.keys.toList()
      ..sort((a, b) => _extractIndex(a, 'Beban Usaha')
          .compareTo(_extractIndex(b, 'Beban Usaha')));

    final newMap = <String, TextEditingController>{};
    final newKat = <String, String>{};
    final newManual = <String, String>{};

    for (int i = 0; i < oldKeys.length; i++) {
      final oldKey = oldKeys[i];
      final newKey = 'Beban Usaha #${i + 1}';

      newMap[newKey] = _bebanUsahaControllerMap[oldKey]!;
      if (selectedKategoriBebanUsaha.containsKey(oldKey)) {
        newKat[newKey] = selectedKategoriBebanUsaha[oldKey]!;
      }
      if (manualBebanUsahaLabel.containsKey(oldKey)) {
        newManual[newKey] = manualBebanUsahaLabel[oldKey]!;
      }
    }

    _bebanUsahaControllerMap
      ..clear()
      ..addAll(newMap);
    selectedKategoriBebanUsaha
      ..clear()
      ..addAll(newKat);
    manualBebanUsahaLabel
      ..clear()
      ..addAll(newManual);
  }

  // ===== Navigasi ke laporan (tombol area kuning)
  Future<void> _goToLaporan() async {
    final ok = await _confirmLeaveIfDirty();
    if (!ok) return;
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LaporanTransaksiPage(
          idUsaha: widget.usahaId,
        ),
      ),
    );
  }

  // ================== BUILD ==================
  @override
  Widget build(BuildContext context) {
    final formattedDate =
    DateFormat('dd MMMM yyyy', 'id_ID').format(_selectedDate);

    // Paksa tema LIGHT + teks/ikon hitam
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(
            color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    final scaffold = Scaffold(
      drawer: usahaDrawer(
        idUsaha: widget.usahaId,
        active: 'trx',
        // ⬇️ kirim guard ke drawer
        onConfirmLeaveIfDirty: _confirmLeaveIfDirty,
      ),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text(
          'Input Penjualan & Beban Usaha',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: AppBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: ListView(
              padding: const EdgeInsets.only(bottom: 24),
              children: [
                // ===== Header & ringkasan =====
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.black.withOpacity(.08)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(.05),
                        blurRadius: 12,
                        offset: const Offset(0, 6),
                      )
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== Tanggal + Tombol Lihat Laporan (area kuning) =====
                      LayoutBuilder(
                        builder: (context, c) {
                          final narrow = c.maxWidth < 540;

                          final row = Row(
                            children: [
                              const Text('Tanggal',
                                  style:
                                  TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(width: 12),
                              InkWell(
                                borderRadius: BorderRadius.circular(999),
                                onTap: _pickDate,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFE4E9),
                                    borderRadius: BorderRadius.circular(999),
                                    border: Border.all(
                                        color: Colors.black, width: 1),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(Icons.calendar_today, size: 16),
                                      const SizedBox(width: 8),
                                      Text(
                                        formattedDate,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const Spacer(),
                              SizedBox(
                                height: 36,
                                child: OutlinedButton.icon(
                                  onPressed: _goToLaporan,
                                  icon: const Icon(Icons.receipt_long, size: 16),
                                  label: const Text('Lihat Laporan'),
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12),
                                    side: const BorderSide(
                                        color: Colors.black, width: 1),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(28)),
                                    foregroundColor: Colors.black,
                                    backgroundColor:
                                    const Color(0xFFFFE4E9),
                                  ),
                                ),
                              ),
                            ],
                          );

                          if (!narrow) return row;

                          // Sempit
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Text('Tanggal',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700)),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: InkWell(
                                      borderRadius: BorderRadius.circular(28),
                                      onTap: _pickDate,
                                      child: Container(
                                        height: 36,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFE4E9),
                                          borderRadius:
                                          BorderRadius.circular(28),
                                          border: Border.all(
                                              color: Colors.black, width: 1),
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                                Icons.calendar_today_rounded,
                                                size: 14),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                DateFormat('dd MMMM yyyy',
                                                    'id_ID')
                                                    .format(_selectedDate),
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    fontWeight:
                                                    FontWeight.w700),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              SizedBox(
                                height: 36,
                                child: OutlinedButton.icon(
                                  onPressed: _goToLaporan,
                                  icon: const Icon(Icons.receipt_long, size: 16),
                                  label: const Text('Lihat Laporan'),
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12),
                                    side: const BorderSide(
                                        color: Colors.black, width: 1),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(28)),
                                    foregroundColor: Colors.black,
                                    backgroundColor:
                                    const Color(0xFFFFE4E9),
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 12),

                      // Ringkasan draft (form)
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          _summaryPill('Penjualan', _totalPenjualan,
                              icon: Icons.trending_up_rounded),
                          _summaryPill('Beban Usaha', _totalBebanUsaha,
                              icon: Icons.trending_down_rounded),
                          _summaryPill('Laba Kotor', _labaBersih,
                              icon: Icons.account_balance_wallet_rounded),
                        ],
                      ),

                      const SizedBox(height: 12),

                      // Rekap tersimpan (server)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF7FA),
                          borderRadius: BorderRadius.circular(14),
                          border:
                          Border.all(color: Colors.black.withOpacity(.08)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('Rekap tersimpan',
                                    style:
                                    TextStyle(fontWeight: FontWeight.w800)),
                                const SizedBox(width: 6),
                                Text(
                                  DateFormat('dd MMMM yyyy', 'id_ID')
                                      .format(_selectedDate),
                                  style:
                                  const TextStyle(color: Colors.black54),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            if (_savedRows.isEmpty)
                              const Text(
                                'Belum ada data tersimpan untuk tanggal ini.',
                                style: TextStyle(color: Colors.black54),
                              )
                            else ...[
                              ..._savedRows.map((r) {
                                final lbl = _rowLabel(r);
                                final j = (r['jumlah'] as int?) ?? 0;
                                final isBeban =
                                    r['jenis_transaksi'] != 'penjualan';
                                final nilai = isBeban ? j.abs() : j;
                                return Padding(
                                  padding:
                                  const EdgeInsets.symmetric(vertical: 2),
                                  child: Row(
                                    children: [
                                      Icon(
                                          isBeban
                                              ? Icons.remove_circle_outline
                                              : Icons.add_circle_outline,
                                          size: 16),
                                      const SizedBox(width: 6),
                                      Expanded(child: Text(lbl)),
                                      Text(
                                        currencyFormat.format(nilai),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                              const Divider(height: 16),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Subtotal Penjualan'),
                                  Text(
                                    currencyFormat
                                        .format(_savedTotalPenjualan),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Subtotal Beban Usaha'),
                                  Text(
                                    currencyFormat.format(_savedTotalBeban),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Laba Kotor (tersimpan)'),
                                  Text(
                                    currencyFormat.format(
                                        _savedTotalPenjualan - _savedTotalBeban),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w800),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),

                      const SizedBox(height: 12),

                      // tombol simpan
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: LayoutBuilder(
                          builder: (context, c) {
                            final double w = c.maxWidth;
                            final double targetWidth =
                            (w <= 380) ? w : (w <= 560) ? w * 0.70 : 420;
                            return Align(
                              alignment: Alignment.centerLeft,
                              child: SizedBox(
                                width: targetWidth,
                                child: SaveButton(
                                  onPressed: () async {
                                    await _saveToPrefs();
                                    await _simpanKeSupabase();
                                  },
                                  label: 'Simpan',
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                // ===== Penjualan =====
                _Section(
                  title: 'Penjualan',
                  action: null,
                  child: Column(
                    children: [
                      for (var entry in _controllerMap.entries)
                        _entryCard(entry, isBebanUsaha: false),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          'Subtotal: ${currencyFormat.format(_totalPenjualan)}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: FilledButton.tonalIcon(
                          onPressed: _addPenjualanRow,
                          icon: const Icon(Icons.add),
                          label: const Text('Tambah'),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // ===== Beban Usaha =====
                _Section(
                  title: 'Beban Usaha',
                  action: null,
                  child: Column(
                    children: [
                      for (var entry in _bebanUsahaControllerMap.entries)
                        _entryCard(entry, isBebanUsaha: true),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          'Subtotal: ${currencyFormat.format(_totalBebanUsaha)}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: FilledButton.tonalIcon(
                          onPressed: _addBebanUsahaRow,
                          icon: const Icon(Icons.add),
                          label: const Text('Tambah'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    // Bungkus guard back
    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: ValueListenableBuilder<bool>(
          valueListenable: _dirty,
          builder: (context, isDirty, child) {
            return WillPopScope(
              onWillPop: () async => await _confirmLeaveIfDirty(),
              child: child!,
            );
          },
          child: scaffold,
        ),
      ),
    );
  }

  // ====== ENTRY CARD (baris input) ======
  Widget _entryCard(
      MapEntry<String, TextEditingController> entry, {
        required bool isBebanUsaha,
      }) {
    final jenis = entry.key;
    final controller = entry.value;

    final Color incomeBg = const Color(0xFF22C55E).withOpacity(0.10);
    final Color incomeLine = const Color(0xFF16A34A).withOpacity(0.28);
    final Color expenseBg = const Color(0xFFEF4444).withOpacity(0.08);
    final Color expenseLine = const Color(0xFFDC2626).withOpacity(0.26);

    final Color cardBg = isBebanUsaha ? expenseBg : incomeBg;
    final Color cardLine = isBebanUsaha ? expenseLine : incomeLine;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: cardLine),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.05),
              blurRadius: 10,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(jenis,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
                IconButton(
                  tooltip: 'Hapus baris',
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      if (isBebanUsaha) {
                        _bebanUsahaControllerMap.remove(jenis);
                        selectedKategoriBebanUsaha.remove(jenis);
                        manualBebanUsahaLabel.remove(jenis);
                        _reindexBebanUsaha();
                      } else {
                        _controllerMap.remove(jenis);
                        selectedKategoriPenjualan.remove(jenis);
                        selectedSubkategoriPenjualan.remove(jenis);
                        manualPenjualanLabel.remove(jenis);
                        namaLainnyaControllerMap.remove(jenis);
                        _reindexPenjualan();
                      }
                      _markDirty();
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Kategori
            if (!isBebanUsaha) ...[
              DropdownButtonFormField<String>(
                value: selectedKategoriPenjualan[jenis],
                items: kategoriPenjualan.keys
                    .map((kat) => DropdownMenuItem(
                  value: kat,
                  child: Text(kat,
                      style: const TextStyle(color: Colors.black87)),
                ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    selectedKategoriPenjualan[jenis] = value!;
                    selectedSubkategoriPenjualan[jenis] = null;
                    _markDirty();
                  });
                },
                decoration: _pillInput(label: 'Kategori Penjualan').copyWith(
                  hintStyle: const TextStyle(color: Colors.black54),
                ),
                style: const TextStyle(color: Colors.black87),
                dropdownColor: Colors.white,
                iconEnabledColor: Colors.black87,
              ),
              const SizedBox(height: 8),
              if ((kategoriPenjualan[selectedKategoriPenjualan[jenis]] ?? [])
                  .isNotEmpty)
                (selectedSubkategoriPenjualan[jenis] == 'Lainnya')
                    ? TextField(
                  decoration: _pillInput(label: 'Isi nama lainnya'),
                  onChanged: (val) => setState(() {
                    manualPenjualanLabel[jenis] = val;
                    _markDirty();
                  }),
                )
                    : DropdownButtonFormField<String>(
                  value: selectedSubkategoriPenjualan[jenis],
                  items:
                  kategoriPenjualan[selectedKategoriPenjualan[jenis]]!
                      .map((sub) => DropdownMenuItem(
                    value: sub,
                    child: Text(sub,
                        style: const TextStyle(
                            color: Colors.black87)),
                  ))
                      .toList(),
                  onChanged: (val) => setState(() {
                    selectedSubkategoriPenjualan[jenis] = val;
                    _markDirty();
                  }),
                  decoration:
                  _pillInput(label: 'Subkategori').copyWith(
                    hintStyle: const TextStyle(color: Colors.black54),
                  ),
                  style: const TextStyle(color: Colors.black87),
                  dropdownColor: Colors.white,
                  iconEnabledColor: Colors.black87,
                ),
            ] else ...[
              DropdownButtonFormField<String>(
                value: selectedKategoriBebanUsaha[jenis],
                items: kategoriBebanUsaha
                    .map((kat) => DropdownMenuItem(
                  value: kat,
                  child: Text(kat,
                      style: const TextStyle(color: Colors.black87)),
                ))
                    .toList(),
                onChanged: (val) => setState(() {
                  selectedKategoriBebanUsaha[jenis] = val!;
                  _markDirty();
                }),
                decoration:
                _pillInput(label: 'Kategori Beban Usaha').copyWith(
                  hintStyle: const TextStyle(color: Colors.black54),
                ),
                style: const TextStyle(color: Colors.black87),
                dropdownColor: Colors.white,
                iconEnabledColor: Colors.black87,
              ),
              if (selectedKategoriBebanUsaha[jenis] == 'Lainnya') ...[
                const SizedBox(height: 8),
                TextField(
                  decoration: _pillInput(label: 'Isi nama lainnya'),
                  onChanged: (val) => setState(() {
                    manualBebanUsahaLabel[jenis] = val;
                    _markDirty();
                  }),
                ),
              ],
            ],

            const SizedBox(height: 10),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                ThousandSeparatorInputFormatter(),
              ],
              decoration: _pillInput(
                hint: '0',
                label: 'Jumlah',
                prefixText: 'Rp',
              ),
              onChanged: (_) => setState(() {
                _markDirty();
              }),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _pillInput({String? hint, String? label, String? prefixText}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.black54),
      labelText: label,
      filled: true,
      fillColor: Colors.white,
      isDense: true,
      contentPadding:
      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(14)),
        borderSide: BorderSide(color: Colors.blue, width: 1.8),
      ),
      prefix: (prefixText == null)
          ? null
          : Padding(
        padding: const EdgeInsets.only(right: 6),
        child: Text(prefixText,
            style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
    );
  }

  // ===== Date Picker (tema pink) + guard =====
  Future<void> _pickDate() async {
    final today = _todayDate;

    final picked = await showDatePicker(
      context: context,
      // jangan biarkan initialDate melewati hari ini
      initialDate: (() {
        final base = _selectedDate;
        return base.isAfter(today) ? today : base;
      })(),
      firstDate: DateTime(2020),
      lastDate: today, // ⛔ maksimum = hari ini
      selectableDayPredicate: (d) => !d.isAfter(today), // disable tanggal > hari ini
      builder: (ctx, child) {
        final t = Theme.of(ctx);
        return Theme(
          data: t.copyWith(
            useMaterial3: false,
            datePickerTheme: DatePickerThemeData(
              backgroundColor: const Color(0xFFFFE4E9),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              dayStyle: const TextStyle(color: Colors.black87),
              headerForegroundColor: Colors.black87,
            ),
            dialogTheme: t.dialogTheme.copyWith(
              backgroundColor: const Color(0xFFFFE4E9),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked == null) return;

    final ok = await _confirmLeaveIfDirty();
    if (!ok) return;

    setState(() => _selectedDate = picked);
    await _loadFromPrefs();      // reload draft sesuai tanggal
    await _fetchSavedForDate();  // refresh rekap server
    _markClean();
  }
}

// ===== Unsaved changes enum (shared) =====
enum _DiscardAction { cancel, save, discard }

// ====== Kartu seksi berjudul + tombol aksi kecil (opsional) ======
class _Section extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? action;
  const _Section({required this.title, required this.child, this.action});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(.08)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.05),
              blurRadius: 12,
              offset: const Offset(0, 6))
        ],
      ),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(title,
                  style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const Spacer(),
              if (action != null) action!,
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}
