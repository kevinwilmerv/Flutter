import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'log_service.dart';
import 'package:ok_oce/widget/app_background.dart';

const String kGoogleScriptWebhookUrl = 'https://script.google.com/macros/s/AKfycbxT_vQDV177nz-hN7JQSjx1umWUWBVZjP67GTi8Eb8W9nS62AUiT86dFBiQy26k3Y7Gwg/exec';

class FeedbackPage extends StatefulWidget {
  final String idUsaha;
  const FeedbackPage({super.key, required this.idUsaha});

  @override
  State<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  final _supabase = Supabase.instance.client;
  final _formKey = GlobalKey<FormState>();
  final _judulCtrl = TextEditingController();
  final _pesanCtrl = TextEditingController();
  final _log = LogService();

  final _kategoriList = const ['Kesalahan Sistem', 'Permintaan Fitur', 'Tampilan Aplikasi', 'Lainnya'];
  String _kategori = 'Kesalahan Sistem';
  int? _rating;
  bool _sending = false;

  // ==== Toast hitam kecil seragam (top) ====
  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle_rounded,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    if (!(context as Element).mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(duration, () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });
        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        message,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
        );
      },
    );
  }

  // ====== Helpers ======
  Future<void> _sendToGoogleSheets(Map<String, dynamic> data) async {
    if (kGoogleScriptWebhookUrl.isEmpty) return;
    try {
      final res = await http.post(
        Uri.parse(kGoogleScriptWebhookUrl),
        body: {'payload': jsonEncode(data)},
      );
      if (res.statusCode != 200) {
        // ignore: avoid_print
        print('GAS responded ${res.statusCode}: ${res.body}');
      }
    } catch (e) {
      // ignore: avoid_print
      print('GAS fetch failed: $e');
      rethrow;
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();

    final user = _supabase.auth.currentUser;
    if (user == null) {
      await showTopToast(context, 'Anda belum login', icon: Icons.info_rounded);
      return;
    }

    final payload = {
      'user_id': user.id,
      'user_email': user.email,
      'id_usaha': widget.idUsaha,
      'kategori': _kategori,
      'subject': _judulCtrl.text.trim(),
      'message': _pesanCtrl.text.trim(),
      'rating': _rating,
      'app_version': null,
      'device_info': null,
      'created_at': DateTime.now().toIso8601String(),
    };

    setState(() => _sending = true);
    try {
      await _supabase.from('feedback').insert(payload);
      await _sendToGoogleSheets(payload);

      await _log.addLog(
        aktivitas: "Kirim Feedback",
        halaman: "Feedback",
        detail: "Kategori: $_kategori • Rating: ${_rating ?? '-'}",
      );

      if (!mounted) return;
      await showTopToast(context, 'Terima kasih! Feedback terkirim.', icon: Icons.check_circle_rounded);
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal mengirim: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 2000),
      );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  // ====== UI widgets ======
  Widget _headerCard() {
    final user = _supabase.auth.currentUser;
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Colors.redAccent, Colors.redAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF8FA3).withOpacity(.35),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.feedback_rounded, size: 30, color: Color(0xFFFF9AA7)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Kirim Feedback',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    )),
                const SizedBox(height: 4),
                Text(
                  user?.email ?? 'Tidak diketahui',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white70, fontSize: 12.5),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.18),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: Colors.white24),
            ),
            child: Text(
              'ID Usaha: ${widget.idUsaha}',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  Widget _categoryChips() {
    final icons = <String, IconData>{
      'Kesalahan Sistem': Icons.bug_report_rounded,
      'Permintaan Fitur': Icons.lightbulb_rounded,
      'Tampilan Aplikasi': Icons.design_services_rounded,
      'Lainnya': Icons.chat_rounded,
    };

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: _kategoriList.map((k) {
        final selected = _kategori == k;
        return ChoiceChip(
          label: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icons[k]!, size: 18, color: Colors.black87),
              const SizedBox(width: 6),
              Text(k, style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.black87)),
            ],
          ),
          selected: selected,
          onSelected: (_) => setState(() => _kategori = k),
          selectedColor: const Color(0xFFECFEFF),
          backgroundColor: Colors.white,
          shape: StadiumBorder(
            side: BorderSide(color: selected ? const Color(0xFFFFF1F3) : Colors.black12),
          ),
          labelPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          elevation: selected ? 2 : 0,
          pressElevation: 0,
        );
      }).toList(),
    );
  }

  Widget _ratingRow() {
    return Row(
      children: List.generate(5, (i) {
        final n = i + 1;
        final active = (_rating ?? 0) >= n;
        return AnimatedScale(
          scale: active ? 1.1 : 1.0,
          duration: const Duration(milliseconds: 120),
          child: IconButton(
            tooltip: '$n',
            onPressed: () => setState(() => _rating = n),
            icon: Icon(active ? Icons.star_rounded : Icons.star_border_rounded),
            color: active ? Colors.amber[700] : Colors.grey[500],
            iconSize: 30,
          ),
        );
      }),
    );
  }

  InputDecoration _inputDecoration({
    required String label,
    String? hint,
    IconData? icon,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      prefixIcon: icon == null ? null : Icon(icon, color: Colors.black87),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFe5e7eb)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFFC5CC), width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    );
  }

  @override
  void dispose() {
    _judulCtrl.dispose();
    _pesanCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // ✅ Paksa LIGHT hanya untuk halaman ini + teks/ikon default hitam
    final base = Theme.of(context);
    final lightForced = base.copyWith(
      brightness: Brightness.light,
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      iconTheme: const IconThemeData(color: Colors.black87),
      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        labelStyle: const TextStyle(color: Colors.black87),
        hintStyle: const TextStyle(color: Colors.black54),
        prefixStyle: const TextStyle(color: Colors.black87),
      ),
      scaffoldBackgroundColor: Colors.transparent,
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: Colors.black87,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
    );

    return Theme(
      data: lightForced,
      child: AppBackground(
        // overlayOpacity: 0.12,
        child: Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: false, // biar konten tidak numpuk di bawah AppBar
          appBar: AppBar(
            title: const Text('Feedback'),
            centerTitle: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => Navigator.maybePop(context),
              splashRadius: 22,
              tooltip: 'Kembali',
            ),
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _headerCard(),
                  const SizedBox(height: 16),

                  // Form card
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.black.withOpacity(.05)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.06),
                          blurRadius: 16,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Kategori', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                          const SizedBox(height: 8),
                          _categoryChips(),
                          const SizedBox(height: 16),

                          // Judul
                          TextFormField(
                            controller: _judulCtrl,
                            textInputAction: TextInputAction.next,
                            decoration: _inputDecoration(
                              label: 'Judul / Subjek',
                              hint: 'Contoh: Perhitungan total hasil tidak sesuai',
                              icon: Icons.title_rounded,
                            ),
                            validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
                          ),
                          const SizedBox(height: 12),

                          // Pesan
                          TextFormField(
                            controller: _pesanCtrl,
                            maxLines: 6,
                            maxLength: 2000,
                            decoration: _inputDecoration(
                              label: 'Deskripsi / Saran',
                              hint: 'Jelaskan detail: langkah reproduksi, harapan Anda, dsb.',
                              icon: Icons.description_rounded,
                            ),
                            validator: (v) => (v == null || v.trim().length < 10) ? 'Minimal 10 karakter' : null,
                            buildCounter: (context, {required int currentLength, required bool isFocused, required int? maxLength}) =>
                                Padding(
                                  padding: const EdgeInsets.only(top: 6, right: 6),
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      '$currentLength / $maxLength',
                                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                                    ),
                                  ),
                                ),
                          ),

                          const SizedBox(height: 4),
                          const Text('Rating (opsional)', style: TextStyle(fontWeight: FontWeight.w700)),
                          _ratingRow(),
                          const SizedBox(height: 8),

                          // Submit
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton.icon(
                              onPressed: _sending ? null : _submit,
                              icon: _sending
                                  ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                                  : const Icon(Icons.send_rounded),
                              label: const Padding(
                                padding: EdgeInsets.symmetric(vertical: 14),
                                child: Text('Kirim Feedback', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                              ),
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF1F2937),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
