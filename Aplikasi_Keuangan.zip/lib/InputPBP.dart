import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:ok_oce/widget/usaha_drawer.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/pages/laporanStok.dart';

// ================== FIFO helpers ==================
class _FifoLayer {
  num qty;
  final num price;
  _FifoLayer({required this.qty, required this.price});
}

List<_FifoLayer> _cloneLayers(List<_FifoLayer> src) =>
    src.map((e) => _FifoLayer(qty: e.qty, price: e.price)).toList();

void _consumeFifo(List<_FifoLayer> layers, num takeQty) {
  var remaining = takeQty;
  for (final layer in layers) {
    if (remaining <= 0) break;
    final use = remaining <= layer.qty ? remaining : layer.qty;
    layer.qty -= use;
    remaining -= use;
  }
  layers.removeWhere((l) => l.qty <= 0);
}
// ====================================================

class InputPBP extends StatefulWidget {
  final String idUsaha;
  const InputPBP({super.key, required this.idUsaha});

  @override
  State<InputPBP> createState() => _InputPBPState();
}

// ===== Unsaved-changes guard: enum (top-level) =====
enum _DiscardAction { cancel, save, discard }
// ===================================================

class _InputPBPState extends State<InputPBP> {
  // nilai persediaan H-1 per baris (pakai key id row di tabel bahan_pokok)
  final Map<String, num> _prevQtyRow = {};
  final Map<String, num> _prevValRow = {};
  final supabase = Supabase.instance.client;

  String? selectedKategori;
  List<String> kategoriList = [];
  List<Map<String, dynamic>> bahanList = [];

  // search
  final TextEditingController _searchCtrl = TextEditingController();
  String _q = '';

  // key: id row di tabel bahan_pokok (String)
  final Map<String, TextEditingController> awalCtrl = {};
  final Map<String, TextEditingController> beliCtrl = {};
  final Map<String, TextEditingController> ambilCtrl = {};
  final Map<String, num> stokAkhir = {};

  DateTime get _todayDate {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  DateTime? selectedDate;

  final DateFormat _fmtChip = DateFormat('d MMM yyyy', 'id_ID');

  // sinkron scroll header-body
  final _hHeader = ScrollController();
  final _hBody   = ScrollController();
  final _vBody   = ScrollController();

  final List<String> _headers = const [
    'Nama', 'Stok Awal', 'Pembelian', 'Pemakaian', 'Stok Akhir', 'Total Harga', 'Satuan',
  ];
  final List<double> _baseWidths = const [220, 130, 130, 130, 150, 170, 140];

  bool _saving = false;
  OverlayEntry? _toastEntry;

  // ================== CACHE FIFO ==================
  // Layers FIFO per id_bahan untuk posisi H-1 (sebelum selectedDate)
  final Map<String, List<_FifoLayer>> _prevFifoLayers = {};
  // =================================================

  // ===== Unsaved-changes guard: state & helpers =====
  final _dirty = ValueNotifier<bool>(false);
  bool get _isDirty => _dirty.value;

  void _markDirty() {
    if (!_dirty.value) {
      _dirty.value = true;
    }
  }

  void _markClean() {
    if (_dirty.value) _dirty.value = false;
  }

  Future<_DiscardAction> _confirmDiscardDialog() async {
    return await showDialog<_DiscardAction>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Perubahan belum disimpan'),
        content: const Text('Kamu sudah mengubah data tapi belum menekan Simpan. Mau gimana?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardAction.cancel),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, _DiscardAction.discard),
            child: const Text('Tinggalkan'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, _DiscardAction.save),
            icon: const Icon(Icons.save),
            label: const Text('Simpan sekarang'),
          ),
        ],
      ),
    ) ?? _DiscardAction.cancel;
  }

  Future<bool> _confirmLeaveIfDirty() async {
    if (!_isDirty) return true;
    final action = await _confirmDiscardDialog();
    if (action == _DiscardAction.save) {
      await _simpanData();
      return true;
    } else if (action == _DiscardAction.discard) {
      return true;
    }
    return false; // cancel
  }
  // ===================================================

  /// Ambil snapshot TERAKHIR (< selectedDate) dari laporan_stok per id_bahan.
  /// Return: id_bahan -> row (berisi stok_akhir, total_harga, kategori, nama_bahan, satuan, tanggal)
  Future<Map<String, Map<String, dynamic>>> _fetchLatestPrevSnapshots() async {
    if (selectedDate == null) return {};
    final cutoff = DateFormat('yyyy-MM-dd').format(selectedDate!.subtract(const Duration(days: 1)));

    final rows = await supabase
        .from('laporan_stok')
        .select('id_bahan, stok_akhir, total_harga, kategori, nama_bahan, satuan, tanggal')
        .eq('id_usaha', widget.idUsaha)
        .lte('tanggal', cutoff)
        .order('tanggal', ascending: false);

    final map = <String, Map<String, dynamic>>{};
    for (final r in (rows as List)) {
      final k = (r['id_bahan'] ?? '').toString();
      if (k.isEmpty) continue;
      // ambil hanya yang pertama (tanggal paling baru < cutoff)
      map.putIfAbsent(k, () => r);
    }
    return map;
  }

  /// Bangun layers FIFO H-1 untuk sekumpulan id_bahan sekaligus.
  /// Sumber: semua pembelian <= cutoff lalu dikurangi total ambil <= cutoff.
  Future<void> _buildPrevFifoLayersBulk(List<String> idList) async {
    _prevFifoLayers.clear();
    if (selectedDate == null || idList.isEmpty) return;

    final cutoff = DateFormat('yyyy-MM-dd')
        .format(selectedDate!.subtract(const Duration(days: 1)));

    // helper: bikin parameter untuk operator IN → '("a","b","c")'
    String _inParam(List<String> xs) =>
        '(${xs.map((e) => '"$e"').join(',')})';

    // 1) Semua pembelian <= cutoff
    final buys = List<Map<String, dynamic>>.from(
      await supabase
          .from('bahan_pokok')
          .select('id_bahan, jumlah, harga, tanggal')
          .eq('id_usaha', widget.idUsaha)
          .filter('id_bahan', 'in', _inParam(idList))
          .lte('tanggal', cutoff)
          .order('id_bahan', ascending: true)
          .order('tanggal', ascending: true),
    );

    final Map<String, List<_FifoLayer>> layersMap = {};
    for (final r in buys) {
      final idb = (r['id_bahan'] ?? '').toString();
      if (idb.isEmpty) continue;
      final num qty = (r['jumlah'] is num)
          ? r['jumlah'] as num
          : num.tryParse((r['jumlah'] ?? '0').toString()) ?? 0;
      final num price = (r['harga'] is num)
          ? r['harga'] as num
          : num.tryParse((r['harga'] ?? '0').toString()) ?? 0;
      if (qty <= 0) continue;
      (layersMap[idb] ??= []).add(_FifoLayer(qty: qty, price: price));
    }

    // 2) Total ambil <= cutoff
    final takes = List<Map<String, dynamic>>.from(
      await supabase
          .from('laporan_stok')
          .select('id_bahan, ambil')
          .eq('id_usaha', widget.idUsaha)
          .filter('id_bahan', 'in', _inParam(idList))
          .lte('tanggal', cutoff),
    );

    final Map<String, num> totalAmbil = {};
    for (final r in takes) {
      final idb = (r['id_bahan'] ?? '').toString();
      if (idb.isEmpty) continue;
      final num a = (r['ambil'] is num)
          ? r['ambil'] as num
          : num.tryParse((r['ambil'] ?? '0').toString()) ?? 0;
      totalAmbil[idb] = (totalAmbil[idb] ?? 0) + a;
    }

    // 3) Kurangi layers dengan total ambil (FIFO)
    for (final idb in idList) {
      final list = layersMap[idb] ?? <_FifoLayer>[];
      final ambilQty = totalAmbil[idb] ?? 0;
      if (ambilQty > 0 && list.isNotEmpty) {
        _consumeFifo(list, ambilQty);
      }
      _prevFifoLayers[idb] = list;
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchKategori();
    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });
    _searchCtrl.addListener(() {
      setState(() => _q = _searchCtrl.text.trim().toLowerCase());
    });
  }

  Widget _saveHeaderButton(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final label = _saving
        ? (w < 380 ? 'Menyimpan...' : 'Menyimpan Laporan...')
        : (w < 380 ? 'Simpan' : 'Simpan Laporan');

    return FilledButton.icon(
      onPressed: _saving ? null : _simpanData,
      icon: _saving
          ? const SizedBox(
        width: 16, height: 16,
        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
      )
          : const Icon(Icons.save_rounded, size: 18),
      label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
      style: FilledButton.styleFrom(
        shape: const StadiumBorder(),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        backgroundColor: Colors.black87,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
    );
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    for (final c in awalCtrl.values) c.dispose();
    for (final c in beliCtrl.values) c.dispose();
    for (final c in ambilCtrl.values) c.dispose();
    _hHeader.dispose();
    _hBody.dispose();
    _vBody.dispose();
    _dirty.dispose(); // guard
    super.dispose();
  }

  // ================== DATA ==================
  Future<void> _fetchKategori() async {
    try {
      // kategori dari pembelian HARI INI (jika ada)
      var q = supabase
          .from('bahan_pokok')
          .select('jenis')
          .eq('id_usaha', widget.idUsaha);

      if (selectedDate != null) {
        final t = DateFormat('yyyy-MM-dd').format(selectedDate!);
        q = q.eq('tanggal', t);
      }
      final rowsToday = await q;

      final setKategori = <String>{};
      for (final r in (rowsToday as List)) {
        final s = (r['jenis'] ?? '').toString().trim();
        if (s.isNotEmpty) setKategori.add(s);
      }

      // kategori dari SNAPSHOT TERAKHIR SEBELUM tanggal terpilih
      final snap = await _fetchLatestPrevSnapshots();
      for (final r in snap.values) {
        final s = (r['kategori'] ?? r['jenis'] ?? '').toString().trim();
        if (s.isNotEmpty) setKategori.add(s);
      }

      final distinctKategori = setKategori.toList()..sort();
      distinctKategori.insert(0, 'Semua Kategori');

      if (!mounted) return;
      setState(() {
        kategoriList = distinctKategori;
        if (selectedKategori != null && !kategoriList.contains(selectedKategori)) {
          selectedKategori = null;
          bahanList = [];
        }
      });
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal memuat kategori: $e',
        icon: Icons.warning_amber_rounded,
      );
    }
  }

  // ambil {id_bahan -> stok_akhir} dari snapshot TERBARU sebelum selectedDate (bisa lompat hari)
  Future<Map<String, num>> _fetchAwalMapFromPrevDay() async {
    if (selectedDate == null) return {};
    final cutoff = DateFormat('yyyy-MM-dd').format(
      selectedDate!.subtract(const Duration(days: 1)),
    );

    final rows = await supabase
        .from('laporan_stok')
        .select('id_bahan, stok_akhir, tanggal')
        .eq('id_usaha', widget.idUsaha)
        .lte('tanggal', cutoff)
        .order('tanggal', ascending: false);

    final map = <String, num>{};
    for (final r in (rows as List)) {
      final k = (r['id_bahan'] ?? '').toString();
      if (k.isEmpty || map.containsKey(k)) continue; // pakai yang paling baru
      final num akhir = (r['stok_akhir'] is num)
          ? r['stok_akhir'] as num
          : num.tryParse((r['stok_akhir'] ?? '0').toString()) ?? 0;
      map[k] = akhir;
    }
    return map;
  }

  // ambil {id_bahan -> total_harga} TERBARU sebelum selectedDate (untuk WAC; bisa lompat hari)
  Future<Map<String, num>> _fetchPrevValueMapFromPrevDay() async {
    if (selectedDate == null) return {};
    final cutoff = DateFormat('yyyy-MM-dd').format(
      selectedDate!.subtract(const Duration(days: 1)),
    );

    final rows = await supabase
        .from('laporan_stok')
        .select('id_bahan, total_harga, tanggal')
        .eq('id_usaha', widget.idUsaha)
        .lte('tanggal', cutoff)
        .order('tanggal', ascending: false);

    final map = <String, num>{};
    for (final r in (rows as List)) {
      final k = (r['id_bahan'] ?? '').toString();
      if (k.isEmpty || map.containsKey(k)) continue; // pakai yang paling baru
      final num v = (r['total_harga'] is num)
          ? r['total_harga'] as num
          : num.tryParse((r['total_harga'] ?? '0').toString()) ?? 0;
      map[k] = v;
    }
    return map;
  }

  Future<void> _fetchBahan(String? kategori) async {
    try {
      // 1) Pembelian pada tanggal terpilih (bisa kosong)
      var q = supabase
          .from('bahan_pokok')
          .select('id, id_bahan, nama_bahan, jenis, jumlah, satuan, harga')
          .eq('id_usaha', widget.idUsaha) as PostgrestFilterBuilder;

      String? t;
      if (selectedDate != null) {
        t = DateFormat('yyyy-MM-dd').format(selectedDate!);
        q = q.eq('tanggal', t);
      }
      if (kategori != null && kategori != 'Semua Kategori') {
        q = q.eq('jenis', kategori);
      }
      final todayRows = List<Map<String, dynamic>>.from(await q.order('nama_bahan'));

      // 2) Snapshot terakhir sebelum tanggal terpilih (per id_bahan unik)
      final prevSnap = await _fetchLatestPrevSnapshots();

      // 3) Gabungkan
      final byIdBahanToday = <String, Map<String, dynamic>>{
        for (final r in todayRows) (r['id_bahan'] ?? '').toString(): r
      };

      final merged = <Map<String, dynamic>>[];
      merged.addAll(todayRows);

      for (final entry in prevSnap.entries) {
        final idBahan = entry.key;
        final snap = entry.value;

        // filter kategori jika dipilih spesifik
        final snapKategori = (snap['kategori'] ?? '').toString();
        if (kategori != null && kategori != 'Semua Kategori' && snapKategori != kategori) {
          continue;
        }

        if (!byIdBahanToday.containsKey(idBahan)) {
          // baris sintetis (tidak ada pembelian hari ini, tapi ada stok sebelumnya)
          merged.add({
            'id': 'snap_$idBahan',
            'id_bahan': idBahan,
            'nama_bahan': snap['nama_bahan'] ?? idBahan,
            'jenis': snapKategori,
            'jumlah': 0, // beli hari ini = 0
            'satuan': snap['satuan'] ?? '',
            'harga': 0,
          });
        }
      }

      // 4) Siapkan controller dan cache prev
      final prevQtyMap = await _fetchAwalMapFromPrevDay();
      final prevValMap = await _fetchPrevValueMapFromPrevDay();

      // reset controllers & cache
      for (final c in awalCtrl.values) c.dispose();
      for (final c in beliCtrl.values) c.dispose();
      for (final c in ambilCtrl.values) c.dispose();
      awalCtrl.clear(); beliCtrl.clear(); ambilCtrl.clear(); stokAkhir.clear();
      _prevQtyRow.clear(); _prevValRow.clear();

      bahanList = merged..sort((a, b) => (a['nama_bahan'] ?? '').toString()
          .toLowerCase().compareTo((b['nama_bahan'] ?? '').toString().toLowerCase()));

      // build FIFO layers H-1
      final idListAll = <String>[
        for (final b in bahanList) (b['id_bahan'] ?? '').toString()
      ]..removeWhere((s) => s.isEmpty);
      await _buildPrevFifoLayersBulk(idListAll);

      for (final b in bahanList) {
        final idRow      = b['id'].toString();
        final idBahanRel = (b['id_bahan'] ?? '').toString();

        final num prevQty = prevQtyMap[idBahanRel] ?? 0;
        final num todayBuy = (b['jumlah'] is num)
            ? (b['jumlah'] as num)
            : num.tryParse((b['jumlah'] ?? '0').toString()) ?? 0;

        _prevQtyRow[idRow] = prevQty;
        _prevValRow[idRow] = prevValMap[idBahanRel] ?? 0;

        awalCtrl[idRow]  = TextEditingController(text: prevQty.toString());
        beliCtrl[idRow]  = TextEditingController(text: todayBuy.toString());
        ambilCtrl[idRow] = TextEditingController(text: '0');

        stokAkhir[idRow] = prevQty + todayBuy; // default sebelum ada input ambil
      }

      if (mounted) {
        setState(() {});
        _markClean(); // form hasil load dianggap "bersih"
      }
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal memuat bahan: $e',
        icon: Icons.warning_amber_rounded,
      );
    }
  }

  void _hitungStok(String idBahan) {
    final awal  = num.tryParse(awalCtrl[idBahan]?.text ?? '0') ?? 0;
    final beli  = num.tryParse(beliCtrl[idBahan]?.text ?? '0') ?? 0;
    final ambil = num.tryParse(ambilCtrl[idBahan]?.text ?? '0') ?? 0;
    stokAkhir[idBahan] = awal + beli - ambil;
    setState(() {});
  }

  Future<void> _simpanData() async {
    if (_saving) return;
    if (selectedDate == null) {
      await showTopToast(context, "Pilih tanggal terlebih dahulu", icon: Icons.info_rounded);
      return;
    }
    if (selectedKategori == null || selectedKategori!.isEmpty) {
      await showTopToast(context, "Pilih kategori terlebih dahulu", icon: Icons.info_rounded);
      return;
    }
    if (bahanList.isEmpty) {
      await showTopToast(context, "Tidak ada data bahan untuk disimpan", icon: Icons.info_rounded);
      return;
    }

    try {
      setState(() => _saving = true);
      FocusScope.of(context).unfocus();

      final tanggal = DateFormat('yyyy-MM-dd').format(selectedDate!);

      // 1) Siapkan payload rows (FIFO)
      final rows = <Map<String, dynamic>>[];
      for (final b in bahanList) {
        final idKey = b['id'].toString();
        final num awal  = num.tryParse(awalCtrl[idKey]?.text ?? '0') ?? 0;
        final num beli  = num.tryParse(beliCtrl[idKey]?.text ?? '0') ?? 0;
        final num ambil = num.tryParse(ambilCtrl[idKey]?.text ?? '0') ?? 0;
        final num akhir = awal + beli - ambil;

        final num harga = (b['harga'] is num)
            ? (b['harga'] as num)
            : num.tryParse((b['harga'] ?? '0').toString()) ?? 0;

        // FIFO total_harga
        final String idBahanRel = (b['id_bahan'] ?? '').toString();
        final baseLayers = _prevFifoLayers[idBahanRel] ?? <_FifoLayer>[];
        final layers = _cloneLayers(baseLayers);

        if (beli > 0 && harga > 0) {
          layers.add(_FifoLayer(qty: beli, price: harga));
        }
        if (ambil > 0 && layers.isNotEmpty) {
          _consumeFifo(layers, ambil);
        }
        num total = 0;
        for (final l in layers) {
          total += l.qty * l.price;
        }
        if (total < 0) total = 0;

        rows.add({
          'id_usaha'   : widget.idUsaha,
          'tanggal'    : tanggal,
          'id_bahan'   : b['id_bahan'],
          'kategori'   : (selectedKategori == 'Semua Kategori') ? (b['jenis'] ?? '') : selectedKategori,
          'nama_bahan' : b['nama_bahan'],
          'satuan'     : b['satuan'] ?? '',
          'awal'       : awal,
          'beli'       : beli,
          'ambil'      : ambil,
          'stok_akhir' : akhir,
          'total_harga': total,
        });
      }

      // 2) Hapus semua data lama untuk tanggal tsb
      await supabase
          .from('laporan_stok')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .eq('tanggal', tanggal);

      // 3) Insert ulang
      if (rows.isNotEmpty) {
        await supabase.from('laporan_stok').insert(rows);
      }

      if (!mounted) return;
      await showTopToast(context, "Data stok berhasil disimpan", icon: Icons.check_circle_rounded);
      _markClean(); // tandai bersih setelah berhasil simpan
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal menyimpan: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 4200),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ==== Toast kecil (atas) ====
  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle_rounded,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    // Hapus toast sebelumnya jika masih ada
    _toastEntry?.remove();
    _toastEntry = null;

    final overlay = Overlay.of(context, rootOverlay: true);
    if (overlay == null) return;

    _toastEntry = OverlayEntry(
      builder: (_) => SafeArea(
        child: Align(
          alignment: const Alignment(0, -0.92),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(12),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      message,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    overlay.insert(_toastEntry!);
    await Future.delayed(duration);
    _toastEntry?.remove();
    _toastEntry = null;
  }

  // ================== DATE UI (single date) ==================
  Future<void> _clearDate() async {
    final ok = await _confirmLeaveIfDirty();
    if (!ok) return;

    setState(() => selectedDate = null);
    await _fetchKategori();
  }

  Future<void> _pickDate() async {
    final today = _todayDate;

    final picked = await showDatePicker(
      context: context,
      // jangan biarkan initialDate melewati hari ini
      initialDate: (() {
        final base = selectedDate ?? today;
        return base.isAfter(today) ? today : base;
      })(),
      firstDate: DateTime(2020),
      lastDate: today, // ⛔ maksimum = hari ini
      selectableDayPredicate: (d) => !d.isAfter(today), // disable tanggal > hari ini
      builder: (ctx, child) {
        final t = Theme.of(ctx);
        return Theme(
          data: t.copyWith(
            useMaterial3: false,
            datePickerTheme: DatePickerThemeData(
              backgroundColor: const Color(0xFFFFE4E9),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              dayStyle: const TextStyle(color: Colors.black87),
              headerForegroundColor: Colors.black87,
            ),
            dialogTheme: t.dialogTheme.copyWith(
              backgroundColor: const Color(0xFFFFE4E9),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked == null) return;

    final ok = await _confirmLeaveIfDirty();
    if (!ok) return;

    setState(() => selectedDate = picked);
    await _fetchKategori();
    if (selectedKategori != null) {
      await _fetchBahan(selectedKategori);
    }
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();
    DateTime target = DateTime(now.year, now.month, now.day);
    if (code == 'yesterday') {
      target = target.subtract(const Duration(days: 1));
    } else if (code == 'bom') {
      target = DateTime(now.year, now.month, 1);
    } else if (code == 'eom') {
      target = DateTime(now.year, now.month + 1, 0);
    }

    // ⛔ jangan biarkan preset memilih tanggal > hari ini
    final today = _todayDate;
    if (target.isAfter(today)) target = today;

    final ok = await _confirmLeaveIfDirty();
    if (!ok) return;

    setState(() => selectedDate = target);
    await _fetchKategori();
    if (selectedKategori != null) {
      await _fetchBahan(selectedKategori);
    }
  }

  // ================== UI Helper ==================
  Widget _sectionCard({required Widget child}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.55),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.black.withOpacity(0.05)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: child,
    );
  }

  Widget _dateAndSearchCard() {
    return _sectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Tanggal & Pencarian',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 12),

          // Bar tombol tanggal + clear + Lihat Laporan (kanan)
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _pickDate,
                icon: const Icon(Icons.date_range, size: 18),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFE4E9),
                  foregroundColor: Colors.black,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                    side: const BorderSide(color: Colors.black, width: 1),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
                label: const Text('Minggu, pilih tanggal'),
              ),
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: _clearDate,
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.black, width: 1),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                child: const Text('Clear'),
              ),

              const Spacer(),

              // Tombol kecil "Lihat Laporan"
              SizedBox(
                height: 36,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final ok = await _confirmLeaveIfDirty();
                    if (!ok) return;
                    if (!mounted) return;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LaporanStok(idUsaha: widget.idUsaha),
                      ),
                    );
                  },
                  icon: const Icon(Icons.receipt_long, size: 16),
                  label: const Text('Lihat Laporan'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                    side: const BorderSide(color: Colors.black, width: 1),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                    foregroundColor: Colors.black,
                    backgroundColor: const Color(0xFFFFE4E9),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Input search
          TextField(
            controller: _searchCtrl,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'Cari ID atau Nama Barang',
              prefixIcon: const Icon(Icons.search),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide(color: Colors.black.withOpacity(.2)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide(color: Colors.black.withOpacity(.2)),
              ),
              focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(30)),
                borderSide: BorderSide(color: Colors.black, width: 1),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Pill tanggal + preset chip
          InkWell(
            onTap: _pickDate,
            borderRadius: BorderRadius.circular(40),
            child: _DatePill(
              label: 'Tanggal',
              value: selectedDate == null ? '—' : _fmtChip.format(selectedDate!),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: [
              _PresetChip(text: 'Hari Ini',   onTap: () => _applyPreset('today')),
              _PresetChip(text: 'Kemarin',    onTap: () => _applyPreset('yesterday')),
              _PresetChip(text: 'Awal Bulan', onTap: () => _applyPreset('bom')),
              _PresetChip(text: 'Akhir Bulan',onTap: () => _applyPreset('eom')),
            ],
          ),

          const SizedBox(height: 12),

          // Tombol SIMPAN
          LayoutBuilder(builder: (context, c) {
            final double w = c.maxWidth;
            final double targetWidth = (w <= 380) ? w : (w <= 560) ? w * 0.70 : 420;
            final label = _saving
                ? (w < 380 ? 'Menyimpan...' : 'Menyimpan Laporan...')
                : (w < 380 ? 'Simpan' : 'Simpan');

            return Align(
              alignment: Alignment.centerLeft,
              child: SizedBox(
                width: targetWidth,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _simpanData,
                  icon: _saving
                      ? const SizedBox(
                    width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                      : const Icon(Icons.save_rounded, size: 18),
                  label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
                  style: FilledButton.styleFrom(
                    shape: const StadiumBorder(),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    backgroundColor: Colors.black87,
                    foregroundColor: Colors.white,
                    elevation: 0,
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildHeader(List<double> widths) {
    const sideInset = 20.0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: sideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: { for (int i=0; i<widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(
            children: List.generate(_headers.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  _headers[i],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _capsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08),
              blurRadius: 10, offset: const Offset(0, 4)),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _cellText(String text) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(text,
          textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
    );
  }

  Widget _cellInput(TextEditingController? c, ValueChanged<String> onChanged) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: TextField(
        controller: c,
        textAlign: TextAlign.center,
        keyboardType: const TextInputType.numberWithOptions(decimal: false),
        onTap: () {
          if (c != null) {
            c.selection = TextSelection(baseOffset: 0, extentOffset: c.text.length);
          }
        },
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
          _RemoveLeadingZerosFormatter(),
        ],
        onChanged: onChanged,
        decoration: const InputDecoration(
          isDense: true,
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 6),
        ),
      ),
    );
  }

  Widget _buildPlaceholder(List<double> widths) {
    return _capsuleRow(
      child: Table(
        columnWidths: { for (int i=0; i<widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(children: List.generate(widths.length, (i) => _cellText('–'))),
        ],
      ),
    );
  }

  Widget _dataRow({
    required List<double> widths,
    required Map<String, dynamic> bahan,
    required bool isFirst,
  }) {
    final id = bahan['id'].toString();
    final akhir = stokAkhir[id] ?? 0;

    final num harga = (bahan['harga'] is num)
        ? (bahan['harga'] as num)
        : num.tryParse((bahan['harga'] ?? '0').toString()) ?? 0;

    // ======== FIFO (ganti WAC) ========
    final num beli  = num.tryParse(beliCtrl[id]?.text  ?? '0') ?? 0;
    final num ambil = num.tryParse(ambilCtrl[id]?.text ?? '0') ?? 0;

    final String idBahanRel = (bahan['id_bahan'] ?? '').toString();
    final baseLayers = _prevFifoLayers[idBahanRel] ?? <_FifoLayer>[];
    final layers = _cloneLayers(baseLayers);

    if (beli > 0 && harga > 0) {
      layers.add(_FifoLayer(qty: beli, price: harga));
    }

    if (ambil > 0 && layers.isNotEmpty) {
      _consumeFifo(layers, ambil);
    }

    num total = 0;
    for (final l in layers) {
      total += l.qty * l.price;
    }
    if (total < 0) total = 0;
    // ===================================

    final String totalStr = NumberFormat.decimalPattern('id_ID').format(total);
    final String satuanStr = (bahan['satuan'] ?? '-').toString();

    return _capsuleRow(
      top: isFirst ? 6 : 12,
      child: Table(
        columnWidths: { for (int i=0; i<widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(
            children: [
              _cellText(bahan['nama_bahan'].toString()),
              _cellInput(awalCtrl[id],  (_) { _markDirty(); _hitungStok(id); }),
              _cellText(beliCtrl[id]?.text ?? '0'), // read-only
              _cellInput(ambilCtrl[id], (_) { _markDirty(); _hitungStok(id); }),
              _cellText('$akhir'),
              _cellText(totalStr),
              _cellText(satuanStr),
            ],
          ),
        ],
      ),
    );
  }

  // ================== BUILD ==================
  @override
  Widget build(BuildContext context) {
    // tema LIGHT + ikon/teks hitam
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(
            color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
        backgroundColor: const Color(0xFFFFE4E9),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    // filter hasil sesuai search
    final List<Map<String, dynamic>> filtered = _q.isEmpty
        ? bahanList
        : bahanList.where((b) {
      final id = (b['id_bahan'] ?? '').toString().toLowerCase();
      final nm = (b['nama_bahan'] ?? '').toString().toLowerCase();
      return id.contains(_q) || nm.contains(_q);
    }).toList();

    // === Scaffold utama ===
    Widget scaffold = Scaffold(
      drawer: usahaDrawer(
        idUsaha: widget.idUsaha,
        active: 'pbp',
        onConfirmLeaveIfDirty: _confirmLeaveIfDirty, // penting
      ),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Builder(
          builder: (ctx) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(ctx).openDrawer(),
          ),
        ),
        title: const Text(
          "Input Persediaan Bahan Pokok",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: false,
      ),
      body: AppBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _dateAndSearchCard(),
                const SizedBox(height: 16),

                // === Filter Kategori ===
                Container(
                  margin: const EdgeInsets.only(top: 4, bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: Colors.black.withOpacity(0.10)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.10),
                        blurRadius: 16,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Filter Kategori',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                      ),
                      const SizedBox(height: 8),

                      DropdownButtonFormField<String>(
                        value: selectedKategori,
                        isExpanded: true,
                        menuMaxHeight: 320,
                        hint: const Text("Pilih Kategori"),
                        style: const TextStyle(color: Colors.black87),
                        dropdownColor: Colors.white,
                        iconEnabledColor: Colors.black87,
                        items: kategoriList
                            .map((k) => DropdownMenuItem(
                          value: k,
                          child: Text(k, style: const TextStyle(color: Colors.black87)),
                        ))
                            .toList(),
                        onChanged: (v) async {
                          // Opsional: guard saat ganti kategori (kalau ingin)
                          final ok = await _confirmLeaveIfDirty();
                          if (!ok) return;

                          setState(() => selectedKategori = v);
                          if (v != null) await _fetchBahan(v);
                        },
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          prefixIcon: const Icon(Icons.category_outlined, size: 18, color: Colors.black87),
                          hintStyle: const TextStyle(color: Colors.black54),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black.withOpacity(.22)),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black.withOpacity(.22)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black, width: 1.2),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // ====== AREA TABEL ======
                LayoutBuilder(
                  builder: (context, c) {
                    final minTotal = _baseWidths.reduce((a, b) => a + b);
                    final available = c.maxWidth - 24;
                    final totalW = available >= minTotal ? available : minTotal.toDouble();
                    final scale  = totalW / minTotal;
                    final widths = _baseWidths.map((w) => w * scale).toList();
                    final tableWidth = widths.reduce((a, b) => a + b);

                    const double tableHeight = 420;

                    final listToShow = filtered;

                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 14, offset: const Offset(0, 6))],
                      ),
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                      child: Column(
                        children: [
                          // HEADER tabel (scroll horizontal)
                          Scrollbar(
                            controller: _hHeader,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _hHeader,
                              scrollDirection: Axis.horizontal,
                              child: SizedBox(width: tableWidth, child: _buildHeader(widths)),
                            ),
                          ),
                          const SizedBox(height: 8),

                          // BODY tabel
                          SizedBox(
                            height: tableHeight,
                            child: Scrollbar(
                              controller: _vBody,
                              thumbVisibility: true,
                              child: SingleChildScrollView(
                                controller: _vBody,
                                child: Scrollbar(
                                  controller: _hBody,
                                  notificationPredicate: (n) => n.depth == 1,
                                  thumbVisibility: true,
                                  child: SingleChildScrollView(
                                    controller: _hBody,
                                    scrollDirection: Axis.horizontal,
                                    child: SizedBox(
                                      width: tableWidth,
                                      child: listToShow.isEmpty
                                          ? _buildPlaceholder(widths)
                                          : Column(
                                        children: List.generate(
                                          listToShow.length,
                                              (i) => _dataRow(
                                            widths: widths,
                                            bahan: listToShow[i],
                                            isFirst: i == 0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );

    // === Bungkus guard back (WillPopScope) ===
    scaffold = ValueListenableBuilder<bool>(
      valueListenable: _dirty,
      builder: (context, isDirty, child) {
        return WillPopScope(
          onWillPop: () async => await _confirmLeaveIfDirty(),
          child: child!,
        );
      },
      child: scaffold,
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: scaffold,
      ),
    );
  }
}

// === Reusable kecil: pill & preset chip ===
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Tanggal', style: TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _RemoveLeadingZerosFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final noLeading = newValue.text.replaceFirst(RegExp(r'^0+(?=\d)'), '');
    final fixed = noLeading.isEmpty ? '0' : noLeading;
    return TextEditingValue(
      text: fixed,
      selection: TextSelection.collapsed(offset: fixed.length),
      composing: TextRange.empty,
    );
  }
}
