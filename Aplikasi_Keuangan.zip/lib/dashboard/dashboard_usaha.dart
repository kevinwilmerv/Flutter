import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:ok_oce/InputIncomeMato.dart';
import 'package:ok_oce/InputPBP.dart';
import 'package:ok_oce/InputTransaksiPage.dart';
import 'package:ok_oce/log_page.dart';
import 'package:ok_oce/log_service.dart';
import 'package:ok_oce/pages/laporanIncomeMato.dart';
import 'package:ok_oce/pages/laporanLB.dart';
import 'package:ok_oce/pages/laporanStok.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/services.dart';
import 'package:ok_oce/feedbackPage.dart';
import 'package:ok_oce/widget/pop_notifier.dart';
import 'package:ok_oce/widget/app_background.dart';
import 'package:ok_oce/widget/floating_helper_button.dart';
import 'package:ok_oce/pages/helper_page.dart';
import 'package:ok_oce/pages/laporan_transaksi_page.dart';

int asInt(dynamic v) {
  if (v == null) return 0;
  if (v is int) return v;
  if (v is double) return v.round();
  if (v is String) return int.tryParse(v) ?? 0;
  return 0;
}

String asStr(dynamic v) => (v ?? '').toString();

// === Responsive helpers (final) ===
extension CtxX on BuildContext {
  MediaQueryData get mq => MediaQuery.of(this);
  Size get sz => mq.size;
  Orientation get ori => mq.orientation;

  // Breakpoints
  bool get isPhone   => sz.width < 600;
  bool get isTablet  => sz.width >= 600 && sz.width < 1024;
  bool get isDesktop => sz.width >= 1024;

  // ALIAS agar kode lama tetap jalan
  bool get isMobile => isPhone;

  bool get isPhonePortrait  => isPhone  && ori == Orientation.portrait;
  bool get isPhoneLandscape => isPhone  && ori == Orientation.landscape;
  bool get isTabPortrait    => isTablet && ori == Orientation.portrait;
  bool get isTabLandscape   => isTablet && ori == Orientation.landscape;

  // Global UI scaling
  double get uiScale {
    if (isPhonePortrait)  return 0.86;
    if (isPhoneLandscape) return 0.80;
    if (isTabPortrait)    return 0.95;
    return 1.0;
  }

  T pick<T>({required T mobile, T? tablet, T? desktop}) {
    if (isDesktop) return (desktop ?? tablet ?? mobile);
    if (isTablet)  return (tablet ?? mobile);
    return mobile;
  }

  double sx(double v) => v * uiScale;
}

/// Pembungkus compact utk phone (tanpa mengubah logika)
class _CompactForMobile extends StatelessWidget {
  final Widget child;
  const _CompactForMobile({required this.child});

  @override
  Widget build(BuildContext context) {
    final base  = Theme.of(context);
    final media = MediaQuery.of(context);

    // kecilkan seluruh tipografi & padding di phone
    final tScale = media.textScaleFactor * context.uiScale;

    return MediaQuery(
      data: media.copyWith(
        textScaleFactor: tScale.clamp(0.78, 1.0),
        // small devices sering overflow atas/bawah
        viewPadding: media.viewPadding,
        viewInsets: media.viewInsets,
      ),
      child: Theme(
        data: base.copyWith(
          visualDensity: const VisualDensity(horizontal: -1, vertical: -1),
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          appBarTheme: base.appBarTheme.copyWith(
            toolbarHeight: context.pick(mobile: 56.0, tablet: 72.0, desktop: 92.0),
            titleTextStyle: TextStyle(
              fontSize: context.pick(mobile: 16.0, tablet: 18.0, desktop: 22.0),
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
            elevation: 0,
            backgroundColor: Colors.transparent,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
              padding: WidgetStatePropertyAll(EdgeInsets.symmetric(
                horizontal: context.pick(mobile: 12, tablet: 14, desktop: 16),
                vertical: context.pick(mobile: 8, tablet: 10, desktop: 12),
              )),
              minimumSize: const WidgetStatePropertyAll(Size(0, 36)),
              shape: const WidgetStatePropertyAll(StadiumBorder()),
              textStyle: WidgetStatePropertyAll(TextStyle(
                fontSize: context.pick(mobile: 12.0, tablet: 13.0, desktop: 14.0),
                fontWeight: FontWeight.w700,
              )),
            ),
          ),
          filledButtonTheme: FilledButtonThemeData(
            style: ButtonStyle(
              padding: WidgetStatePropertyAll(EdgeInsets.symmetric(
                horizontal: context.pick(mobile: 12, tablet: 14, desktop: 16),
                vertical: context.pick(mobile: 8, tablet: 10, desktop: 12),
              )),
              minimumSize: const WidgetStatePropertyAll(Size(0, 36)),
              shape: const WidgetStatePropertyAll(StadiumBorder()),
              textStyle: WidgetStatePropertyAll(TextStyle(
                fontSize: context.pick(mobile: 12.0, tablet: 13.0, desktop: 14.0),
                fontWeight: FontWeight.w700,
              )),
            ),
          ),
          outlinedButtonTheme: OutlinedButtonThemeData(
            style: ButtonStyle(
              padding: WidgetStatePropertyAll(EdgeInsets.symmetric(
                horizontal: context.pick(mobile: 12, tablet: 14, desktop: 16),
                vertical: context.pick(mobile: 8, tablet: 10, desktop: 12),
              )),
              minimumSize: const WidgetStatePropertyAll(Size(0, 36)),
              shape: const WidgetStatePropertyAll(StadiumBorder()),
              textStyle: WidgetStatePropertyAll(TextStyle(
                fontSize: context.pick(mobile: 12.0, tablet: 13.0, desktop: 14.0),
                fontWeight: FontWeight.w700,
              )),
            ),
          ),
          inputDecorationTheme: base.inputDecorationTheme.copyWith(
            isDense: true,
            contentPadding: EdgeInsets.symmetric(
              horizontal: context.pick(mobile: 12, tablet: 14, desktop: 16),
              vertical: context.pick(mobile: 10, tablet: 12, desktop: 14),
            ),
          ),
          chipTheme: base.chipTheme.copyWith(
            labelStyle: TextStyle(
              fontSize: context.pick(mobile: 11.0, tablet: 12.0, desktop: 13.0),
              fontWeight: FontWeight.w600,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          ),
        ),
        child: child,
      ),
    );
  }
}

// --- Formatter Rupiah global (bisa dipakai dari mana saja)
final NumberFormat _rupiahFmt =
NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

String rupiah(num v) => _rupiahFmt.format(v);

// ---------- KARTU LAPORAN (modern) ----------
Widget _buildLaporanCard({
  required String title,
  required String subtitle,
  required VoidCallback onDetailPressed,
  IconData icon = Icons.insert_chart_rounded,
  Color accentColor = const Color(0xFF14B8A6), // teal default
}) {
  return Material(
    color: Colors.transparent,
    child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onDetailPressed,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          // gradasi halus biar berasa modern
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.white, Color(0xFFFFF5F7)],
          ),
          border: Border.all(color: Colors.black.withOpacity(0.06)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 14,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            // lingkaran icon aksen
            Container(
              height: 56,
              width: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: accentColor.withOpacity(.12),
              ),
              child: Icon(icon, color: accentColor, size: 28),
            ),
            const SizedBox(width: 14),
            // judul + subjudul
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      letterSpacing: .2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 13.5,
                      height: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // tombol detail (tetap ada)
            TextButton.icon(
              onPressed: onDetailPressed,
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                foregroundColor: Colors.black87,
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: BorderSide(color: Colors.black.withOpacity(.10)),
                ),
              ),
              icon: const Icon(Icons.chevron_right_rounded, size: 20),
              label: const Text('Detail', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    ),
  );
}

class Dashboardusaha extends StatefulWidget {
  final String idUsaha;
  final String namausaha;

  const Dashboardusaha({
    super.key,
    required this.idUsaha,
    required this.namausaha,
  });

  @override
  State<Dashboardusaha> createState() => _DashboardusahaState();
}

class _DashboardusahaState extends State<Dashboardusaha> {
  // ====== SUPABASE ======
  final _supabase = Supabase.instance.client;

  // ===== Rekap Transaksi (mutasi-style ala LB) =====
  bool _rtSelectMode = false;                // ⬅️ NEW
  final Set<String> _rtSelectedDates = {};   // ⬅️ NEW, simpan 'yyyy-MM-dd'

  // ====== STATE LAINNYA ======
  int _selectedIndex = 0;

  // (ganti) key export chart untuk Omzet & Laba Bersih
  final GlobalKey _chartKeyOmzet = GlobalKey();
  final GlobalKey _chartKeyLaba = GlobalKey();

  final logService = LogService();

  late final String usahaIdKamu;
  late final String namausahaKamu;
  String? userEmail;

  DateTime? _startDate;
  DateTime? _endDate;
  String _rangePreset = 'all'; // preset: all|month|100

  String _rtPeriodeLabel() {
    final f = DateFormat('d MMM yyyy', 'id_ID');
    if (_rtStartDate == null && _rtEndDate == null) return 'Semua';
    final s = _rtStartDate != null ? f.format(_rtStartDate!) : 'Semua';
    final e = _rtEndDate != null ? f.format(_rtEndDate!) : 'Semua';
    return '$s — $e';
  }

  final List<Map<String, dynamic>> _navItems = [
    {'label': 'Dashboard', 'icon': Icons.dashboard},
    {'label': 'Laporan', 'icon': Icons.insert_chart},
    {'label': 'Mato Karyawan', 'icon': Icons.pie_chart},
  ];

  // ===== Rekap Transaksi (mutasi-style ala LB) =====
  final _rtFmtDate = DateFormat('d MMM yyyy', 'id_ID');
  final _rtFmtIso = DateFormat('yyyy-MM-dd');
  final _rtFmtCur = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  DateTime? _rtStartDate;
  DateTime? _rtEndDate;

  List<Map<String, dynamic>> _rtRows = [];
  bool _rtLoading = false;

  Widget _forceLightDatePicker(BuildContext ctx, Widget? child) {
    final base = Theme.of(ctx);
    return Theme(
      data: base.copyWith(
        brightness: Brightness.light,
        colorScheme: base.colorScheme.copyWith(brightness: Brightness.light),
        textTheme: base.textTheme.apply(
          bodyColor: Colors.black87,
          displayColor: Colors.black87,
        ),
      ),
      child: child!,
    );
  }

  final _rtHHeader = ScrollController();
  final _rtHBody = ScrollController();
  final _rtVBody = ScrollController();

  final List<String> _rtHeaders = const [
    'Tanggal',
    'Penjualan',
    'Beban Usaha',
    'Laba Kotor',
    'Keterangan',
    'Aksi',
  ];
  final List<double> _rtBaseWidths = const [
    160, // Tanggal
    180, // Penjualan
    180, // Beban Usaha
    180, // Total
    280, // Keterangan
    160, // Aksi
  ];

  bool _welcomeShown = false;

  Future<void> _rtDeleteAll() async {
    if (_rtStartDate == null || _rtEndDate == null) {
      PopNotifier.I.show(context,
          title: 'Pilih rentang tanggal',
          message: 'Silakan pilih rentang tanggal dulu sebelum hapus semua.',
          type: NoticeType.info, duration: const Duration(seconds: 2));
      return;
    }
    if (_rtRows.isEmpty) {
      PopNotifier.I.show(context,
          title: 'Tidak ada data',
          message: 'Tidak ada data pada periode ini.',
          type: NoticeType.info, duration: const Duration(seconds: 2));
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus semua data?'),
        content: Text('Semua transaksi harian pada periode ${_rtPeriodeLabel()} akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _rtFmtIso.format(_rtStartDate!))
          .lte('tanggal', _rtFmtIso.format(_rtEndDate!));

      PopNotifier.I.show(context,
          title: 'Berhasil',
          message: 'Semua data pada periode ini dihapus.',
          type: NoticeType.success, duration: const Duration(seconds: 2));
      _rtSelectedDates.clear();
      _rtSelectMode = false;
      await _fetchMutasiData();
    } catch (e) {
      PopNotifier.I.show(context,
          title: 'Gagal hapus',
          message: '$e',
          type: NoticeType.error, duration: const Duration(seconds: 2));
    }
  }

  Future<void> _rtDeleteSelected() async {
    if (_rtSelectedDates.isEmpty) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus data terpilih?'),
        content: Text('${_rtSelectedDates.length} tanggal akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_usaha', widget.idUsaha)
          .inFilter('tanggal', _rtSelectedDates.toList());

      _rtSelectedDates.clear();
      _rtSelectMode = false;

      PopNotifier.I.show(context,
          title: 'Berhasil',
          message: 'Data terpilih dihapus.',
          type: NoticeType.success, duration: const Duration(seconds: 2));
      await _fetchMutasiData();
    } catch (e) {
      PopNotifier.I.show(context,
          title: 'Gagal hapus',
          message: '$e',
          type: NoticeType.error, duration: const Duration(seconds: 2));
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    AppBackground.precacheAll(context);
    if (_welcomeShown) return;

    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is Map && args['showWelcome'] == true) {
      // jalankan setelah frame supaya pasti punya Overlay
      WidgetsBinding.instance.addPostFrameCallback((_) {
        PopNotifier.I.show(
          context,
          title: 'Berhasil',
          message: 'Login berhasil. Selamat datang!',
          type: NoticeType.success,
          duration: const Duration(seconds: 2),
        );
      });
    }
    _welcomeShown = true;
  }

  // === Edit Nama usaha dan Lokasi usaha ===
  final TextEditingController _namausahaCtrl = TextEditingController();
  final TextEditingController _lokasiusahaCtrl = TextEditingController();
  String? _namausahaDb;
  String? _lokasiusahaDb;
  bool _savingNamausaha = false;

  Future<void> _loadNamausaha() async {
    try {
      final row = await _supabase
          .from('usaha')
          .select('nama_usaha, lokasi')
          .eq('id_usaha', widget.idUsaha)
          .maybeSingle();

      setState(() {
        _namausahaDb   = (row?['nama_usaha'] as String?)?.trim();
        _lokasiusahaDb = (row?['lokasi'] as String?)?.trim();
        _namausahaCtrl.text   = _namausahaDb ?? widget.namausaha;
        _lokasiusahaCtrl.text = _lokasiusahaDb ?? '';
      });
    } catch (_) {
      setState(() {
        _namausahaDb = widget.namausaha;
        _lokasiusahaDb = null;
        _namausahaCtrl.text = _namausahaDb!;
      });
    }
  }

  Future<void> _showEditNamausahaDialog() async {
    // nilai awal
    final initNama   = _namausahaDb ?? widget.namausaha;
    final initLokasi = _lokasiusahaDb ?? '';

    // controller LOKAL (tidak ikut dispose halaman → anti-glitch saat rotate)
    final namaC   = TextEditingController(text: initNama);
    final lokasiC = TextEditingController(text: initLokasi);

    const double _btnH = 44;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (dialogCtx, setLocal) => Dialog(
            insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: SafeArea(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: 560,
                  maxHeight: MediaQuery.of(dialogCtx).size.height * 0.9,
                ),
                child: SingleChildScrollView(
                  padding: EdgeInsets.only(
                    left: 20, right: 20, top: 20,
                    bottom: 12 + MediaQuery.of(dialogCtx).viewInsets.bottom,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'Ubah nama & lokasi usaha *',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 16),

                      // Nama
                      TextField(
                        controller: namaC,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          hintText: 'NAMA USAHA',
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(30)),
                            borderSide: BorderSide(color: Colors.black, width: 1.2),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Lokasi
                      TextField(
                        controller: lokasiC,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _saveNamausaha(dialogCtx, setLocal, namaC, lokasiC),
                        decoration: InputDecoration(
                          hintText: 'LOKASI (mis. ANCOL)',
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.black.withOpacity(.15)),
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(30)),
                            borderSide: BorderSide(color: Colors.black, width: 1.2),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),

                      // Tombol
                      Row(
                        children: [
                          Expanded(
                            child: SizedBox(
                              height: _btnH,
                              child: OutlinedButton(
                                onPressed: () => Navigator.of(dialogCtx).pop(),
                                style: OutlinedButton.styleFrom(
                                  shape: const StadiumBorder(),
                                  side: const BorderSide(color: Colors.black87, width: 1),
                                ),
                                child: const Text('Batal'),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: SizedBox(
                              height: _btnH,
                              child: FilledButton(
                                onPressed: _savingNamausaha
                                    ? null
                                    : () => _saveNamausaha(dialogCtx, setLocal, namaC, lokasiC),
                                style: FilledButton.styleFrom(
                                  shape: const StadiumBorder(),
                                  backgroundColor: Colors.black87,
                                  foregroundColor: Colors.white,
                                ),
                                child: _savingNamausaha
                                    ? const SizedBox(
                                  width: 18, height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                                    : const Text('Simpan'),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _saveNamausaha(
      BuildContext dialogCtx,
      StateSetter setLocal,
      TextEditingController namaC,
      TextEditingController lokasiC,
      ) async {
    final nama   = namaC.text.trim();
    final lokasi = lokasiC.text.trim();

    // Validasi
    if (nama.isEmpty || lokasi.isEmpty) {
      PopNotifier.I.show(
        context,
        title: 'Form belum lengkap',
        message: 'Nama usaha dan lokasi tidak boleh kosong.',
        type: NoticeType.warning,
        duration: const Duration(seconds: 2),
      );
      return;
    }

    setLocal(() => _savingNamausaha = true);
    try {
      await _supabase
          .from('usaha')
          .update({
        'nama_usaha': nama,
        'lokasi': lokasi,
        'updated_at': DateTime.now().toIso8601String(),
      })
          .eq('id_usaha', widget.idUsaha);

      if (!mounted) return;
      setState(() {
        _namausahaDb   = nama;
        _lokasiusahaDb = lokasi;
      });

      if (dialogCtx.mounted) {
        Navigator.of(dialogCtx).pop(); // tutup dialog
      }

      PopNotifier.I.show(
        context,
        title: 'Tersimpan',
        message: 'Nama & lokasi usaha sudah diperbarui.',
        type: NoticeType.success,
        duration: const Duration(seconds: 2),
      );
    } catch (e) {
      PopNotifier.I.show(
        context,
        title: 'Gagal menyimpan',
        message: 'Terjadi error: $e',
        type: NoticeType.error,
        duration: const Duration(seconds: 2),
      );
    } finally {
      if (dialogCtx.mounted) {
        setLocal(() => _savingNamausaha = false);
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _loadNamausaha();
    usahaIdKamu = widget.idUsaha;
    namausahaKamu = widget.namausaha;
    userEmail = Supabase.instance.client.auth.currentUser?.email;

    // Rekap Transaksi default = bulan ini
    final now = DateTime.now();
    _rtStartDate = DateTime(now.year, now.month, 1);
    _rtEndDate = DateTime(now.year, now.month + 1, 0);

    // sinkron scroll header <-> body
    _rtHHeader.addListener(() {
      if (_rtHBody.hasClients && _rtHBody.offset != _rtHHeader.offset) {
        _rtHBody.jumpTo(_rtHHeader.offset);
      }
    });
    _rtHBody.addListener(() {
      if (_rtHHeader.hasClients && _rtHHeader.offset != _rtHBody.offset) {
        _rtHHeader.jumpTo(_rtHBody.offset);
      }
    });

    _fetchMutasiData();

    Supabase.instance.client.rpc('whoami').then((who) {
      debugPrint('whoami: $who');
    });
  }

  @override
  void dispose() {
    _rtHHeader.dispose();
    _rtHBody.dispose();
    _rtVBody.dispose();
    super.dispose();
  }

  // ================== DATA DASBOR (BARU): OMZET & LABA BERSIH ==================
  Future<List<Map<String, dynamic>>> _fetchRekapOmzetHarian() async {
    try {
      var qb = _supabase
          .from('rekap_omzet_harian')
          .select('tanggal, id_usaha, total_omzet')
          .eq('id_usaha', widget.idUsaha);

      if (_startDate != null) {
        qb = qb.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }
      if (_endDate != null) {
        qb = qb.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final res = await qb.order('tanggal', ascending: true);
      return List<Map<String, dynamic>>.from(res);
    } catch (e) {
      debugPrint('❌ Error fetch rekap_omzet_harian: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> _fetchRekapLabaBersih() async {
    try {
      var qb = _supabase
          .from('rekap_laba_bersih')
          .select('tanggal, id_usaha, total_laba_bersih')
          .eq('id_usaha', widget.idUsaha);

      if (_startDate != null) {
        qb = qb.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }
      if (_endDate != null) {
        qb = qb.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final res = await qb.order('tanggal', ascending: true);
      return List<Map<String, dynamic>>.from(res);
    } catch (e) {
      debugPrint('❌ Error fetch rekap_laba_bersih: $e');
      return [];
    }
  }

  // ================== REKAP TRANSAKSI (mutasi ala LB) ==================
  num _rtNum(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  Future<void> _fetchMutasiData() async {
    if (_rtStartDate == null || _rtEndDate == null) {
      setState(() => _rtRows = []);
      return;
    }
    setState(() => _rtLoading = true);

    try {
      final data = await Supabase.instance.client
          .from('transaksi_harian')
          .select('tanggal, jumlah, keterangan')
          .eq('id_usaha', widget.idUsaha)
          .gte('tanggal', _rtFmtIso.format(_rtStartDate!))
          .lte('tanggal', _rtFmtIso.format(_rtEndDate!))
          .order('tanggal');

      final list = List<Map<String, dynamic>>.from(data);

      final Map<String, Map<String, dynamic>> agg = {};
      for (final row in list) {
        final String t = (row['tanggal'] ?? '').toString().substring(0, 10); // yyyy-MM-dd
        final num j = _rtNum(row['jumlah']);
        final String ket = (row['keterangan'] ?? '').toString().trim();

        agg.putIfAbsent(t, () => {
          'tanggal': t,
          'penjualan': 0,
          'beban_usaha': 0,
          'total': 0,
          'notes': <String>{},
        });

        if (j >= 0) {
          agg[t]!['penjualan'] = (agg[t]!['penjualan'] as num) + j;
        } else {
          agg[t]!['beban_usaha'] = (agg[t]!['beban_usaha'] as num) + (-j); // simpan positif
        }
        agg[t]!['total'] = (agg[t]!['total'] as num) + j;

        if (ket.isNotEmpty) {
          (agg[t]!['notes'] as Set<String>).add(ket);
        }
      }

      final rows = agg.values.toList()
        ..sort((a, b) => a['tanggal'].toString().compareTo(b['tanggal'].toString()));

      // gabungkan notes jadi string
      final rtRows = rows.map((m) {
        final notesSet = (m['notes'] as Set<String>);
        String ket = notesSet.take(3).join(' • ');
        if (ket.length > 120) ket = '${ket.substring(0, 120)}…';
        return {
          'tanggal': m['tanggal'],
          'penjualan': m['penjualan'],
          'beban_usaha': m['beban_usaha'],
          'total': m['total'],
          'keterangan': ket.isEmpty ? '—' : ket,
        };
      }).toList();

      setState(() => _rtRows = rtRows);
      if (_rtVBody.hasClients) _rtVBody.jumpTo(0);
    } catch (e) {
      if (!mounted) return;
      // CHANGED: SnackBar -> PopNotifier (2 detik)
      PopNotifier.I.show(
        context,
        title: 'Gagal memuat',
        message: 'Tidak dapat memuat transaksi: $e',
        type: NoticeType.error,
        duration: const Duration(seconds: 2),
      );
    } finally {
      if (mounted) setState(() => _rtLoading = false);
    }
  }

  Future<void> _rtOpenRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _rtStartDate ?? DateTime(now.year, now.month, 1),
      end: _rtEndDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _rtStartDate = picked.start;
        _rtEndDate = picked.end;
      });
      _fetchMutasiData();
    }
  }

  Future<void> _rtPickDate({required bool isStart}) async {
    final now = DateTime.now();
    final init = isStart ? (_rtStartDate ?? now) : (_rtEndDate ?? _rtStartDate ?? now);

    final picked = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1, 12, 31),
      builder: (ctx, child) => Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );
    if (picked == null) return;

    setState(() {
      if (isStart) {
        _rtStartDate = picked;
        if (_rtEndDate != null && _rtEndDate!.isBefore(_rtStartDate!)) {
          _rtEndDate = _rtStartDate;
        }
      } else {
        _rtEndDate = picked;
        if (_rtStartDate != null && _rtStartDate!.isAfter(_rtEndDate!)) {
          _rtStartDate = _rtEndDate;
        }
      }
    });

    _fetchMutasiData();
  }

  void _rtClearDates() {
    setState(() {
      _rtStartDate = null;
      _rtEndDate = null;
      _rtRows = [];
    });
  }

  Future<void> _rtApplyPreset(String code) async {
    final now = DateTime.now();
    if (code == 'all') {
      setState(() {
        _rtStartDate = DateTime(2020, 1, 1);
        _rtEndDate = now;
      });
    } else if (code == 'month') {
      setState(() {
        _rtStartDate = DateTime(now.year, now.month, 1);
        _rtEndDate = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '100') {
      setState(() {
        _rtStartDate = now.subtract(const Duration(days: 99));
        _rtEndDate = now;
      });
    }
    await _fetchMutasiData();
  }

  Widget _rtCapsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4)),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _rtCellText(String text, {TextAlign align = TextAlign.center}) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Text(
        text,
        textAlign: align,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }

  Widget _miniIconBtn({
    required IconData icon,
    required VoidCallback onPressed,
    Color? color,
    String? tooltip,
  }) {
    return IconButton(
      tooltip: tooltip,
      onPressed: onPressed,
      icon: Icon(icon, size: 18, color: color),
      style: IconButton.styleFrom(
        padding: EdgeInsets.zero,
        minimumSize: const Size(32, 32), // << kecil
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
      visualDensity: const VisualDensity(horizontal: -4, vertical: -4), // << padat
    );
  }

  // ================== UI ==================
  @override
  Widget build(BuildContext context) {
    final namaUsahaUpper = (_namausahaDb ?? widget.namausaha).toUpperCase();

    // Paksa LIGHT di halaman ini (teks & ikon default hitam)
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      iconTheme: const IconThemeData(color: Colors.black87),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
      ),
    );

    return Theme(
      data: forceLight,
      child: _CompactForMobile(
        // <-- bungkus compact khusus mobile
        child: Scaffold(
          extendBodyBehindAppBar: true,
          backgroundColor: Colors.transparent,

          appBar: PreferredSize(
            preferredSize: Size.fromHeight(context.isMobile ? 64 : 100), // tinggi adaptif
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: context.isMobile ? 16 : 24,
                  vertical: context.isMobile ? 8 : 12,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // tombol drawer
                    Builder(
                      builder: (ctx) => IconButton(
                        icon: Icon(
                          Icons.menu,
                          size: context.isMobile ? 28 : 34,
                          color: Colors.black, // pastikan hitam
                        ),
                        onPressed: () => Scaffold.of(ctx).openDrawer(),
                      ),
                    ),
                    const SizedBox(width: 16),

                    // logo + nama usaha
                    Expanded(
                      child: Row(
                        children: [
                          Image.asset(
                            'assets/InmatoID_logo.png',
                            height: context.isMobile ? 52 : 85,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              namaUsahaUpper,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.black, // pastikan hitam
                                fontSize: context.isMobile ? 16 : 30,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // actions kanan
                    IconButton(
                      icon: Icon(
                        Icons.refresh,
                        size: context.isMobile ? 18 : 20,
                        color: Colors.black,
                      ),
                      tooltip: 'Refresh',
                      onPressed: () async {
                        await _fetchProfile();
                        await _loadNamausaha();
                        if (!mounted) return;
                        setState(() {});
                        PopNotifier.I.show(
                          context,
                          title: 'Berhasil',
                          message: 'Halaman sudah di-refresh.',
                          type: NoticeType.success,
                          duration: const Duration(seconds: 2),
                        );
                      },
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'ADMIN',
                      style: TextStyle(
                        fontSize: context.isMobile ? 14 : 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.black, // pastikan hitam
                      ),
                    ),
                    SizedBox(width: context.isMobile ? 12 : 20),
                  ],
                ),
              ),
            ),
          ),

          // === Drawer ===
          drawer: Drawer(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _FancyDrawerHeader(
                  namaUsaha: (_namausahaDb ?? widget.namausaha).toUpperCase(),
                  email: userEmail ?? 'Email tidak tersedia',
                  role: 'ADMIN USAHA',
                  usaha: (_lokasiusahaDb ?? '—').toUpperCase(),
                  photoUrl: Supabase.instance.client.auth.currentUser?.userMetadata?['avatar_url'],
                  onTapEditUsaha: () {
                    Navigator.pop(context);
                    _showEditNamausahaDialog();
                  },
                  onTapSettings: () {
                    Navigator.pop(context);
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                const SizedBox(height: 6),

                _DrawerItem(
                  icon: Icons.home_rounded,
                  label: 'Beranda',
                  active: _selectedIndex == 0,
                  onTap: () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 0);
                  },
                ),
                _DrawerItem(
                  icon: Icons.payments_rounded,
                  label: 'Input Beban Pokok Penjualan',
                  onTap: () {
                    Navigator.pop(context);
                    Future.delayed(const Duration(milliseconds: 300), () {
                      Navigator.pushNamed(
                        context,
                        '/input-omzet',
                        arguments: {
                          'idUsaha': widget.idUsaha,
                          'namausaha': _namausahaDb ?? widget.namausaha,
                        },
                      );
                    });
                  },
                ),
                _DrawerItem(
                  icon: Icons.inventory_2_rounded,
                  label: 'Input Persedian Bahan Pokok',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => InputPBP(idUsaha: widget.idUsaha)),
                    );
                  },
                ),
                _DrawerItem(
                  icon: Icons.receipt_long_rounded,
                  label: 'Input Penjualan & Beban Usaha',
                  onTap: () {
                    Navigator.pop(context);
                    Future.delayed(const Duration(milliseconds: 300), () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => InputTransaksiPage(usahaId: widget.idUsaha),
                        ),
                      );
                    });
                  },
                ),
                _DrawerItem(
                  icon: Icons.insights_rounded,
                  label: 'Penetapan Laba Bersih',
                  onTap: () {
                    Navigator.pop(context);
                    Future.delayed(const Duration(milliseconds: 300), () {
                      final usahaId = widget.idUsaha;
                      final tanggal = DateTime.now();
                      Navigator.pushNamed(
                        context,
                        '/input-laba',
                        arguments: {'idUsaha': usahaId, 'tanggal': tanggal},
                      );
                    });
                  },
                ),
                _DrawerItem(
                  icon: Icons.inventory_2_rounded,
                  label: 'Update Income Per Mato',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => InputIncomeMato(idUsaha: widget.idUsaha),
                      ),
                    );
                  },
                ),

                const Divider(height: 24, indent: 16, endIndent: 16),

                _DrawerItem(
                  icon: Icons.history_rounded,
                  label: 'Log Aktivitas',
                  onTap: () =>
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const LogPage())),
                ),
                _DrawerItem(
                  icon: Icons.feedback_rounded,
                  label: 'Kirim Feedback',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => FeedbackPage(idUsaha: widget.idUsaha)),
                    );
                  },
                ),

                const SizedBox(height: 8),
                _DrawerItem(
                  icon: Icons.logout_rounded,
                  label: 'Keluar',
                  danger: true,
                  onTap: () async {
                    final supabase = Supabase.instance.client;
                    final user = supabase.auth.currentUser;
                    if (user != null) {
                      final userData = await supabase
                          .from('profiles')
                          .select('nama, role')
                          .eq('id', user.id)
                          .maybeSingle();
                      if (userData != null) {
                        final nama = userData['nama'];
                        final role = userData['role'];
                        await logService.addLog(
                          aktivitas: "Logout",
                          halaman: "Auth",
                          detail: "User $nama ($role) melakukan logout",
                        );
                      }
                    }
                    await supabase.auth.signOut();
                    if (context.mounted) {
                      Navigator.pushReplacementNamed(context, '/login');
                    }
                  },
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),

          // === BODY ===
          body: AppBackground(
            overlayLight: true, // lapisan putih tipis agar kontras enak
            overlayOpacity: 0.22, // 0.18–0.28 biasanya pas
            child: LayoutBuilder(
              builder: (ctx, cons) {
                return SafeArea(
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: cons.maxHeight),
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: ctx.pick(mobile: 12.0, tablet: 16.0, desktop: 24.0),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            SizedBox(height: ctx.pick(mobile: 12.0, tablet: 16.0, desktop: 20.0)),

                            // NAV BUTTONS (Wrap)
                            Wrap(
                              spacing: ctx.pick(mobile: 10.0, tablet: 16.0, desktop: 20.0),
                              runSpacing: ctx.pick(mobile: 10.0, tablet: 12.0, desktop: 16.0),
                              alignment: WrapAlignment.center,
                              children: List.generate(
                                _navItems.length,
                                    (i) => _buildNavButton(i),
                              ),
                            ),

                            SizedBox(height: ctx.pick(mobile: 16.0, tablet: 22.0, desktop: 30.0)),

                            // KONTEN TAB
                            _buildContent(),

                            SizedBox(height: ctx.pick(mobile: 16.0, tablet: 20.0, desktop: 24.0)),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // === Floating Helper Button ===
          floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
          floatingActionButton: FloatingHelperButton(
            pageTitle: 'Panduan Dashboard Usaha',
            items: const [
              HelperItem(
                title: 'Panduan Teks',
                description: 'Penggunaan Aplikasi Inmato.ID dalam bentuk teks.',
                url: 'https://drive.google.com/file/d/11YDrXjm5F62432s0tpAwFLdb4G2sm_S_/view?usp=sharing',
                type: HelperType.text,
              ),
              HelperItem(
                title: 'Panduan Video',
                description: 'Penggunaan Aplikasi Inmato.ID dalam bentuk video.',
                url: 'https://drive.google.com/file/d/1QcYwEqy_cSKtQdmNlNVeInabH0R9eGAz/view?usp=sharing',       // ganti
                type: HelperType.video,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================== BAGIAN DASHBOARD ==================
  Widget _buildLaporanTab(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: context.isMobile ? 4 : 0),
        child: Column(
          children: [
            _buildLaporanCard(
              title: "Laporan Income per mato",
              subtitle: "Rekap Income per mato",
              onDetailPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LaporanIncomeMatoPage(idUsaha: widget.idUsaha),
                  ),
                );
              },
            ),
            SizedBox(height: context.isMobile ? 10 : 16),
            _buildLaporanCard(
              title: "Laporan Laba Bersih",
              subtitle: "Mutasi laba bersih per hari",
              onDetailPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LaporanLBPage(idUsaha: widget.idUsaha),
                  ),
                );
              },
            ),
            SizedBox(height: context.isMobile ? 10 : 16),
            _buildLaporanCard(
              title: "Laporan Persediaan Bahan Pokok",
              subtitle: "Analisa pemakaian barang",
              onDetailPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LaporanStok(idUsaha: widget.idUsaha),
                  ),
                );
              },
            ),
            SizedBox(height: context.isMobile ? 10 : 16),
            _buildLaporanCard(
              title: "Laporan Penjualan & Beban Usaha",
              subtitle: "Ringkasan penjualan & beban usaha (mutasi harian)",
              onDetailPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LaporanTransaksiPage(idUsaha: widget.idUsaha),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(int index) {
    final isSelected = _selectedIndex == index;
    final w = context.pick<double>(mobile: context.isPhonePortrait ? 160 : 180, tablet: 200, desktop: 220);
    final h = context.pick<double>(mobile: 40, tablet: 44, desktop: 48);

    return SizedBox(
      width: w,
      height: h,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? const Color(0xFFFFC1CC) : Colors.white,
          foregroundColor: Colors.black,
          elevation: isSelected ? 4 : 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
        ),
        onPressed: () => setState(() => _selectedIndex = index),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_navItems[index]['icon'], size: context.pick(mobile: 18.0, tablet: 20.0, desktop: 22.0)),
            const SizedBox(width: 8),
            Text(_navItems[index]['label'], style: TextStyle(fontSize: context.pick(mobile: 13.0, tablet: 14.0, desktop: 16.0))),
          ],
        ),
      ),
    );
  }

  // === UTIL umum filter tanggal untuk list Map {'tanggal': 'yyyy-MM-dd', ...}
  List<Map<String, dynamic>> _applyDateFilter(List<Map<String, dynamic>> data) {
    return data.where((item) {
      try {
        final raw = item['tanggal'];
        DateTime tanggal;
        if (raw is DateTime) {
          tanggal = raw;
        } else {
          final s = (raw ?? '').toString();
          // ambil 10 char pertama kalau ada waktu/zonanya
          final iso = s.length >= 10 ? s.substring(0, 10) : s;
          tanggal = DateTime.parse(iso);
        }
        if (_startDate != null && tanggal.isBefore(_startDate!)) return false;
        if (_endDate != null && tanggal.isAfter(_endDate!)) return false;
        return true;
      } catch (_) {
        return false;
      }
    }).toList();
  }

  Widget _buildLineChart(
      List<Map<String, dynamic>> data, {
        required String valueKey,
        String yLabel = 'Omzet',
      }) {
    if (data.isEmpty) return const Center(child: Text("Tidak ada data"));

    // --- kumpulkan data unik per tanggal ---
    final Map<String, double> perTanggal = {};
    for (final item in data) {
      final tgl = (item['tanggal'] ?? '').toString();
      final val = (item[valueKey] as num?)?.toDouble() ?? 0.0;
      perTanggal[tgl] = (perTanggal[tgl] ?? 0) + val;
    }
    final List<String> dateKeys = perTanggal.keys.toList()..sort();

    final spots = List.generate(
      dateKeys.length,
          (i) => FlSpot(i.toDouble(), perTanggal[dateKeys[i]]!),
    );

    String _fmtShort(num v) {
      if (v.abs() >= 1e9) return 'Rp ${(v / 1e9).toStringAsFixed(2)} M';
      if (v.abs() >= 1e6) return 'Rp ${(v / 1e6).toStringAsFixed(2)} jt';
      if (v.abs() >= 1e3) return 'Rp ${(v / 1e3).toStringAsFixed(0)} rb';
      return 'Rp ${v.toStringAsFixed(0)}';
    }

    return LayoutBuilder(
      builder: (ctx, cons) {
        // ====== SPACING & SCROLL LOGIC ======
        final bool isPhone = MediaQuery.of(ctx).size.width < 600;
        final bool isPortrait =
            MediaQuery.of(ctx).orientation == Orientation.portrait;

        final double perPoint = isPhone ? (isPortrait ? 46 : 38) : 34;

        const double extraPaddingPx = 80; // total padding horizontal di dalam container
        final double wantWidth =
        max(cons.maxWidth, (dateKeys.length * perPoint) + extraPaddingPx);

        // ====== Sumbu X ======
        final double minX = -0.5;
        final double maxX = (dateKeys.length - 1) + 0.5;

        // ====== Sumbu Y (FIX) ======
        // hitung min/max dari data; kalau range terlalu kecil, beri padding supaya != 0
        double minY = spots.isNotEmpty
            ? spots.map((s) => s.y).reduce(min)
            : 0.0;
        double maxY = spots.isNotEmpty
            ? spots.map((s) => s.y).reduce(max)
            : 0.0;

        if (!minY.isFinite || !maxY.isFinite || (maxY - minY).abs() < 1e-9) {
          minY = minY - 1;
          maxY = maxY + 1;
        }

        // interval grid horizontal berdasarkan range Y (BUKAN X)
        double _niceInterval(double range) {
          if (range <= 0) return 1;
          final raw = range / 5; // kira-kira 5 garis grid
          final exp = pow(10, (log(raw) / ln10).floor());
          final f = raw / exp;
          double nice;
          if (f < 1.5) {
            nice = 1;
          } else if (f < 3) {
            nice = 2;
          } else if (f < 7) {
            nice = 5;
          } else {
            nice = 10;
          }
          return nice * exp;
        }

        final double hInterval = _niceInterval(maxY - minY);

        // maksimalkan jumlah label bawah agar tidak bertumpuk
        final int maxXTicks = isPhone ? 6 : 8;
        final int step =
        dateKeys.isEmpty ? 1 : max(1, (dateKeys.length / maxXTicks).ceil());

        final chart = Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.06),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
            border: Border.all(color: Colors.black.withOpacity(.06)),
          ),
          width: wantWidth, // memicu scroll horizontal bila > layar
          child: SizedBox(
            height: isPhone ? 260.0 : 320.0,
            child: LineChart(
              LineChartData(
                minX: minX,
                maxX: maxX,
                minY: minY,     // <- pakai minY hasil hitung
                maxY: maxY,     // <- pakai maxY hasil hitung

                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: hInterval, // <- interval aman (tak nol)
                  getDrawingHorizontalLine: (v) => FlLine(
                    color: const Color(0xFFE5E7EB),
                    strokeWidth: 1,
                    dashArray: const [6, 6],
                  ),
                ),

                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    axisNameWidget: const Padding(
                      padding: EdgeInsets.only(right: 12),
                      child:
                      Text('Omzet', style: TextStyle(fontWeight: FontWeight.w700)),
                    ),
                    axisNameSize: 24,
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: isPhone ? 64 : 68,
                      getTitlesWidget: (value, meta) =>
                          Text(_fmtShort(value), style: const TextStyle(fontSize: 11)),
                    ),
                  ),
                  rightTitles:
                  const AxisTitles(sideTitles: SideTitles(showTitles: false)),

                  bottomTitles: AxisTitles(
                    axisNameWidget: const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text('Tanggal',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                    ),
                    axisNameSize: 24,
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: isPhone ? 36 : 38,
                      interval: 1,
                      getTitlesWidget: (value, meta) {
                        final i = value.round();
                        if (i < 0 || i >= dateKeys.length) {
                          return const SizedBox.shrink();
                        }
                        if (i % step != 0) return const SizedBox.shrink();

                        final s = DateFormat('dd MMM', 'id_ID')
                            .format(DateTime.parse(dateKeys[i]));
                        return Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            s,
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                        );
                      },
                    ),
                  ),
                  topTitles:
                  const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),

                borderData: FlBorderData(
                  show: true,
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                ),

                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    barWidth: 3,
                    color: const Color(0xFF14B8A6),
                    belowBarData: BarAreaData(
                      show: true,
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          const Color(0xFF14B8A6).withOpacity(.25),
                          const Color(0xFF14B8A6).withOpacity(.05),
                        ],
                      ),
                    ),
                    dotData: FlDotData(
                      show: true,
                      getDotPainter: (spot, p, bar, i) => FlDotCirclePainter(
                        radius: 3.8,
                        color: Colors.white,
                        strokeWidth: 2.5,
                        strokeColor: const Color(0xFF0EA5A4),
                      ),
                    ),
                  ),
                ],

                lineTouchData: LineTouchData(
                  handleBuiltInTouches: true,
                  touchTooltipData: LineTouchTooltipData(
                    tooltipBorderRadius: BorderRadius.circular(10),
                    tooltipPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    getTooltipColor: (_) => const Color(0xFF1F2937),
                    fitInsideHorizontally: true,
                    fitInsideVertically: true,
                    getTooltipItems: (touchedSpots) => touchedSpots.map((ts) {
                      final i = ts.x.round().clamp(0, dateKeys.length - 1);
                      final tanggal = DateFormat('d MMM yyyy', 'id_ID')
                          .format(DateTime.parse(dateKeys[i]));
                      final nilai = _fmtShort(ts.y);
                      return LineTooltipItem(
                        '$tanggal\n',
                        const TextStyle(
                            fontSize: 11,
                            color: Colors.white70,
                            fontWeight: FontWeight.w600),
                        children: [
                          TextSpan(
                            text: nilai,
                            style: const TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                                fontWeight: FontWeight.w800),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        );

        // ====== hanya scroll X bila perlu ======
        if (wantWidth > cons.maxWidth) {
          return Scrollbar(
            thumbVisibility: true,
            interactive: true,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: chart,
            ),
          );
        }
        return chart;
      },
    );

  }

  Future<void> _exportChartToPdf(GlobalKey chartKey) async {
    final pdf = pw.Document();
    final image = await WidgetWraper.wrapWidgetToImage(chartKey);

    if (image != null) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) => pw.Center(child: pw.Image(pw.MemoryImage(image))),
        ),
      );
      await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdf.save());
    }
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 32),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // Awal
                    Expanded(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(40),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _startDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                            builder: _forceLightDatePicker, // ← paksa teks gelap
                          );
                          if (picked != null) setState(() => _startDate = picked);
                        },
                        child: _DatePill(
                          label: 'Tanggal Awal',
                          value: _startDate == null
                              ? 'Pilih tanggal'
                              : DateFormat('dd MMM yyyy', 'id_ID').format(_startDate!),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),

                    // Akhir
                    Expanded(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(40),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _endDate ?? (_startDate ?? DateTime.now()),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                            builder: _forceLightDatePicker,
                          );
                          if (picked != null) setState(() => _endDate = picked);
                        },
                        child: _DatePill(
                          label: 'Tanggal Akhir',
                          value: _endDate == null
                              ? 'Pilih tanggal'
                              : DateFormat('dd MMM yyyy', 'id_ID').format(_endDate!),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),

                    SizedBox(
                      height: 40,
                      child: ElevatedButton(
                        onPressed: () => setState(() {}),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFD5F5DD),
                          foregroundColor: const Color(0xFF166534),
                          elevation: 0,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                        ),
                        child: const Text('Tampilkan'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

// Preset chips — tetap sama
                Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    _PresetChipDash(text: 'Semua Data', selected: _rangePreset == 'all', onTap: () => _applyRangePreset('all')),
                    _PresetChipDash(text: 'Bulan Ini', selected: _rangePreset == 'month', onTap: () => _applyRangePreset('month')),
                    _PresetChipDash(text: '100 Hari Terakhir', selected: _rangePreset == '100', onTap: () => _applyRangePreset('100')),
                  ],
                ),

                const SizedBox(height: 24),

                // ====== GRAFIK OMZET (dari view rekap_omzet_harian) ======
                const Text('Grafik Omzet', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchRekapOmzetHarian(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat data omzet: ${snapshot.error}');
                    }
                    final filteredData = _applyDateFilter(snapshot.data ?? []);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(
                          key: _chartKeyOmzet,
                          child: _buildLineChart(filteredData, valueKey: 'total_omzet', yLabel: 'Omzet'),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeyOmzet),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export Grafik Omzet ke PDF'),
                        ),
                      ],
                    );
                  },
                ),

                const SizedBox(height: 32),

                // ====== GRAFIK LABA BERSIH (dari view rekap_laba_bersih) ======
                const Text('Grafik Laba Bersih', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchRekapLabaBersih(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat data laba bersih: ${snapshot.error}');
                    }
                    final filteredData = _applyDateFilter(snapshot.data ?? []);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(
                          key: _chartKeyLaba,
                          child: _buildLineChart(filteredData, valueKey: 'total_laba_bersih', yLabel: 'Laba Bersih'),
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeyLaba),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export Grafik Laba Bersih ke PDF'),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        );

      case 1:
        return _buildLaporanTab(context);

      case 2:
        return _buildMatoBoxList();

      default:
      // supaya switch SELALU mengembalikan widget
        return const SizedBox.shrink();
    }
  }

  Future<void> _applyRangePreset(String code) async {
    final now = DateTime.now();
    setState(() {
      _rangePreset = code;
      if (code == 'all') {
        _startDate = null;
        _endDate = null;
      } else if (code == 'month') {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      } else if (code == '100') {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      }
    });
  }

  Future<Map<String, dynamic>> _fetchProfile() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) throw Exception('User tidak login');

    final data =
    await Supabase.instance.client.from('profiles').select().eq('id', user.id).maybeSingle();

    if (data == null) throw Exception('Profil tidak ditemukan');
    return data;
  }

  // Widget seksi grup penjualan/beban usaha dengan daftar per-jenis
  Widget _groupSection({
    required String title,
    required Map<String, int> items,
    required Color color,
    required IconData icon,
  }) {
    final total = items.values.fold<int>(0, (a, b) => a + b);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const Spacer(),
              Text(
                rupiah(total),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color),
              ),
            ],
          ),
          const SizedBox(height: 10),

          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 6),
              child: Text('Tidak ada data', style: TextStyle(color: Colors.black54)),
            )
          else
            ...items.entries.map(
                  (e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        e.key,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                    ),
                    Text(
                      rupiah(e.value),
                      style: TextStyle(fontWeight: FontWeight.w700, color: color),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ==== Detail Transaksi Dialog ====
  Future<void> _showDetailTransaksi(BuildContext context, String tanggalIso) async {
    final breakdown = await _fetchKategoriBreakdown(tanggalIso);
    final tanggal = DateTime.parse(tanggalIso);
    final judul = DateFormat('d MMM yyyy', 'id_ID').format(tanggal);

    showDialog(
      context: context,
      builder: (context) {
        final base = Theme.of(context);
        final overlay = base.copyWith(
          brightness: Brightness.light,
          textTheme: base.textTheme.apply(
            bodyColor: Colors.black87,
            displayColor: Colors.black87,
          ),
          iconTheme: const IconThemeData(color: Colors.black87),
          colorScheme: base.colorScheme.copyWith(
            brightness: Brightness.light,
            surface: const Color(0xFFEFF4EC), // warna background dialog
            onSurface: Colors.black87,        // ⬅️ kunci: teks jadi hitam
          ),
          dialogTheme: const DialogThemeData(
            titleTextStyle: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.w700,
              fontSize: 20,
            ),
            contentTextStyle: TextStyle(
              color: Colors.black87,
              fontSize: 14,
            ),
          ),
        );

        return Theme(
          data: overlay,
          child: Dialog(
            backgroundColor: const Color(0xFFEFF4EC),
            insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 24),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Detail Transaksi $judul',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 12),

                    _groupSection(
                      title: 'penjualan',
                      items: breakdown.penjualan,
                      color: Colors.green.shade700,
                      icon: Icons.add_circle_rounded,
                    ),
                    _groupSection(
                      title: 'beban_usaha',
                      items: breakdown.bebanUsaha,
                      color: Colors.red.shade700,
                      icon: Icons.remove_circle_rounded,
                    ),

                    const SizedBox(height: 12),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text(
                          'Tutup',
                          style: TextStyle(color: Colors.black87),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );

  }

  /// Ambil transaksi di tanggal tsb, lalu kelompokkan per kategori.
  Future<_Breakdown> _fetchKategoriBreakdown(String tanggalIso) async {
    final rows = await _supabase
        .from('transaksi_harian')
        .select('kategori, sub_kategori, custom_label, jumlah, jenis_transaksi')
        .eq('id_usaha', widget.idUsaha)
        .eq('tanggal', tanggalIso);

    final inc = <String, int>{};
    final exp = <String, int>{};

    for (final r in rows) {
      final kategori = (r['kategori'] ?? '').toString().trim();
      final sub = (r['sub_kategori'] ?? '').toString().trim();
      final labelRaw = [kategori, sub].where((s) => s.isNotEmpty).join(' — ');
      final label = labelRaw.isEmpty ? 'Lain-lain' : labelRaw;

      num n = 0;
      final j = r['jumlah'];
      if (j is num) n = j;
      else n = num.tryParse(j?.toString() ?? '0') ?? 0;

      String jenis = (r['jenis_transaksi'] ?? '').toString().toLowerCase();
      if (jenis.isEmpty) {
        jenis = n < 0 ? 'beban_usaha' : 'penjualan';
      }
      final nilaiAbs = n.abs().round();

      if (jenis == 'beban_usaha') {
        exp[label] = (exp[label] ?? 0) + nilaiAbs;
      } else {
        inc[label] = (inc[label] ?? 0) + nilaiAbs;
      }
    }

    return _Breakdown(inc, exp);
  }

  // ==== EDIT / DELETE dipakai ulang, ditambah refresh mutasi ====
  Future<void> _editKeteranganTransaksi(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userProfile =
    await supabase.from('profiles').select('id_usaha, nama').eq('id', user.id).maybeSingle();

    final idUsaha = userProfile?['id_usaha'];
    final namaAdmin = userProfile?['nama'] ?? 'Admin';
    if (idUsaha == null) return;

    final transaksi = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_usaha', idUsaha)
        .eq('tanggal', tanggal)
        .limit(1)
        .maybeSingle();

    if (transaksi == null) {
      PopNotifier.I.show(
        context,
        title: 'Tidak tersedia',
        message: 'Detail tidak tersedia untuk data rekap.',
        type: NoticeType.info,
        duration: const Duration(seconds: 2),
      );
      return;
    }

    final TextEditingController keteranganController =
    TextEditingController(text: transaksi['keterangan'] ?? '');

    await showDialog(
      context: context,
      builder: (context) {
        final base = Theme.of(context);
        final overlay = base.copyWith(
          brightness: Brightness.light,
          textTheme: base.textTheme.apply(
            bodyColor: Colors.black87,
            displayColor: Colors.black87,
          ),
          iconTheme: const IconThemeData(color: Colors.black87),
          colorScheme: base.colorScheme.copyWith(
            brightness: Brightness.light,
            surface: Colors.white,
            onSurface: Colors.black87, // ⬅️ penting supaya teks tidak putih
          ),
          dialogTheme: const DialogThemeData(
            titleTextStyle: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.w700,
              fontSize: 20,
            ),
            contentTextStyle: TextStyle(
              color: Colors.black87,
              fontSize: 14,
            ),
          ),
        );

        return Theme(
          data: overlay,
          child: AlertDialog(
            title: const Text('Edit Keterangan'),
            content: TextField(
              controller: keteranganController,
              decoration: const InputDecoration(
                labelText: 'Keterangan baru',
              ),
              maxLines: 3,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'Batal',
                  style: TextStyle(color: Colors.black87),
                ),
              ),
              ElevatedButton(
                onPressed: () async {
                  final newKeterangan = keteranganController.text.trim();
                  await supabase
                      .from('transaksi_harian')
                      .update({'keterangan': newKeterangan})
                      .eq('id', transaksi['id']);

                  Navigator.of(context).pop();
                  PopNotifier.I.show(
                    context,
                    title: 'Tersimpan',
                    message: 'Keterangan berhasil diperbarui.',
                    type: NoticeType.success,
                    duration: const Duration(seconds: 2),
                  );
                  await logService.addLog(
                    aktivitas: '$namaAdmin edit keterangan transaksi',
                    halaman: 'Rekap Transaksi',
                    detail: 'Tanggal: $tanggal',
                  );
                },
                child: const Text('Simpan'),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _deleteLaporan(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userProfile =
    await supabase.from('profiles').select('id_usaha, nama').eq('id', user.id).maybeSingle();

    final idUsaha = userProfile?['id_usaha'];
    final namaAdmin = userProfile?['nama'] ?? 'Admin';
    if (idUsaha == null) return;

    final confirm = await showDialog(
      context: context,
      builder: (context) {
        final base = Theme.of(context);

        // ⬇️ Paksa theme dialog yg terang + teks hitam
        final overlay = base.copyWith(
          brightness: Brightness.light,
          colorScheme: base.colorScheme.copyWith(
            brightness: Brightness.light,
            surface: Colors.white,
            onSurface: Colors.black87, // ⬅️ kunci agar teks dialog tidak putih
            primary: const Color(0xFF8B0000), // merah brand kamu untuk tombol
            onPrimary: Colors.white,
          ),
          textTheme: base.textTheme.apply(
            bodyColor: Colors.black87,
            displayColor: Colors.black87,
          ),
          iconTheme: const IconThemeData(color: Colors.black87),
          dialogTheme: const DialogThemeData(
            titleTextStyle: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.w700,
              fontSize: 20,
            ),
            contentTextStyle: TextStyle(
              color: Colors.black87,
              fontSize: 14,
            ),
          ),
          // pastikan tombol default juga kontras
          textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(foregroundColor: Colors.black87),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF8B0000),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 0,
            ),
          ),
        );

        return Theme(
          data: overlay,
          child: AlertDialog(
            title: const Text('Konfirmasi'),
            content: const Text(
                'Yakin ingin menghapus semua transaksi pada tanggal ini?'
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                child: const Text('Hapus'),
                  onPressed: () async {
                    // 1) Normalisasi ke DateTime
                    DateTime t;
                    if (tanggal is DateTime) {
                      t = tanggal as DateTime;
                    } else if (tanggal is String) {
                      // coba parse "yyyy-MM-dd" dulu
                      t = DateTime.tryParse(tanggal as String) ??
                          // lalu coba parse format UI: "d MMM yyyy" (id_ID)
                          DateFormat('d MMM yyyy', 'id_ID').parse(tanggal as String);
                    } else {
                      // fallback: pakai DateTime.now() atau selectedDate milikmu
                      t = DateTime.now();
                    }

                    // 2) Ubah ke format DB
                    final tanggalDb = DateFormat('yyyy-MM-dd').format(t);

                    try {
                      await supabase
                          .from('transaksi_harian')
                          .delete()
                          .eq('id_usaha', idUsaha)
                          .eq('tanggal', tanggalDb);

                      if (context.mounted) Navigator.of(context).pop();

                      PopNotifier.I.show(
                        context,
                        title: 'Berhasil',
                        message: 'Semua transaksi pada $tanggalDb telah dihapus.',
                        type: NoticeType.success,
                        duration: const Duration(seconds: 2),
                      );

                      await logService.addLog(
                        aktivitas: '$namaAdmin menghapus transaksi',
                        halaman: 'Rekap Transaksi',
                        detail: 'Tanggal: $tanggalDb',
                      );
                    } catch (e) {
                      if (context.mounted) Navigator.of(context).pop();
                      PopNotifier.I.show(
                        context,
                        title: 'Gagal',
                        message: 'Penghapusan gagal: $e',
                        type: NoticeType.error,
                      );
                    }
                  }
              ),
            ],
          ),
        );
      },
    );

    if (confirm != true) return;

    try {
      await supabase
          .from('transaksi_harian')
          .delete()
          .eq('id_usaha', idUsaha)
          .eq('tanggal', tanggal);

      PopNotifier.I.show(
        context,
        title: 'Terhapus',
        message: 'Transaksi berhasil dihapus.',
        type: NoticeType.success,
        duration: const Duration(seconds: 2),
      );
      await logService.addLog(
        aktivitas: '$namaAdmin delete transaksi',
        halaman: 'Rekap Transaksi',
        detail: 'Tanggal: $tanggal',
      );
    } catch (e) {
      PopNotifier.I.show(
        context,
        title: 'Gagal menghapus',
        message: 'Terjadi error: $e',
        type: NoticeType.error,
        duration: const Duration(seconds: 2),
      );
    }
  }

  // Widget: daftar pegawai (Mato)
  final TextEditingController _searchController = TextEditingController();
  String _sortOption = 'Tertinggi';

// Helper kecil untuk format rupiah tanpa ketergantungan tambahan
  String _fmtRupiah(num? v) {
    final n = (v ?? 0).round().toString();
    final buf = StringBuffer();
    for (int i = 0; i < n.length; i++) {
      final revIdx = n.length - i - 1;
      buf.write(n[revIdx]);
      if ((i + 1) % 3 == 0 && i != n.length - 1) buf.write('.');
    }
    final s = buf.toString().split('').reversed.join();
    return 'Rp $s';
  }

  Widget _buildMatoBoxList() {
    const double sidePadding = 10;      // 50 kiri + 50 kanan
    const double gap = 16;              // jarak antar-card
    const double targetCardWidth = 200; // lebar ideal card

    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Mato Karyawan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    hintText: 'Cari nama karyawan...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(width: 12),
              DropdownButton<String>(
                value: _sortOption,
                items: ['Tertinggi', 'Terendah'].map((option) {
                  return DropdownMenuItem(value: option, child: Text('Sort by $option'));
                }).toList(),
                onChanged: (value) => setState(() => _sortOption = value ?? 'Tertinggi'),
              ),
            ],
          ),

          const SizedBox(height: 16),

          FutureBuilder<List<Map<String, dynamic>>>(
            future: _fetchPegawaiFromSupabase(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Terjadi kesalahan: ${snapshot.error}'));
              }

              // filter + sort
              List<Map<String, dynamic>> pegawaiList = snapshot.data ?? [];
              final q = _searchController.text.toLowerCase();
              pegawaiList = pegawaiList
                  .where((e) => (e['nama'] ?? '').toString().toLowerCase().contains(q))
                  .toList();
              pegawaiList.sort((a, b) {
                final aVal = a['skor_mato'] ?? 0;
                final bVal = b['skor_mato'] ?? 0;
                return _sortOption == 'Tertinggi' ? bVal.compareTo(aVal) : aVal.compareTo(bVal);
              });

              // ⬇️ grid responsif, scroll vertikal (no horizontal)
              return LayoutBuilder(
                builder: (ctx, cons) {
                  final bool isPhone = cons.maxWidth < 600;

                  // ⬇️ set khusus HP agar mirip figma
                  final double side = isPhone ? 16 : sidePadding;         // HP: padding 16, tablet/desktop: 50
                  final double gapX = isPhone ? 12 : gap;                 // jarak antar card
                  final double targetW = isPhone ? 170 : targetCardWidth; // HP: card ~170px
                  final double contentWidth =
                  (cons.maxWidth - (side * 2)).clamp(0.0, double.infinity);

                  // HP: paksa 2 kolom; selain itu hitung otomatis seperti sebelumnya
                  final int crossAxisCount = isPhone
                      ? 2
                      : max(1, ((contentWidth + gapX) / (targetW + gapX)).floor());

                  // Skala UI di dalam card (supaya tidak terlalu kecil)
                  final double pad = isPhone ? 12 : 16;          // ↑ sedikit diperbesar di HP
                  final double titleFs = isPhone ? 16 : 18;
                  final double subFs = isPhone ? 13 : 14;
                  final double scoreFs = isPhone ? 16 : 18;
                  final double btnVPad = isPhone ? 8 : 10;
                  final double btnMinH = isPhone ? 36 : 40;
                  final double radius = isPhone ? 14 : 16;

                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: side),
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: pegawaiList.length,
                      // di _buildMatoBoxList() -> GridView.builder
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: crossAxisCount,
                        crossAxisSpacing: gapX,
                        mainAxisSpacing: gapX,
                        // ↓ card sedikit lebih tinggi agar muat "Pendapatan"
                        mainAxisExtent: isPhone ? 168 : 204,
                      ),
                      itemBuilder: (context, index) {
                        final pegawai = pegawaiList[index];

                        // Ambil pendapatan dari beberapa kemungkinan key agar fleksibel
                        final num totalHasil = (pegawai['total_hasil'] ?? 0) as num;

                        return Container(
                          padding: EdgeInsets.all(pad),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(radius),
                            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                pegawai['nama'] ?? '-',
                                maxLines: 2,                 // ← beri 2 baris
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: titleFs, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                pegawai['jabatan'] ?? '-',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: subFs),
                              ),
                              if (isPhone)
                                const SizedBox(height: 6)   // jarak kecil di HP
                              else
                                const Spacer(),             // tetap rapih di tablet/desktop

                              // Poin Mato
                              Text(
                                "Poin Mato ${pegawai['skor_mato'] ?? 0}",
                                style: TextStyle(
                                  fontSize: scoreFs,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),

                              // Pendapatan (total hasil bersih) — diminta tampil di bawah Poin Mato
                              const SizedBox(height: 4),
                              Text(
                                "Pendapatan: ${_fmtRupiah(totalHasil)}",
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: subFs,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black87,
                                ),
                              ),

                              const SizedBox(height: 8),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () async {
                                    final changed = await openPegawaiDetail(context, pegawai);  // ← tanpa callback
                                    if (!mounted) return;

                                    if (changed) {
                                      setState(() {});
                                      WidgetsBinding.instance.addPostFrameCallback((_) {
                                        if (!mounted) return;
                                        PopNotifier.I.show(
                                          context,
                                          title: 'Berhasil',
                                          message: 'Data karyawan sudah diperbarui.',
                                          type: NoticeType.success,
                                          duration: const Duration(seconds: 2),
                                        );
                                      });
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green.shade100,
                                    minimumSize: Size.fromHeight(btnMinH),
                                    padding: EdgeInsets.symmetric(vertical: btnVPad),
                                  ),
                                  child: const Text('Detail', style: TextStyle(color: Colors.green)),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _fetchPegawaiFromSupabase() async {
    final supa = Supabase.instance.client;
    final user = supa.auth.currentUser;
    if (user == null) throw Exception('Belum login');

    try {
      // Ambil profil user login untuk dapatkan id_usaha
      final me = await supa
          .from('profiles')
          .select('id, role, id_usaha')
          .eq('id', user.id)
          .single();

      final idUsaha = me['id_usaha'];
      if (idUsaha == null) throw Exception('ID usaha tidak ditemukan');

      // Ambil semua profil dalam usaha yg sama
      // Tambahkan kolom komponen supaya bisa fallback hitung manual
      final rows = await supa.from('profiles').select('''
        id,
        nama,
        jabatan,
        role,
        id_usaha,
        skor_mato,
        nilai_per_mata,
        pendapatan,
        pinjaman,
        bon_makan,
        bon_gudang,
        pot_absen,
        absen,
        uang_servis,
        total_hasil
      ''').eq('id_usaha', idUsaha)
          .order('nama');

      debugPrint('Profiles fetched: ${rows.length}');
      for (final r in rows) {
        debugPrint('row: $r');
      }

      return List<Map<String, dynamic>>.from(rows);
    } on PostgrestException catch (e, st) {
      debugPrint(
        'PostgrestException in _fetchPegawaiFromSupabase: '
            '${e.code} ${e.message} details=${e.details} hint=${e.hint}',
      );
      debugPrintStack(stackTrace: st);
      rethrow;
    } catch (e, st) {
      debugPrint('Unexpected error in _fetchPegawaiFromSupabase: $e');
      debugPrintStack(stackTrace: st);
      rethrow;
    }
  }
}

// ========== HELPER ==========
class WidgetWraper {
  static Future<Uint8List?> wrapWidgetToImage(GlobalKey key) async {
    try {
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      final image = await boundary?.toImage(pixelRatio: 2.0);
      final byteData = await image?.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }
}

// Helper global: ambil income_per_mato aktif hari ini
Future<int> _getIncomePerMatoValue() async {
  final supabase = Supabase.instance.client;
  final user = supabase.auth.currentUser;
  if (user == null) return 0;

  final profile = await supabase
      .from('profiles')
      .select('id_usaha')
      .eq('id', user.id)
      .maybeSingle();

  final idUsaha = profile?['id_usaha'];
  if (idUsaha == null) return 0;

  final today = DateTime.now();
  final result = await supabase
      .from('income_per_mato')
      .select('income_per_mato')
      .eq('id_usaha', idUsaha)
      .lte('tanggal_awal', today.toIso8601String())
      .gte('tanggal_akhir', today.toIso8601String())
      .maybeSingle();

  return (result?['income_per_mato'] as int?) ?? 0;
}

class _PresetChipDash extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  const _PresetChipDash({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFE4E9) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }
}

// ====== Reusable kecil ala LaporanLB ======
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _Breakdown {
  final Map<String, int> penjualan;
  final Map<String, int> bebanUsaha;
  _Breakdown(this.penjualan, this.bebanUsaha);
}

class _FancyDrawerHeader extends StatelessWidget {
  final String namaUsaha;
  final String email;
  final String role;
  final String usaha;
  final String? photoUrl;
  final VoidCallback? onTapEditUsaha;
  final VoidCallback? onTapSettings;

  const _FancyDrawerHeader({
    required this.namaUsaha,
    required this.email,
    required this.role,
    required this.usaha,
    this.photoUrl,
    this.onTapEditUsaha,
    this.onTapSettings,
  });

  String _initialsFrom(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return 'U';
    final first = parts.first.isNotEmpty ? parts.first[0] : '';
    final last = parts.length > 1 && parts.last.isNotEmpty ? parts.last[0] : '';
    return (first + last).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top; // safe-area
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(24),
        bottomRight: Radius.circular(24),
      ),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFC1CC), Colors.white],
          ),
        ),
        // ⬇️ PADDING dinamis: tak akan overflow
        padding: EdgeInsets.fromLTRB(16, top + 16, 12, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min, // <-- biar setinggi konten
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: const Color(0xFF2D2D2D),
                  backgroundImage:
                  (photoUrl != null && photoUrl!.isNotEmpty) ? NetworkImage(photoUrl!) : null,
                  child: (photoUrl == null || photoUrl!.isEmpty)
                      ? Text(
                    _initialsFrom(namaUsaha),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                    ),
                  )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              namaUsaha,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                letterSpacing: .2,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            onTap: onTapEditUsaha,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(Icons.edit, size: 18),
                            ),
                          ),
                          const SizedBox(width: 4),
                          InkWell(
                            onTap: onTapSettings,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(Icons.settings, size: 18),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // chip2 – taruh dalam scroll horizontal biar aman jika panjang
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _badge(role, color: const Color(0xFF22313F)),
                  const SizedBox(width: 8),
                  InkWell(
                    onTap: onTapEditUsaha,        // klik chip lokasi -> buka dialog edit
                    borderRadius: BorderRadius.circular(999),
                    child: _chip(icon: Icons.location_on_rounded, label: usaha),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.55),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black.withOpacity(0.06)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: const [
                  Icon(Icons.verified_user, size: 16, color: Colors.black87),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Akun aktif – akses admin',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, {required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: .3,
        ),
      ),
    );
  }

  Widget _chip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black.withOpacity(0.10)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.black87),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, letterSpacing: .2),
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final bool danger;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = active ? const Color(0xFFFFE4E9) : Colors.white;
    final fg = danger ? Colors.red : Colors.black87;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        elevation: active ? 2 : 0,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(icon, color: danger ? Colors.red : Colors.black87),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: fg,
                    ),
                  ),
                ),
                Icon(Icons.chevron_right_rounded,
                    color: danger ? Colors.red : Colors.black38),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// 1) Helper kecil
double _safeInterval(double range, {double fallback = 1}) {
  if (!range.isFinite || range <= 0) return fallback;
  final v = range / 4; // 4 grid line, bebas mau 5/6
  return v > 0 ? v : fallback;
}

LineChart buildChart(List<FlSpot> spots) {
  if (spots.isEmpty) {
    return LineChart(
      LineChartData(
        // chart kosong yang rapi
        minX: 0, maxX: 1, minY: 0, maxY: 1,
        gridData: const FlGridData(show: false),
        titlesData: const FlTitlesData(show: false),
        lineBarsData: const [],
      ),
    );
  }

  // 2) Hitung min/max
  double minX = spots.map((e) => e.x).reduce((a, b) => a < b ? a : b);
  double maxX = spots.map((e) => e.x).reduce((a, b) => a > b ? a : b);
  double minY = spots.map((e) => e.y).reduce((a, b) => a < b ? a : b);
  double maxY = spots.map((e) => e.y).reduce((a, b) => a > b ? a : b);

  // 3) Kalau semua Y = 0 (atau min==max), lebarkan sedikit
  if (minY == maxY) { minY -= 1; maxY += 1; }
  if (minX == maxX) { minX -= 1; maxX += 1; }

  final vInterval = _safeInterval(maxX - minX, fallback: 1); // sumbu X
  final hInterval = _safeInterval(maxY - minY, fallback: 1); // sumbu Y

  return LineChart(
    LineChartData(
      minX: minX, maxX: maxX, minY: minY, maxY: maxY,
      gridData: FlGridData(
        drawVerticalLine: true,
        drawHorizontalLine: true,
        verticalInterval: vInterval,     // <-- TIDAK 0
        horizontalInterval: hInterval,   // <-- TIDAK 0
      ),
      titlesData: FlTitlesData(
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(showTitles: true, interval: vInterval),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(showTitles: true, interval: hInterval),
        ),
      ),
      lineBarsData: [
        LineChartBarData(
          spots: spots,
          isCurved: true,
          dotData: const FlDotData(show: false),
        ),
      ],
    ),
  );
}

// === OPENER: panggil ini dari tombol "Detail" ===
Future<bool> openPegawaiDetail(
    BuildContext context,
    Map<String, dynamic> pegawai,
    ) async {
  final supabase = Supabase.instance.client;

  Map<String, dynamic> row = pegawai;
  try {
    final id = pegawai['id'];
    if (id != null) {
      final fresh = await supabase.from('profiles').select().eq('id', id).maybeSingle();
      if (fresh != null) row = fresh;
    }
  } catch (_) {}

  final safe = <String, dynamic>{
    'id'          : row['id'],
    'nama'        : asStr(row['nama']),
    'jabatan'     : asStr(row['jabatan']),
    'skor_mato'   : asInt(row['skor_mato']),
    'pinjaman'    : asInt(row['pinjaman']),
    'bon_makan'   : asInt(row['bon_makan']),
    'bon_gudang'  : asInt(row['bon_gudang']),
    'pot_absen'   : asInt(row['pot_absen']),
    'absen'       : asInt(row['absen']),
    'uang_servis' : asInt(row['uang_servis']),
  };

  final mq = MediaQuery.of(context);
  final w = mq.size.width, h = mq.size.height;
  final isPhone = w < 600;

  final result = await showDialog<bool>(
    context: context,
    useRootNavigator: true,
    barrierDismissible: true,
    barrierColor: Colors.black.withOpacity(0.35),
    builder: (_) => Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: isPhone ? 360.0 : (w < 1024 ? 720.0 : 920.0),
          maxHeight: h * (isPhone ? 0.80 : 0.88),
        ),
        child: _EmployeeDetailDialog(
          pegawai: safe,
          compact: isPhone,
        ),
      ),
    ),
  );
  return result ?? false;
  return result ?? false; // ← penting
}

// === UI + LOGIC barunya (gantikan versi lama seluruhnya) ===
class _EmployeeDetailDialog extends StatefulWidget {
  const _EmployeeDetailDialog({
    super.key,
    required this.pegawai,
    required this.compact,
  });

  final Map<String, dynamic> pegawai;
  final bool compact;

  @override
  State<_EmployeeDetailDialog> createState() => _EmployeeDetailDialogState();
}

class _EmployeeDetailDialogState extends State<_EmployeeDetailDialog> {
  bool isEditing = false;
  bool _saving = false;

  // controller
  late final TextEditingController mataCtrl;
  late final TextEditingController pinjamanCtrl;
  late final TextEditingController bonMakanCtrl;
  late final TextEditingController bonGudangCtrl;
  late final TextEditingController potAbsenCtrl;
  late final TextEditingController absenCtrl;
  late final TextEditingController servisCtrl;
  late final TextEditingController jabatanCtrl;

  // ⬇️ GETTER: id user karyawan dari data yang kamu kirim ke dialog
  String get karyawanUserId => asStr(widget.pegawai['id']);

  int incomePerMato = 0;

  final _rupiahInputFmt = RupiahInputFormatter();

  void _formatIfNeeded(TextEditingController c) {
    final digits = c.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) {
      c.value = const TextEditingValue(text: '');
      return;
    }
    final t = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0)
        .format(int.parse(digits));
    if (c.text != t) {
      c.value = TextEditingValue(
        text: t,
        selection: TextSelection.collapsed(offset: t.length),
      );
    }
  }

  void _formatAllCurrencyControllers() {
    _formatIfNeeded(pinjamanCtrl);
    _formatIfNeeded(bonMakanCtrl);
    _formatIfNeeded(bonGudangCtrl);
    _formatIfNeeded(potAbsenCtrl);
    _formatIfNeeded(servisCtrl);
  }

  // flag loading khusus tombol hapus
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    final p = widget.pegawai;
    mataCtrl      = TextEditingController(text: asInt(p['skor_mato']).toString());
    pinjamanCtrl  = TextEditingController(text: asInt(p['pinjaman']).toString());
    bonMakanCtrl  = TextEditingController(text: asInt(p['bon_makan']).toString());
    bonGudangCtrl = TextEditingController(text: asInt(p['bon_gudang']).toString());
    potAbsenCtrl  = TextEditingController(text: asInt(p['pot_absen']).toString());
    absenCtrl     = TextEditingController(text: asInt(p['absen']).toString());
    servisCtrl    = TextEditingController(text: asInt(p['uang_servis']).toString());
    jabatanCtrl   = TextEditingController(text: asStr(p['jabatan']));

    _formatAllCurrencyControllers();

    _getIncomePerMatoValue().then((v) {
      if (mounted) setState(() => incomePerMato = v);
    });

    Supabase.instance.client.rpc('whoami').then((who) {
      debugPrint('whoami: $who');
    });
  }

  @override
  void dispose() {
    mataCtrl.dispose();
    pinjamanCtrl.dispose();
    bonMakanCtrl.dispose();
    bonGudangCtrl.dispose();
    potAbsenCtrl.dispose();
    absenCtrl.dispose();
    servisCtrl.dispose();
    jabatanCtrl.dispose();
    super.dispose();
  }

  int _toInt(TextEditingController c) =>
      int.tryParse(c.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;

// formatter rupiah lokal
  final NumberFormat _nfLocal =
  NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
  String _rp(num v) => _nfLocal.format(v);

  @override
  Widget build(BuildContext context) {
    final compact = widget.compact;

    // hitung
    final skor        = _toInt(mataCtrl);
    final pendapatan  = skor * incomePerMato;
    final totalPinjam = _toInt(pinjamanCtrl) + _toInt(bonMakanCtrl) + _toInt(bonGudangCtrl);

    // ⬇️ baru: jumlah absen × potongan per absen (langsung dipakai)
    final jmlAbsen       = _toInt(absenCtrl);
    final potPerAbsen    = _toInt(potAbsenCtrl);        // aman walau "Rp 10.000"
    final potAbsenTotal  = jmlAbsen * potPerAbsen;

    final hasil       = pendapatan - (totalPinjam + potAbsenTotal);
    final totalHasil  = hasil + _toInt(servisCtrl);

    // style ringkas utk HP
    final double padOuter   = compact ? 12 : 18;
    final double fsTitle    = compact ? 16 : 18;
    final double fsLabel    = compact ? 13 : 14;
    final double fsValue    = compact ? 13.5 : 14.5;
    final EdgeInsets iptPad = EdgeInsets.symmetric(horizontal: 12, vertical: compact ? 8 : 10);

    // ⬇️ style tombol hapus (merah muda + maroon)
    final ButtonStyle _hapusStyle = FilledButton.styleFrom(
      backgroundColor: const Color(0xFFFFC6C6), // merah muda terang
      foregroundColor: const Color(0xFF6B0000), // maroon
      shape: const StadiumBorder(),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      textStyle: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: .2),
    );

    Widget kv(String k, String v, {bool bold = false, Color? color}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(k, style: TextStyle(fontSize: fsLabel, fontWeight: FontWeight.w600)),
          Text(v, style: TextStyle(fontSize: fsValue, fontWeight: bold ? FontWeight.w800 : FontWeight.w700, color: color)),
        ],
      ),
    );

    InputDecoration ipt(String label) => InputDecoration(
      labelText: label,
      isDense: true,
      contentPadding: iptPad,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    );

    Widget group(String title, List<Widget> children) => Container(
      margin: const EdgeInsets.only(top: 12),
      padding: EdgeInsets.all(compact ? 12 : 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(0.08)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0,4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ...children,
        ],
      ),
    );

    return SafeArea(
      top: false,
      bottom: false,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ===== header =====
          Padding(
            padding: EdgeInsets.fromLTRB(padOuter, padOuter, padOuter - 4, 6),
            child: Row(
              children: [
                Expanded(
                  child: Text('Detail Karyawan',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: fsTitle),
                  ),
                ),
                IconButton(
                  tooltip: 'Tutup',
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.of(context, rootNavigator: true).maybePop(),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          // ===== body scrollable =====
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(padOuter, padOuter, padOuter, padOuter),
              child: LayoutBuilder(
                builder: (ctx, cons) {
                  final isWide = cons.maxWidth >= 760 && !compact;

                  final kiri = Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      // === JABATAN (tanpa judul card supaya tidak dobel) ===
                      group('', [
                        if (isEditing)
                          TextField(
                            controller: jabatanCtrl,
                            textInputAction: TextInputAction.done,
                            decoration: ipt('Jabatan'),
                            onChanged: (_) => setState(() {}),
                          )
                        else
                          kv('Jabatan', jabatanCtrl.text.isEmpty ? '—' : jabatanCtrl.text),
                      ]),

                      // === MATO + PENDAPATAN ===
                      group('', [
                        if (isEditing)
                          TextField(
                            controller: mataCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            onTap: () {
                              if (mataCtrl.text == '0') {
                                mataCtrl.clear();
                              } else {
                                mataCtrl.selection = TextSelection(baseOffset: 0, extentOffset: mataCtrl.text.length);
                              }
                            },
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Mato'),
                          )
                        else
                          kv('Mato', mataCtrl.text),
                        kv('Nilai per mato', _rp(incomePerMato), color: Colors.red.shade600),
                        kv('Pendapatan Kotor', _rp(pendapatan), bold: true),
                      ]),

                      // === PINJAMAN ===
                      group('Rincian Pinjaman', [
                        if (isEditing) ...[
                          TextField(
                            controller: pinjamanCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [_rupiahInputFmt],
                            textAlign: TextAlign.right,
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Pinjaman cash'),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: bonMakanCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [_rupiahInputFmt],
                            textAlign: TextAlign.right,
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Bon makan'),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: bonGudangCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [_rupiahInputFmt],
                            textAlign: TextAlign.right,
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Bon gudang'),
                          ),
                        ] else ...[
                          kv('Pinjaman cash', _rp(_toInt(pinjamanCtrl))),
                          kv('Bon makan',     _rp(_toInt(bonMakanCtrl))),
                          kv('Bon gudang',    _rp(_toInt(bonGudangCtrl))),
                        ],
                        const Divider(),
                        kv('Total Pinjaman', _rp(totalPinjam), bold: true),
                      ]),
                    ],
                  );

                  final kanan = Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      group('', [
                        if (isEditing) ...[
                          TextField(
                            controller: absenCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            onTap: () => absenCtrl.selection =
                                TextSelection(baseOffset: 0, extentOffset: absenCtrl.text.length),
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Jumlah Absen'),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: potAbsenCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [_rupiahInputFmt],
                            textAlign: TextAlign.right,
                            onTap: () => potAbsenCtrl.selection =
                                TextSelection(baseOffset: 0, extentOffset: potAbsenCtrl.text.length),
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Potongan Absen'),
                          ),

                          const SizedBox(height: 8),
                          TextField(
                            controller: servisCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [_rupiahInputFmt],
                            textAlign: TextAlign.right,
                            onChanged: (_) => setState(() {}),
                            decoration: ipt('Uang Servis'),
                          ),
                        ] else ...[
                          kv('Jumlah Absen', absenCtrl.text.isEmpty ? '0' : absenCtrl.text),
                          kv('Potongan Absen', _rp(_toInt(potAbsenCtrl))),
                          kv('Total Pot. Absen', _rp(potAbsenTotal)),
                          kv('Uang Servis',     _rp(_toInt(servisCtrl))),
                        ],
                        const SizedBox(height: 6),
                        // pill total
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: compact ? 14 : 16, vertical: compact ? 10 : 12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(compact ? 18 : 22),
                            border: Border.all(color: Colors.black, width: 1.5),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Total Hasil Bersih', style: TextStyle(fontWeight: FontWeight.w700, fontSize: compact ? 13 : 14)),
                              Text(_rp(totalHasil),      style: TextStyle(fontWeight: FontWeight.w800, fontSize: compact ? 15 : 16)),
                            ],
                          ),
                        ),
                      ]),
                    ],
                  );

                  if (isWide) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: kiri),
                        const SizedBox(width: 16),
                        Expanded(child: kanan),
                      ],
                    );
                  }
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      kiri,
                      const SizedBox(height: 12),
                      kanan,
                    ],
                  );
                },
              ),
            ),
          ),

          // ===== Footer =====
          Padding(
            padding: EdgeInsets.fromLTRB(padOuter, 0, padOuter, padOuter),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // kiri: TUTUP
                TextButton(
                  onPressed: () => Navigator.of(context, rootNavigator: true).maybePop(),
                  child: const Text('TUTUP', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black)),
                ),

                // kanan: [HAPUS]* [PERBARUI | SIMPAN]
                Row(
                  children: [
                    // tombol kanan: PERBARUI / SIMPAN seperti semula
                    if (!isEditing)
                      ElevatedButton(
                        onPressed: () => setState(() {
                          isEditing = true;
                          _formatAllCurrencyControllers(); // pastikan field “Rp …” sudah terformat
                        }),

                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF2F2F2),
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          elevation: 0,
                        ),
                        child: const Text('PERBARUI DATA', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black)),
                      )
                    else
                      SizedBox(
                        height: 44,
                        child: ElevatedButton.icon(
                          onPressed: _saving ? null : () async {
                            _formatAllCurrencyControllers();
                            setState(() => _saving = true);
                            try { await _save(); } finally { if (mounted) setState(() => _saving = false); }
                          },
                          icon: _saving
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.save),
                          label: Text(_saving ? 'MENYIMPAN…' : 'SIMPAN PERUBAHAN',
                              style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.black)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFFE4E9),
                            foregroundColor: Colors.black,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    final supabase = Supabase.instance.client;

    final skor        = _toInt(mataCtrl);
    final pendapatan  = skor * incomePerMato;
    final jmlAbsen    = _toInt(absenCtrl);
    final potPerAbsen = _toInt(potAbsenCtrl);
    final potAbsenTotal = jmlAbsen * potPerAbsen; // ✅ baru

    final totalMingguan = pendapatan + _toInt(servisCtrl);
    final hasil = pendapatan
        - (_toInt(pinjamanCtrl) + _toInt(bonMakanCtrl) + _toInt(bonGudangCtrl) + potAbsenTotal); // ✅ pakai total
    final totalHasil = hasil + _toInt(servisCtrl);

    final updateMap = {
      'jabatan': jabatanCtrl.text.trim(),
      'skor_mato': skor,
      'nilai_per_mata': incomePerMato,
      'pendapatan': pendapatan,
      'pinjaman': _toInt(pinjamanCtrl),
      'bon_makan': _toInt(bonMakanCtrl),
      'bon_gudang': _toInt(bonGudangCtrl),
      'pot_absen': _toInt(potAbsenCtrl),
      'absen': _toInt(absenCtrl),
      'uang_servis': _toInt(servisCtrl),
      'total_mingguan': totalMingguan,
      'hasil': hasil,
      'total_hasil': totalHasil,
      'updated_at': DateTime.now().toIso8601String(),
    };

    try {
      await supabase.from('profiles').update(updateMap).eq('id', widget.pegawai['id']);

      // (opsional) tulis log seperti semula...

      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop(true);
    } catch (e) {
      if (!mounted) return;
      final overlayCtx = Overlay.of(context, rootOverlay: true)?.context ?? context;
      PopNotifier.I.show(
        overlayCtx,
        title: 'Gagal update',
        message: 'Tidak dapat menyimpan: $e',
        type: NoticeType.error,
        duration: const Duration(seconds: 2),
      );
    }
  }

// helper toast sederhana
  void _showToast(String title, String msg) {
    final overlayCtx = Overlay.of(context, rootOverlay: true)?.context ?? context;
    PopNotifier.I.show(overlayCtx, title: title, message: msg,
        type: title == 'Berhasil' ? NoticeType.success : NoticeType.error,
        duration: const Duration(seconds: 2));
  }
}

// Formatter: saat mengetik "10000" -> "Rp 10.000"
class RupiahInputFormatter extends TextInputFormatter {
  final NumberFormat _nf = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ', // ganti ke 'Rp. ' kalau mau pakai titik setelah Rp
    decimalDigits: 0,
  );

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue,
      TextEditingValue newValue,
      ) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) {
      return const TextEditingValue(text: '', selection: TextSelection.collapsed(offset: 0));
    }
    final n = int.parse(digits);
    final formatted = _nf.format(n);
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
      composing: TextRange.empty,
    );
  }
}
