import 'dart:async';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:ok_oce/feedbackPage.dart';
import 'package:ok_oce/widget/app_background.dart';

/// ===== Helper Rupiah =====
final NumberFormat _rupiahFmt =
NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
String rupiah(num v) => _rupiahFmt.format(v);

class DashboardStaff extends StatefulWidget {
  const DashboardStaff({super.key});

  @override
  State<DashboardStaff> createState() => _DashboardStaffState();
}

class _DashboardStaffState extends State<DashboardStaff> {
  final supabase = Supabase.instance.client;
  StreamSubscription<AuthState>? _authSub;

  bool _welcomeChecked = false;

  // Info user & usaha
  String? _namaUsaha; // usaha.nama_usaha
  String? _namausaha; // usaha.lokasi -> chip lokasi
  String? staffEmail;
  String? _idUsaha;
  String? _staffName;

  // Filter tanggal utk grafik total_hasil
  DateTime? _startDate;
  DateTime? _endDate;
  String _preset = 'all'; // all | month | 100

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_welcomeChecked) return;

    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is Map && (args['showWelcome'] == true)) {
      final msg = (args['welcomeText'] as String?) ??
          'Login berhasil. Selamat datang!';
      // Jalankan setelah frame pertama selesai, supaya overlay aman
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          showTopToast(
            context,
            msg,
            icon: Icons.check_circle,
          );
        }
      });
    }
    _welcomeChecked = true;
    AppBackground.precacheAll(context);
  }

  @override
  void initState() {
    super.initState();
    _loadNamaUsaha();
    _loadStaffInfo();
    _authSub = supabase.auth.onAuthStateChange.listen((data) {
      if (!mounted) return;
      setState(() {
        staffEmail = data.session?.user.email;
      });
    });
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }

  /// ===== Helper device (MediaQuery) =====
  bool isPhone(BuildContext c) => MediaQuery.sizeOf(c).width < 600;
  bool isTablet(BuildContext c) {
    final w = MediaQuery.sizeOf(c).width;
    return w >= 600 && w < 1024;
  }

  Future<void> _loadStaffInfo() async {
    final user = supabase.auth.currentUser;
    if (!mounted) return;
    setState(() => staffEmail = user?.email);

    if (user != null) {
      try {
        final prof = await supabase
            .from('profiles')
            .select('nama')
            .eq('id', user.id)
            .maybeSingle();

        if (!mounted) return;
        setState(() {
          _staffName = (prof?['nama'] as String?)?.trim();
        });
      } catch (e) {
        debugPrint('load staff name error: $e');
      }
    }
  }

  // ================== LOAD STATIC ==================
  Future<void> _loadNamaUsaha() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;

      final prof = await supabase
          .from('profiles')
          .select('id_usaha')
          .eq('id', user.id)
          .maybeSingle();

      final idUsaha = prof?['id_usaha'];
      if (idUsaha == null) return;

      final cab = await supabase
          .from('usaha')
          .select('nama_usaha, lokasi')
          .eq('id_usaha', idUsaha)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        _idUsaha = idUsaha;
        _namaUsaha = (cab?['nama_usaha'] as String?)?.trim();
        _namausaha = (cab?['lokasi'] as String?)?.trim();
      });
    } catch (e) {
      debugPrint('load usaha error: $e');
    }
  }

  // ================== DATA: “Pendapatan Saya” ==================
  Future<Map<String, dynamic>?> _fetchMyIncomeRow() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    final row = await supabase.from('profiles').select('''
          id, nama, jabatan,
          pendapatan, hasil, total_hasil, total_mingguan,
          skor_mato, nilai_per_mata, uang_servis,
          pinjaman, bon_makan, bon_gudang, pot_absen,
          updated_at
        ''').eq('id', user.id).maybeSingle();

    return row;
  }

  // ================== DATA: Series total_hasil (grafik) ==================
  String _iso(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

  Future<List<Map<String, dynamic>>> _fetchTotalHasilSeries() async {
    final user = supabase.auth.currentUser;
    if (user == null) return [];

    try {
      var qb = supabase
          .from('riwayat_total_hasil')
          .select('tanggal, total_hasil')
          .eq('user_id', user.id)
          .order('tanggal', ascending: true)
      as PostgrestFilterBuilder;

      if (_startDate != null) qb = qb.gte('tanggal', _iso(_startDate!));
      if (_endDate != null) qb = qb.lte('tanggal', _iso(_endDate!));

      final res = await qb;
      return List<Map<String, dynamic>>.from(res);
    } catch (e) {
      debugPrint('riwayat_total_hasil NA, fallback profiles: $e');
      try {
        final r = await supabase
            .from('profiles')
            .select('total_hasil, updated_at')
            .eq('id', user.id)
            .maybeSingle();
        if (r == null) return [];
        final String iso =
        (r['updated_at']?.toString() ?? DateTime.now().toIso8601String());
        final row = {
          'tanggal': iso.substring(0, 10),
          'total_hasil': (r['total_hasil'] as num?) ?? 0,
        };

        final dt = DateTime.tryParse((row['tanggal'] ?? '').toString());
        final okStart =
            _startDate == null || (dt != null && !dt.isBefore(_startDate!));
        final okEnd =
            _endDate == null || (dt != null && !dt.isAfter(_endDate!));
        return (okStart && okEnd) ? [row] : [];
      } catch (e2) {
        debugPrint('fallback profiles failed: $e2');
        return [];
      }
    }
  }

  // ==== PERBAIKAN: export PDF pakai toast seragam ====
  Future<void> _exportPendapatanSayaToPdf() async {
    try {
      final row = await _fetchMyIncomeRow();
      if (row == null) {
        if (!mounted) return;
        await showTopToast(
          context,
          'Data pendapatan tidak ditemukan',
          icon: Icons.info_rounded,
        );
        return;
      }

      // hitung nilai seperti UI
      final skor        = (row['skor_mato'] as num?) ?? 0;
      final nilai       = (row['nilai_per_mata'] as num?) ?? 0;
      final pendapatan  = (row['pendapatan'] as num?) ?? (skor * nilai);
      final pinjaman    = (row['pinjaman'] as num?) ?? 0;
      final bonMakan    = (row['bon_makan'] as num?) ?? 0;
      final bonGudang   = (row['bon_gudang'] as num?) ?? 0;
      final potAbsen    = (row['pot_absen'] as num?) ?? 0;
      final servis      = (row['uang_servis'] as num?) ?? 0;
      final potongan    = pinjaman + bonMakan + bonGudang + potAbsen;
      final totalMingguan = (row['total_mingguan'] as num?) ?? (pendapatan + servis);
      final hasil       = (row['hasil'] as num?) ?? (pendapatan - potongan);
      final totalHasil  = (row['total_hasil'] as num?) ?? (hasil + servis);

      final updatedAtStr = () {
        final raw = (row['updated_at'])?.toString();
        if (raw == null) return '—';
        try {
          return DateFormat('dd MMM yyyy HH:mm', 'id_ID').format(DateTime.parse(raw).toLocal());
        } catch (_) {
          return '—';
        }
      }();

      final nowStr = DateFormat('dd MMM yyyy HH:mm', 'id_ID').format(DateTime.now());

      final doc = pw.Document();

      pw.Widget kv(String k, String v, {bool bold = false, double gap = 6}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 2),
        child: pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              child: pw.Text(
                k,
                style: pw.TextStyle(fontSize: 11, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
              ),
            ),
            pw.SizedBox(width: gap),
            pw.Text(
              v,
              style: pw.TextStyle(fontSize: 11, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
            ),
          ],
        ),
      );
      pw.Widget money(String k, num v, {bool bold = false}) => kv(k, rupiah(v), bold: bold);

      doc.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(24),
          build: (ctx) => [
            pw.Text(
              (_namaUsaha ?? 'NAMA USAHA').toUpperCase(),
              style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 2),
            pw.Text('Laporan Pendapatan Karyawan', style: pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 8),
            pw.Row(children: [
              pw.Expanded(
                child: pw.Text('usaha: ${_namausaha ?? '-'}', style: const pw.TextStyle(fontSize: 10)),
              ),
              pw.Text('Dicetak: $nowStr', style: const pw.TextStyle(fontSize: 10)),
            ]),
            if (staffEmail != null) ...[
              pw.SizedBox(height: 2),
              pw.Text('Email Karyawan: $staffEmail', style: const pw.TextStyle(fontSize: 10)),
            ],
            pw.SizedBox(height: 16),
            pw.Text('Ringkasan', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 8),
            money('Pendapatan', pendapatan),
            money('Potongan', potongan),
            money('Servis', servis),
            pw.Divider(),
            money('Total Hasil', totalHasil, bold: true),
            pw.SizedBox(height: 16),
            pw.Text('Rincian Pendapatan', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 8),
            kv('Skor Mato', '$skor'),
            kv('Nilai/Mata', rupiah(nilai)),
            kv('Terakhir update', updatedAtStr),
            pw.SizedBox(height: 6),
            money('Pinjaman', pinjaman),
            money('Bon Makan', bonMakan),
            money('Bon Gudang', bonGudang),
            money('Potongan Absen', potAbsen),
            money('Uang Servis', servis),
            pw.Divider(),
            money('Total Mingguan', totalMingguan, bold: true),
            money('Hasil', hasil, bold: true),
            money('Total Hasil', totalHasil, bold: true),
            pw.SizedBox(height: 20),
            pw.Text(
              'Catatan: PDF ini hanya berisi bagian "Pendapatan Saya" (grafik tidak disertakan).',
              style: pw.TextStyle(fontSize: 9),
            ),
          ],
        ),
      );

      await Printing.layoutPdf(onLayout: (_) async => doc.save());

      if (!mounted) return;
      await showTopToast(
        context,
        'PDF siap dicetak / dibagikan',
        icon: Icons.check_circle,
      );
    } catch (e) {
      if (!mounted) return;
      await showTopToast(
        context,
        'Gagal membuat PDF: $e',
        icon: Icons.warning_amber_rounded,
        duration: const Duration(milliseconds: 1800),
      );
    }
  }

  // ================== FILTER UI HELPERS ==================
  Future<void> _pickDate({required bool isStart}) async {
    final now = DateTime.now();
    final init = isStart ? (_startDate ?? now) : (_endDate ?? _startDate ?? now);
    final picked = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1, 12, 31),
      builder: (ctx, child) =>
          Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );
    if (picked == null) return;
    setState(() {
      if (isStart) {
        _startDate = picked;
        if (_endDate != null && _endDate!.isBefore(_startDate!)) {
          _endDate = _startDate;
        }
      } else {
        _endDate = picked;
        if (_startDate != null && _startDate!.isAfter(_endDate!)) {
          _startDate = _endDate;
        }
      }
    });
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _preset = 'all';
    });
  }

  void _applyPreset(String code) {
    final now = DateTime.now();
    setState(() {
      _preset = code;
      if (code == 'all') {
        _startDate = null;
        _endDate = null;
      } else if (code == 'month') {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      } else if (code == '100') {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      }
    });
  }

  // ================== BUILD ==================
  @override
  Widget build(BuildContext context) {
    final namaUsahaUpper = (_namaUsaha ?? 'NAMA USAHA').toUpperCase();

    // ⬇️ PAKSA LIGHT THEME + teks/ikon default hitam
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      dialogTheme: base.dialogTheme.copyWith(
        titleTextStyle: const TextStyle(
            color: Colors.black87, fontWeight: FontWeight.w700, fontSize: 18),
        contentTextStyle: const TextStyle(color: Colors.black87, fontSize: 14),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,   // teks tombol primary tetap putih
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
        data: forceLight,
        child: Scaffold(
          extendBodyBehindAppBar: true,
          backgroundColor: Colors.transparent,

      // =================== APP BAR RESPONSIF ===================
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Builder(
                  builder: (context) => IconButton(
                    icon: const Icon(Icons.menu, size: 30, color: Colors.black),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                    tooltip: 'Menu',
                  ),
                ),
                const SizedBox(width: 8),
                // ⬇️ Expanded agar teks nama usaha dapat ruang
                Expanded(
                  child: Row(
                    children: [
                      Image.asset(
                        'assets/InmatoID_logo.png',
                        height: isPhone(context) ? 44 : 62,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          namaUsahaUpper,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: isPhone(context) ? 18 : 26,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // (Hapus Spacer agar kiri tidak ketindih)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.refresh, size: 20),
                      tooltip: 'Refresh',
                      onPressed: _refreshPage,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'KARYAWAN',
                          style: TextStyle(
                            fontSize:
                            MediaQuery.of(context).size.width < 600 ? 14 : 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        if ((_staffName ?? '').isNotEmpty) const SizedBox(height: 2),
                        if ((_staffName ?? '').isNotEmpty)
                          ConstrainedBox(
                            constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width < 600
                                  ? 140
                                  : 220,
                            ),
                            child: Text(
                              _staffName!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontSize:
                                MediaQuery.of(context).size.width < 600 ? 12 : 14,
                                color: Colors.black54,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),

      // =================== DRAWER ===================
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            _FancyDrawerHeader(
              namaUsaha: namaUsahaUpper,
              email: staffEmail ?? 'Memuat email…',
              role: 'Karyawan',
              usaha: (_namausaha ?? '[LOKASI]').toUpperCase(),
              photoUrl: Supabase.instance.client.auth.currentUser
                  ?.userMetadata?['avatar_url'],
              onTapEditUsaha: null,
              onTapSettings: null,
            ),
            const Divider(height: 24, indent: 16, endIndent: 16),
            _DrawerItem(
              icon: Icons.feedback_rounded,
              label: 'Kirim Feedback',
              onTap: () {
                Navigator.pop(context);
                if (_idUsaha == null) {
                  showTopToast(context, 'ID usaha belum tersedia',
                    icon: Icons.info_rounded,
                    duration: const Duration(milliseconds: 1600),
                  );
                  return;
                }
                Navigator.of(context).push(
                  MaterialPageRoute(
                      builder: (_) => FeedbackPage(idUsaha: _idUsaha!)),
                );
              },
            ),
            const Divider(height: 24, indent: 16, endIndent: 16),
            _DrawerItem(
              icon: Icons.logout_rounded,
              label: 'Keluar',
              danger: true,
              onTap: () async {
                await supabase.auth.signOut();
                if (context.mounted) {
                  Navigator.pushReplacementNamed(context, '/login');
                }
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),

      body: AppBackground(
        overlayLight: true,      // putih tipis agar konten jelas
        overlayOpacity: 0.22,    // 0.20–0.32 enak dilihat
        // showBrandGradient: true, // biarkan true jika mau tetap ada brand gradient
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ===== Filter Tanggal =====
                Text(
                  'Filter Tanggal',
                  style: TextStyle(
                    fontSize: isPhone(context) ? 18 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                _filterSection(context),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _PresetChip(
                      text: 'Semua Data',
                      selected: _preset == 'all',
                      onTap: () => _applyPreset('all'),
                    ),
                    _PresetChip(
                      text: 'Bulan Ini',
                      selected: _preset == 'month',
                      onTap: () => _applyPreset('month'),
                    ),
                    _PresetChip(
                      text: '100 Hari Terakhir',
                      selected: _preset == '100',
                      onTap: () => _applyPreset('100'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    width: isPhone(context) ? double.infinity : null,
                    child: ElevatedButton.icon(
                      onPressed: _exportPendapatanSayaToPdf,
                      icon: const Icon(Icons.picture_as_pdf),
                      label: const Text('Export "Pendapatan Saya" ke PDF'),
                    ),
                  ),
                ),
                const SizedBox(height: 18),

                // ====== PENDAPATAN SAYA ======
                FutureBuilder<Map<String, dynamic>?>(
                  future: _fetchMyIncomeRow(),
                  builder: (context, snap) {
                    if (snap.connectionState == ConnectionState.waiting) {
                      return const Padding(
                        padding: EdgeInsets.all(24.0),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    if (snap.hasError) {
                      return Text('Gagal memuat data: ${snap.error}');
                    }
                    final row = snap.data;
                    if (row == null) {
                      return const Text('Data pendapatan tidak ditemukan');
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Pendapatan Saya',
                            style: TextStyle(
                                fontSize: isPhone(context) ? 20 : 22,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        _summaryCard(row),
                        const SizedBox(height: 18),
                        _detailBreakdown(row),
                      ],
                    );
                  },
                ),

                const SizedBox(height: 22),

                // ====== GRAFIK: Total Hasil ======
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchTotalHasilSeries(),
                  builder: (context, snap) {
                    if (snap.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.all(24.0),
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }
                    if (snap.hasError) {
                      return Text('Gagal memuat grafik: ${snap.error}');
                    }
                    final data = snap.data ?? [];
                    final lastVal = (data.isNotEmpty)
                        ? (data.last['total_hasil'] as num?) ?? 0
                        : 0;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _summaryTotalHasil(lastVal),
                        const SizedBox(height: 16),
                        Text('Grafik Total Hasil',
                            style: TextStyle(
                                fontSize: isPhone(context) ? 16 : 18,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        _buildLineChartLikeusaha(
                          data,
                          valueKey: 'total_hasil',
                          yLabel: 'Total Hasil',
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
        ),
    );
  }

  // ================= refresh ====================
  Future<void> _refreshPage() async {
    await Future.wait([_loadNamaUsaha(), _loadStaffInfo()]);
    if (!mounted) return;
    setState(() {});
    showTopToast(context, 'Berhasil refresh halaman');
  }

  // ================= Filter section (responsif) =================
  Widget _filterSection(BuildContext context) {
    final bool phone = isPhone(context);

    final left = Expanded(
      child: InkWell(
        onTap: () => _pickDate(isStart: true),
        borderRadius: BorderRadius.circular(40),
        child: _DatePill(
          label: 'Tanggal Awal',
          value: _startDate == null
              ? '—'
              : DateFormat('d MMM yyyy', 'id_ID').format(_startDate!),
        ),
      ),
    );

    final right = Expanded(
      child: InkWell(
        onTap: () => _pickDate(isStart: false),
        borderRadius: BorderRadius.circular(40),
        child: _DatePill(
          label: 'Tanggal Akhir',
          value: _endDate == null
              ? '—'
              : DateFormat('d MMM yyyy', 'id_ID').format(_endDate!),
        ),
      ),
    );

    final clearBtn = OutlinedButton(
      onPressed: _clearDates,
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Colors.black, width: 1),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      ),
      child: const Text('Clear'),
    );

    if (phone) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [left]),
          const SizedBox(height: 8),
          Row(children: [right]),
          const SizedBox(height: 8),
          clearBtn,
        ],
      );
    }

    return Row(
      children: [
        left,
        const SizedBox(width: 10),
        const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(width: 10),
        right,
        const SizedBox(width: 10),
        clearBtn,
      ],
    );
  }

  // ====== Summary Card (grid responsif) ======
  Widget _summaryCard(Map<String, dynamic> row) {
    final pendapatan = (row['pendapatan'] as num?) ?? 0;
    final servis = (row['uang_servis'] as num?) ?? 0;
    final potongan = ((row['pinjaman'] as num?) ?? 0) +
        ((row['bon_makan'] as num?) ?? 0) +
        ((row['bon_gudang'] as num?) ?? 0) +
        ((row['pot_absen'] as num?) ?? 0);
    final totalHasil =
        (row['total_hasil'] as num?) ?? (pendapatan - potongan + servis);

    final items = <Widget>[
      _summaryItem('Pendapatan', rupiah(pendapatan), Icons.trending_up_rounded),
      _summaryItem('Potongan', rupiah(potongan), Icons.remove_circle_outline_rounded),
      _summaryItem('Servis', rupiah(servis), Icons.miscellaneous_services_rounded),
      _summaryItem('Total Hasil', rupiah(totalHasil), Icons.summarize_rounded, emphasize: true),
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      // ⬇️ masing-masing card selebar isinya; akan otomatis wrap ke baris berikutnya
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        alignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: items,
      ),
    );
  }

  Widget _summaryItem(String title, String value, IconData icon, {bool emphasize = false}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: emphasize ? const Color(0xFFFFE4E9) : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black.withOpacity(.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Icon(icon, size: 16), const SizedBox(width: 6), Text(title)]),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  // ====== Detail Breakdown (info header responsif) ======
  Widget _detailBreakdown(Map<String, dynamic> row) {
    final skor = (row['skor_mato'] as num?) ?? 0;
    final nilai = (row['nilai_per_mata'] as num?) ?? 0;
    final pendapatan = (row['pendapatan'] as num?) ?? (skor * nilai);
    final pinjaman = (row['pinjaman'] as num?) ?? 0;
    final bonMakan = (row['bon_makan'] as num?) ?? 0;
    final bonGudang = (row['bon_gudang'] as num?) ?? 0;
    final potAbsen = (row['pot_absen'] as num?) ?? 0;
    final servis = (row['uang_servis'] as num?) ?? 0;
    final totalMingguan =
        (row['total_mingguan'] as num?) ?? (pendapatan + servis);
    final hasil = (row['hasil'] as num?) ??
        (pendapatan - (pinjaman + bonMakan + bonGudang + potAbsen));
    final totalHasil = (row['total_hasil'] as num?) ?? (hasil + servis);

    final updatedAt = () {
      final raw = (row['updated_at'])?.toString();
      if (raw == null) return '—';
      try {
        return DateFormat('dd MMM yyyy HH:mm', 'id_ID')
            .format(DateTime.parse(raw).toLocal());
      } catch (_) {
        return '—';
      }
    }();

    Widget line(String label, num value, {bool bold = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(rupiah(value),
              style: TextStyle(
                  fontWeight: bold ? FontWeight.w800 : FontWeight.w600)),
        ],
      ),
    );

    final infoTop = isPhone(context)
        ? Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Skor Mato: $skor'),
        const SizedBox(height: 4),
        Text('Nilai/Mata: ${rupiah(nilai)}'),
        const SizedBox(height: 4),
        Text('Terakhir update: $updatedAt'),
      ],
    )
        : Row(
      children: [
        Expanded(child: Text('Skor Mato: $skor')),
        Expanded(child: Text('Nilai/Mata: ${rupiah(nilai)}')),
        Expanded(child: Text('Terakhir update: $updatedAt')),
      ],
    );

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Rincian Pendapatan',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          infoTop,
          const Divider(height: 22),
          line('Pendapatan', pendapatan),
          line('Pinjaman', pinjaman),
          line('Bon Makan', bonMakan),
          line('Bon Gudang', bonGudang),
          line('Potongan Absen', potAbsen),
          line('Uang Servis', servis),
          const Divider(height: 22),
          line('Total Hasil', totalHasil, bold: true),
        ],
      ),
    );
  }

  // ==== Toast kecil di dekat atas (seragam dengan InputBahanPokokPage) ====
  Future<void> showTopToast(
      BuildContext context,
      String message, {
        IconData icon = Icons.check_circle,
        Duration duration = const Duration(milliseconds: 1600),
      }) async {
    if (!context.mounted) return;
    await showGeneralDialog(
      context: context,
      barrierColor: Colors.transparent,
      barrierDismissible: true,
      barrierLabel: 'dismiss',
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, _, __) {
        Future.delayed(duration, () {
          if (Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
        });
        return SafeArea(
          child: Align(
            alignment: const Alignment(0, -0.92),
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [
                    BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4)),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        message,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, __, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(curved), child: child),
        );
      },
    );
  }

  // ====== Summary kecil Total Hasil ======
  Widget _summaryTotalHasil(num totalHasil) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          // ikon tetap seperti semula (tidak diubah)
          const Icon(Icons.attach_money_rounded),
          const SizedBox(width: 10),
          const Text('Total Hasil Terakhir',
              style: TextStyle(fontWeight: FontWeight.w700)),
          const Spacer(),
          Text(rupiah(totalHasil),
              style: const TextStyle(
                  fontWeight: FontWeight.w800, color: Colors.black)),
        ],
      ),
    );
  }

  // ====== Chart dengan horizontal scroll pada X axis ======
  String _formatRupiahShort(num v) {
    if (v.abs() >= 1000000000) {
      return 'Rp ${(v / 1000000000).toStringAsFixed(2)} M';
    }
    if (v.abs() >= 1000000) {
      return 'Rp ${(v / 1000000).toStringAsFixed(2)} jt';
    }
    if (v.abs() >= 1000) {
      return 'Rp ${(v / 1000).toStringAsFixed(0)} rb';
    }
    return 'Rp ${v.toStringAsFixed(0)}';
  }

  Widget _buildLineChartLikeusaha(
      List<Map<String, dynamic>> data, {
        required String valueKey,
        required String yLabel,
      }) {
    if (data.isEmpty) {
      return Container(
          height: 300,
          alignment: Alignment.center,
          child: const Text('Tidak ada data'));
    }

    // akumulasi per tanggal
    final Map<String, double> perTanggal = {};
    for (final it in data) {
      final tgl = (it['tanggal'] ?? '').toString();
      final val = (it[valueKey] as num?)?.toDouble() ?? 0;
      perTanggal[tgl] = (perTanggal[tgl] ?? 0) + val;
    }
    final keys = perTanggal.keys.toList()..sort();
    final values = keys.map((k) => perTanggal[k]!).toList();
    final minVal = values.reduce((a, b) => a < b ? a : b);
    final maxVal = values.reduce((a, b) => a > b ? a : b);
    final chartMinY = (minVal * 0.2).clamp(0, double.infinity).toDouble();
    final chartMaxY = (maxVal * 1.2).toDouble();
    final spots =
    List.generate(keys.length, (i) => FlSpot(i.toDouble(), perTanggal[keys[i]]!));

    return LayoutBuilder(
      builder: (ctx, cons) {
        final bool phone = isPhone(ctx);
        final bool tablet = isTablet(ctx);

        // jarak minimum per titik
        final double perPoint = phone ? 46 : (tablet ? 38 : 34);
        const double extraPaddingPx = 80; // padding kiri-kanan internal
        final double wantWidth = (perPoint * keys.length) + extraPaddingPx;
        final double chartWidth =
        wantWidth < cons.maxWidth ? cons.maxWidth : wantWidth;

        final double chartHeight = phone ? 300 : (tablet ? 320 : 360);
        final double minX = -0.5;
        final double maxX = (keys.length - 1) + 0.5;
        final double yInterval =
        ((chartMaxY - chartMinY) / 5).clamp(1, double.infinity);

        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.black.withOpacity(.06)),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(.06),
                  blurRadius: 16,
                  offset: const Offset(0, 6))
            ],
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: SizedBox(
              width: chartWidth,
              height: chartHeight,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: LineChart(
                  LineChartData(
                    minX: minX,
                    maxX: maxX,
                    minY: chartMinY,
                    maxY: chartMaxY,
                    gridData: FlGridData(
                      show: true,
                      drawVerticalLine: false,
                      horizontalInterval: yInterval,
                      getDrawingHorizontalLine: (v) => FlLine(
                        color: const Color(0xFFE5E7EB),
                        strokeWidth: 1,
                        dashArray: const [6, 6],
                      ),
                    ),
                    titlesData: FlTitlesData(
                      leftTitles: AxisTitles(
                        axisNameWidget: Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: Text(yLabel,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black87)),
                        ),
                        axisNameSize: 28,
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 72,
                          getTitlesWidget: (value, _) => Text(
                            _formatRupiahShort(value),
                            style: const TextStyle(
                                fontSize: 11, color: Colors.black87),
                          ),
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        axisNameWidget: const Padding(
                          padding: EdgeInsets.only(top: 2),
                          child: Text('Tanggal',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black87)),
                        ),
                        axisNameSize: 28,
                        sideTitles: SideTitles(
                          showTitles: true,
                          interval: 1,
                          getTitlesWidget: (value, meta) {
                            final i = value.toInt();
                            if (i < 0 || i >= keys.length) {
                              return const SizedBox.shrink();
                            }
                            // Hindari label tepat di ujung
                            if (value - meta.min < 0.1 ||
                                meta.max - value < 0.1) {
                              return const SizedBox.shrink();
                            }
                            final txt = DateFormat('dd MMM', 'id_ID')
                                .format(DateTime.parse(keys[i]));
                            return Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text(
                                txt,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black87,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                    ),
                    borderData: FlBorderData(
                        show: true,
                        border: Border.all(color: const Color(0xFFE5E7EB))),
                    lineBarsData: [
                      LineChartBarData(
                        spots: spots,
                        isCurved: true,
                        barWidth: 3,
                        color: const Color(0xFF14B8A6),
                        belowBarData: BarAreaData(
                          show: true,
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              const Color(0xFF14B8A6).withOpacity(.25),
                              const Color(0xFF14B8A6).withOpacity(.05)
                            ],
                          ),
                        ),
                        dotData: FlDotData(
                          show: true,
                          getDotPainter: (_, __, ___, ____) =>
                              FlDotCirclePainter(
                                radius: 3.8,
                                color: Colors.white,
                                strokeWidth: 2.5,
                                strokeColor: const Color(0xFF0EA5A4),
                              ),
                        ),
                      ),
                    ],
                    lineTouchData: LineTouchData(
                      handleBuiltInTouches: true,
                      touchTooltipData: LineTouchTooltipData(
                        tooltipBorderRadius: BorderRadius.circular(10),
                        tooltipPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        getTooltipColor: (_) => const Color(0xFF1F2937),
                        fitInsideHorizontally: true,
                        fitInsideVertically: true,
                        getTooltipItems: (spots) => spots.map((ts) {
                          final i =
                          ts.x.toInt().clamp(0, keys.length - 1);
                          final tanggal = DateFormat('d MMM yyyy', 'id_ID')
                              .format(DateTime.parse(keys[i]));
                          return LineTooltipItem(
                            '$tanggal\n',
                            const TextStyle(
                                fontSize: 11,
                                color: Colors.white70,
                                fontWeight: FontWeight.w600),
                            children: [
                              TextSpan(
                                  text: _formatRupiahShort(ts.y),
                                  style: const TextStyle(
                                      fontSize: 14,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w800))
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

//// ===================== Reusable kecil (preset & date pill) =====================
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style:
                    const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  const _PresetChip({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFE4E9) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child:
        Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }
}

//// ===================== Drawer Components =====================
class _FancyDrawerHeader extends StatelessWidget {
  final String namaUsaha;
  final String email;
  final String role;
  final String usaha; // STAFF: ini LOKASI
  final String? photoUrl;
  final VoidCallback? onTapEditUsaha;
  final VoidCallback? onTapSettings;

  const _FancyDrawerHeader({
    required this.namaUsaha,
    required this.email,
    required this.role,
    required this.usaha,
    this.photoUrl,
    this.onTapEditUsaha,
    this.onTapSettings,
  });

  String _initialsFrom(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return 'U';
    final first = parts.first.isNotEmpty ? parts.first[0] : '';
    final last = parts.length > 1 && parts.last.isNotEmpty ? parts.last[0] : '';
    return (first + last).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(24),
        bottomRight: Radius.circular(24),
      ),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFC1CC), Colors.white],
          ),
        ),
        padding: EdgeInsets.fromLTRB(16, top + 16, 12, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: const Color(0xFF2D2D2D),
                  backgroundImage: (photoUrl != null && photoUrl!.isNotEmpty)
                      ? NetworkImage(photoUrl!)
                      : null,
                  child: (photoUrl == null || photoUrl!.isEmpty)
                      ? Text(
                    _initialsFrom(namaUsaha),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                    ),
                  )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              namaUsaha,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                letterSpacing: .2,
                              ),
                            ),
                          ),
                          if (onTapEditUsaha != null) ...[
                            const SizedBox(width: 6),
                            InkWell(
                              onTap: onTapEditUsaha,
                              borderRadius: BorderRadius.circular(20),
                              child: const Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Icon(Icons.edit, size: 18),
                              ),
                            ),
                          ],
                          if (onTapSettings != null) ...[
                            const SizedBox(width: 4),
                            InkWell(
                              onTap: onTapSettings,
                              borderRadius: BorderRadius.circular(20),
                              child: const Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Icon(Icons.settings, size: 18),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _badge(role, color: const Color(0xFF22313F)),
                  const SizedBox(width: 8),
                  _chip(icon: Icons.location_on_rounded, label: usaha),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const _ActiveInfo(),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, {required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
          color: color, borderRadius: BorderRadius.circular(999)),
      child: Text(
        text,
        style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: .3),
      ),
    );
  }

  Widget _chip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black.withOpacity(0.10)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.black87),
          const SizedBox(width: 6),
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                  letterSpacing: .2)),
        ],
      ),
    );
  }
}

class _ActiveInfo extends StatelessWidget {
  const _ActiveInfo();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.55),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: const Row(
        children: [
          Icon(Icons.verified_user, size: 16, color: Colors.black87),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Akun aktif – akses Karyawan',
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final fg = danger ? Colors.red : Colors.black87;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(icon, color: fg),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(fontWeight: FontWeight.w600, color: fg),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: danger ? Colors.red : Colors.black38,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
