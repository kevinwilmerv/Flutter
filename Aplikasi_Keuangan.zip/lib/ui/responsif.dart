// responsif.dart
import 'package:flutter/widgets.dart';

class Breakpoints {
  static const double mobile = 600;
  static const double tablet = 1024;
}

extension ContextSizeX on BuildContext {
  Size get screenSize => MediaQuery.of(this).size;
  double get w => screenSize.width;
  double get h => screenSize.height;

  bool get isMobile => w < Breakpoints.mobile;
  bool get isTablet => w >= Breakpoints.mobile && w < Breakpoints.tablet;
  bool get isDesktop => w >= Breakpoints.tablet;

  // Helper nilai adaptif
  T pick<T>({
    required T mobile,
    T? tablet,
    T? desktop,
  }) {
    if (isDesktop && desktop != null) return desktop;
    if (isTablet && tablet != null) return tablet;
    return mobile;
  }
}

// Widget pembungkus cepat
class ResponsiveBuilder extends StatelessWidget {
  final Widget Function(BuildContext, BoxConstraints, bool isMobile) builder;
  const ResponsiveBuilder({super.key, required this.builder});
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (ctx, cons) => builder(ctx, cons, cons.maxWidth < Breakpoints.mobile),
    );
  }
}
