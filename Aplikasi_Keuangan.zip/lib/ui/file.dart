// file.dart
import 'package:flutter/material.dart';
import 'responsif.dart';

class HalamanContoh extends StatelessWidget {
  const HalamanContoh({super.key});

  @override
  Widget build(BuildContext context) {
    final isMobile = context.isMobile;

    final double pagePadding = context.pick(
      mobile: 12,
      tablet: 20,
      desktop: 28,
    );

    final double titleSize = context.pick(
      mobile: 18,
      tablet: 20,
      desktop: 22,
    );

    final double chartHeight = context.pick(
      mobile: 200,
      tablet: 280,
      desktop: 340,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Dashboard',
          style: TextStyle(fontSize: titleSize),
        ),
      ),
      drawer: isMobile ? const Drawer(child: Text('Menu')) : null,
      body: Padding(
        padding: EdgeInsets.all(pagePadding),
        child: LayoutBuilder(
          builder: (ctx, cons) {
            // Contoh: sidebar + konten → jadi satu kolom di mobile
            final content = isMobile
                ? Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _SidebarCard(isMobile: isMobile),
                const SizedBox(height: 12),
                _KontenUtama(chartHeight: chartHeight, isMobile: isMobile),
              ],
            )
                : Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(width: 280, child: _SidebarCard(isMobile: isMobile)),
                const SizedBox(width: 16),
                Expanded(child: _KontenUtama(chartHeight: chartHeight, isMobile: isMobile)),
              ],
            );

            return content;
          },
        ),
      ),
      // Navigasi bawah khusus mobile (opsional)
      bottomNavigationBar: isMobile
          ? NavigationBar(
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.assessment), label: 'Laporan'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profil'),
        ],
      )
          : null,
    );
  }
}

class _SidebarCard extends StatelessWidget {
  final bool isMobile;
  const _SidebarCard({required this.isMobile});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: EdgeInsets.all(isMobile ? 12 : 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Ringkasan', style: TextStyle(fontSize: isMobile ? 16 : 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _StatChip(label: 'Omzet', value: 'Rp 12,5 jt', isMobile: isMobile),
                _StatChip(label: 'Laba', value: 'Rp 3,1 jt', isMobile: isMobile),
                _StatChip(label: 'Transaksi', value: '152', isMobile: isMobile),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _KontenUtama extends StatelessWidget {
  final double chartHeight;
  final bool isMobile;
  const _KontenUtama({required this.chartHeight, required this.isMobile});

  @override
  Widget build(BuildContext context) {
    // Grid responsif: 1–2 kolom di mobile, 3–4 di tablet/desktop
    final crossAxisCount = context.pick(mobile: 1, tablet: 2, desktop: 3);

    return Column(
      children: [
        Card(
          margin: EdgeInsets.zero,
          child: SizedBox(
            height: chartHeight,
            child: const Center(child: Text('Chart Omzet (placeholder)')),
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 6,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: isMobile ? 16 / 9 : 4 / 3,
          ),
          itemBuilder: (ctx, i) => const _ItemCard(),
        ),
      ],
    );
  }
}

class _ItemCard extends StatelessWidget {
  const _ItemCard();

  @override
  Widget build(BuildContext context) {
    final isMobile = context.isMobile;
    return Card(
      child: Padding(
        padding: EdgeInsets.all(isMobile ? 12 : 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Card ${isMobile ? "(m)" : "(l)"}', style: TextStyle(fontSize: isMobile ? 14 : 16, fontWeight: FontWeight.w600)),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(0, isMobile ? 36 : 44),
                      shape: const StadiumBorder(),
                    ),
                    child: Text(isMobile ? 'Detail' : 'Lihat Detail'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final bool isMobile;
  const _StatChip({required this.label, required this.value, required this.isMobile});

  @override
  Widget build(BuildContext context) {
    return Chip(
      labelPadding: EdgeInsets.symmetric(horizontal: isMobile ? 8 : 10, vertical: isMobile ? 0 : 2),
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: TextStyle(fontSize: isMobile ? 12 : 13, color: Colors.black54)),
          Text(value, style: TextStyle(fontSize: isMobile ? 12 : 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
