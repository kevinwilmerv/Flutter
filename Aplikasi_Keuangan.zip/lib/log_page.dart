import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
// import 'package:laporan_keuangan1/ui/responsif.dart'; // tidak dipakai, boleh dihapus
import 'package:ok_oce/widget/app_background.dart';

class LogPage extends StatefulWidget {
  const LogPage({super.key});

  @override
  State<LogPage> createState() => _LogPageState();
}

class _LogPageState extends State<LogPage> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> logs = [];
  bool isLoading = true;

  StreamSubscription<List<Map<String, dynamic>>>? _sub; // cancel di dispose

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // biar wallpaper transisinya halus saat halaman dibuka
    AppBackground.precacheAll(context);
  }

  @override
  void initState() {
    super.initState();
    fetchLogs();

    // Realtime update (urut terbaru dulu)
    _sub = supabase
        .from('log_aktivitas')
        .stream(primaryKey: ['id'])
        .order('waktu', ascending: false)
        .listen((data) {
      if (!mounted) return;
      setState(() {
        logs = List<Map<String, dynamic>>.from(data);
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> fetchLogs() async {
    setState(() => isLoading = true);
    try {
      final user = supabase.auth.currentUser;
      if (user == null) throw Exception("User belum login");

      final profile = await supabase
          .from('profiles')
          .select('id_usaha')
          .eq('id', user.id)
          .maybeSingle();

      final idUsaha = profile?['id_usaha'];

      final response = await supabase
          .from('log_aktivitas')
          .select()
          .eq('id_usaha', idUsaha) // filter per usaha
          .order('waktu', ascending: false);

      if (!mounted) return;
      setState(() {
        logs = List<Map<String, dynamic>>.from(response);
        isLoading = false;
      });
    } catch (e) {
      debugPrint("❌ Gagal mengambil log: $e");
      if (!mounted) return;
      setState(() => isLoading = false);
    }
  }

  String formatWaktu(String waktuIso) {
    final date = DateTime.tryParse(waktuIso);
    if (date == null) return waktuIso;
    return DateFormat('dd MMM yyyy HH:mm:ss', 'id_ID').format(date);
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final bool isPhone = w < 600;
    final double cardPad = isPhone ? 12 : 14;

    // ✅ Paksa LIGHT + teks/ikon hitam
    final base = Theme.of(context);
    final forceLight = base.copyWith(
      brightness: Brightness.light,
      iconTheme: const IconThemeData(color: Colors.black87),
      textTheme: base.textTheme.apply(
        bodyColor: Colors.black87,
        displayColor: Colors.black87,
      ),
      appBarTheme: base.appBarTheme.copyWith(
        foregroundColor: Colors.black87,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.black87,
          fontWeight: FontWeight.w700,
          fontSize: 18,
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      colorScheme: base.colorScheme.copyWith(
        brightness: Brightness.light,
        onSurface: Colors.black87,
        onBackground: Colors.black87,
        onPrimary: Colors.white,
        onSecondary: Colors.black87,
      ),
    );

    return Theme(
      data: forceLight,
      child: DefaultTextStyle.merge(
        style: const TextStyle(color: Colors.black87),
        child: AppBackground(
          // kalau mau kontras ekstra di atas wallpaper, nyalakan overlay:
          overlayLight: true,
          overlayOpacity: 0.10,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            extendBodyBehindAppBar: false,
            appBar: AppBar(
              title: const Text('Log Aktivitas'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => Navigator.maybePop(context),
                tooltip: 'Kembali',
                splashRadius: 22,
              ),
            ),
            body: SafeArea(
              top: false, // sudah ada AppBar
              minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : RefreshIndicator(
                onRefresh: fetchLogs,
                child: Scrollbar(
                  thumbVisibility: true,
                  child: logs.isEmpty
                      ? ListView(
                    physics:
                    const AlwaysScrollableScrollPhysics(),
                    children: const [
                      SizedBox(height: 120),
                      Center(
                        child: Text(
                          'Belum ada log aktivitas',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.black54,
                          ),
                        ),
                      ),
                    ],
                  )
                      : ListView.separated(
                    physics:
                    const AlwaysScrollableScrollPhysics(),
                    itemCount: logs.length,
                    separatorBuilder: (_, __) =>
                    const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final log = logs[index];
                      return _LogTile(
                        aktivitas: '${log['aktivitas']}',
                        halaman: '${log['halaman']}',
                        detail: '${log['detail'] ?? ''}',
                        waktuText:
                        formatWaktu('${log['waktu'] ?? ''}'),
                        pad: cardPad,
                        isPhone: isPhone,
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// ====== UI card log konsisten dengan halaman lain ======
class _LogTile extends StatelessWidget {
  final String aktivitas;
  final String halaman;
  final String detail;
  final String waktuText;
  final double pad;
  final bool isPhone;

  const _LogTile({
    required this.aktivitas,
    required this.halaman,
    required this.detail,
    required this.waktuText,
    required this.pad,
    required this.isPhone,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.05),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: EdgeInsets.all(pad),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                margin: const EdgeInsets.only(right: 10),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFFE53935), // aksen merah
                ),
              ),
              Expanded(
                child: Text(
                  '$aktivitas – $halaman',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: isPhone ? 15 : 16,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: isPhone ? 6 : 8),
          if (detail.isNotEmpty)
            Text(
              detail,
              style: TextStyle(
                fontSize: isPhone ? 13 : 14,
                color: Colors.black.withOpacity(.80),
                height: 1.25,
              ),
            ),
          SizedBox(height: isPhone ? 6 : 8),
          Text(
            waktuText,
            style: TextStyle(
              fontSize: 12,
              color: Colors.black.withOpacity(.55),
            ),
          ),
        ],
      ),
    );
  }
}
