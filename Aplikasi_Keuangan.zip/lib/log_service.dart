import 'package:supabase_flutter/supabase_flutter.dart';

class LogService {
  final supabase = Supabase.instance.client;

  Future<void> addLog({
    required String aktivitas,
    required String halaman,
    required String detail,
  }) async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) throw Exception("User belum login");

      final profile = await supabase
          .from('profiles')
          .select('nama, role, id_usaha') // ← WAJIB ambil id_usaha juga!
          .eq('id', user.id)
          .maybeSingle();

      if (profile == null) throw Exception("Data profil tidak ditemukan");

      final nama = profile['nama'] ?? '-';
      final role = profile['role'] ?? '-';
      final idUsaha = profile['id_usaha']; // ← WAJIB: pastikan tidak null

      await supabase.from('log_aktivitas').insert({
        'user_id': user.id,
        'nama': nama,
        'role': role,
        'id_usaha': idUsaha, // ← WAJIB: simpan id_usaha ke log
        'aktivitas': aktivitas,
        'halaman': halaman,
        'detail': detail,
        'waktu': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      print("❌ Gagal menambahkan log: $e");
    }
  }
}

final logService = LogService();
